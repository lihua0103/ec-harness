'use strict';
// This is a self-contained experience prototype. No DSH, model or clinical-data API is called.
const KEY = 'ec-clinical.workbench.prototype.v2';
const $ = (s) => document.querySelector(s);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icons = {
 home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-6v-7h-4v7H4a1 1 0 0 1-1-1z"/>',
 project:'<path d="M3 7h7l2-3h8a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3 9h18"/>',
 tasks:'<rect x="5" y="4" width="15" height="17" rx="2"/><path d="M9 4V2m7 2V2M9 10h7m-7 4h7m-7 4h4"/>',
 pending:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',
 artifacts:'<path d="M4 8h16v13H4zM3 4h18v4H3zM9 12h6"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 4 3c-1 0-1 2-1 2m0 3h.01"/>',
 listing:'<path d="M5 3h10l4 4v14H5zM15 3v5h4M8 11h8m-8 4h8m-8 3h5"/>',
 dvp:'<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6z"/><path d="m8 12 3 3 5-6"/>',
 arrow:'<path d="M4 12h15m-5-5 5 5-5 5"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 file:'<path d="M6 3h9l4 4v14H6zM15 3v5h4"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>',
 download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.file}</svg>`;
const capabilities = {
 listing:{name:'生成 Listing 程序',short:'Listing',subtitle:'从项目资料到程序交付',description:'识别需求与数据结构，组织程序草稿和检查证据，让每一次交付有据可查。',input:'需求规格、ALS 与合成数据',output:'程序草稿说明、检查记录',project:'SYN-101 · 临床数据整理示例',sceneLabel:'业务场景',scenes:[['manual','人工审核 Listing'],['medical','医学审核 Listing'],['pk-be','PK · BE'],['pk-sad','PK · SAD/MAD'],['report','报告 Listing']],files:[['需求规格_示例.xlsx','需求规格','仅内置合成名称，无真实工作簿'],['ALS_示例.xlsx','结构定义','仅内置合成名称，不含真实字段'],['合成数据_示例.csv','示例数据','仅合成资料展示，不读取受试者信息']],question:'两个需求版本，应该采用哪一个？',questionHint:'演示发现两个需求版本。只有确定基准，才能继续准备程序候选。',choices:[['latest','采用 V2.0 示例版本','以较新的需求版本作为本次合成演示基准。'],['baseline','保留 V1.0 示例版本','演示按既有基线继续，不自动选择新版本。']],stages:['识别项目资料','确认需求基准','准备程序候选','整理交付说明'],artifact:'Listing 程序交付说明（合成）',limitation:'此处不会生成或运行真实 R 程序；服务器复跑与业务 QC 均未执行。'},
 dvp:{name:'编制 DVP 草稿',short:'DVP',subtitle:'从方案要求到规则候选',description:'梳理方案要求与模板结构，逐项查看规则候选、待确认逻辑和测试用例说明。',input:'方案示例、公司模板结构',output:'规则草稿说明、用例候选',project:'SYN-202 · 数据核查计划示例',sceneLabel:'目标参考格式',scenes:[['generic','通用表达式参考'],['rave','Rave 步骤参考']],files:[['方案_合成示例.pdf','方案示例','仅内置合成名称，不读取 PDF'],['DVP_模板结构_示例.xlsx','模板结构','只展示虚构结构，不读取 Cover 或评审信息']],question:'边界条件尚不明确，需要如何处理？',questionHint:'演示规则“超过阈值时触发”未说明等于阈值的情况。不能擅自补全业务语义。',choices:[['unresolved','保留为待确认项','不推断边界，交由业务团队确认。'],['example','采用合成示例假设','只为体验流程演示“等于时不触发”，不应用于真实项目。']],stages:['识别方案与模板','澄清规则边界','准备规则候选','整理用例说明'],artifact:'DVP 规则与用例说明（合成）',limitation:'此处不会生成真实 DVP 工作簿或配置 EDC；所有规则与用例仅为展示候选。'}
};
// Domain examples mirror current plugin contracts, not any real project's content.
Object.assign(capabilities.listing, {
 subtitle:'项目目录 → 需求映射 → R 程序与 QC',
 description:'按 Manual、Medical、PK 或 Report 场景识别项目资料，理解需求与数据批次，查看 R 编程、执行修复及独立 QC 的交付链路。',
 input:'项目目录中的 spec、ALS、SAS/XPT/数据包',
 output:'单文件 R、Excel/RDS 与执行 / QC 证据（目标交付）',
 files:[['Listing_spec_V2.0_合成.xlsx','需求规格','来源、行条件、输出列、排序与人工核查说明'],['ALS_合成.xlsx','EDC 结构定义','表单、字段、访视与码表；不强制固定六列'],['SAS_20261101_合成.zip','数据批次','演示 SAS/XPT 数据包识别；密码不展示、不写日志']],
 stages:['发现目录、资料与数据批次','确认需求与映射歧义（如有）','R 编程、执行诊断与独立 QC（示意）','整理单文件 R 与交付证据（示意）'],
 question:'需求里的重复标记，是否意味着只输出重复行？',
 questionHint:'合成 spec 的 Condition 写明 flag=duplicated，但未明确要求过滤行。标记与筛选是不同操作，不能把重复标记自动变成只输出重复行。',
 choices:[['latest','保留全部适用行，增加重复标记','本合成示例选择：不附加只保留重复行的筛选。'],['baseline','按项目补充要求，仅输出重复行','模拟项目团队明确增加筛选条件；该裁定只适用于本任务。']],
 artifact:'Listing 单文件 R 与 QC 交付范围说明（合成）'
});
Object.assign(capabilities.dvp, {
 subtitle:'方案与模板 → 规则诊断 → DVP 候选',
 description:'依据方案 PDF 与公司模板，梳理跨字段、字段级、人工与动态规则，查看 fire-when 诊断、正反及边界用例候选。',
 input:'方案 PDF 文本层、公司 DVP 模板工作簿',
 output:'8-sheet DVP 草稿、用例候选、EDC 配置参考',
 files:[['Protocol_V1.0_合成.pdf','方案 PDF 文本层','表格版式不在文本层；扫描件需 OCR，加密 PDF 不支持'],['Company_DVP_合成.xlsx','公司 DVP 模板','先分类后读取；Cover / Approval 签署内容不读']],
 stages:['读取方案文本、分类并解析模板','处理规则语义与未解析项（如有）','fire-when 诊断与正 / 反 / 边界用例（示意）','DVP 草稿与 EDC 配置参考（示意）'],
 artifact:'DVP 8-sheet 草稿与用例交付范围说明（合成）',
 choices:[['unresolved','保留为 unresolved，交给 DM 确认','不猜测边界，也不将无法解析的规则冒充校验通过。'],['example','按已确认的合成要求：等于时不触发','仅代表本合成示例中的人工澄清，不自动应用于真实方案。']]
});
const navs = [['home','工作首页'],['project','项目'],['tasks','我的任务'],['pending','待我处理'],['artifacts','交付物'],['help','使用帮助']];
const statuses = {CREATED:['已创建 · 模拟',''],RUNNING:['处理中 · 模拟','running'],WAITING_FOR_USER:['待你确认','waiting'],SUCCEEDED:['已结束 · 模拟','success'],FAILED:['演示故障','failed'],CANCELLED:['已取消 · 模拟','']};
let storageIssue = '';
let persistence = true;
let toastTimer;
let route = 'home';
let detailId = '';
let detailTab = 'progress';
let viewedRun = '';
let listFilter = 'all';
let searchQuery = '';
let wizardState = null;
let confirmAction = null;
let dialogOpener = null;
const now = () => new Date().toISOString();
const stamp = value => new Date(value).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
const runOf = task => task.runs.find(r => r.id === task.currentRunId);
const isActive = r => ['CREATED','RUNNING','WAITING_FOR_USER'].includes(r.status);
const badge = status => `<span class="badge ${statuses[status]?.[1] || ''}">${statuses[status]?.[0] || '状态未知'}</span>`;
const seedRun = (id,status,stage,answer=null) => ({id,status,stage,answer,createdAt:now(),events:[{at:now(),message:'载入预置合成任务，非真实执行记录。'}]});
function freshState(){
 const r1=seedRun('DEMO-0001-R1','WAITING_FOR_USER',1);
 const r2=seedRun('DEMO-0002-R1','SUCCEEDED',4,'unresolved');
 return {version:2,revision:0,seq:2,tasks:[{id:'DEMO-0001',title:'Manual Listing · 重复标记需求确认',kind:'listing',project:capabilities.listing.project,scene:'manual',files:[0,1,2],createdAt:now(),currentRunId:r1.id,runs:[r1]},{id:'DEMO-0002',title:'DVP 规则草稿 · 示例交付',kind:'dvp',project:capabilities.dvp.project,scene:'generic',files:[0,1],createdAt:now(),currentRunId:r2.id,runs:[r2]}]};
}
function validState(s){
 const validContext=c=>c===undefined||(c&&typeof c==='object'&&!Array.isArray(c)&&Object.entries(c).every(([k,v])=>['root','batch','server','protocol','template'].includes(k)&&typeof v==='string'&&v.length<=1000));
 if(!s || s.version!==2 || !Number.isInteger(s.seq) || s.seq<0 || !Number.isInteger(s.revision) || !Array.isArray(s.tasks) || s.tasks.length>200)return false;
 const ids=new Set();
 return s.tasks.every(t=>{
  if(!t || !validContext(t.context) || !Object.hasOwn(capabilities,t.kind) || typeof t.id!=='string' || ids.has(t.id) || typeof t.title!=='string' || t.title.length>120 || typeof t.project!=='string' || !Number.isFinite(Date.parse(t.createdAt)) || !capabilities[t.kind].scenes.some(x=>x[0]===t.scene) || !Array.isArray(t.files) || t.files.length<1 || t.files.some(i=>!Number.isInteger(i)||!capabilities[t.kind].files[i]) || !Array.isArray(t.runs) || !t.runs.length || t.runs.length>100)return false;
  ids.add(t.id);
  const runIds=new Set();
  return t.runs.some(r=>r.id===t.currentRunId) && t.runs.every(r=>{
   if(!r || typeof r.id!=='string' || runIds.has(r.id) || !Object.hasOwn(statuses,r.status) || !Number.isInteger(r.stage) || r.stage<0 || r.stage>4 || !Number.isFinite(Date.parse(r.createdAt)) || !Array.isArray(r.events) || r.events.length>1000 || !r.events.every(e=>typeof e?.message==='string'&&Number.isFinite(Date.parse(e.at))))return false;
   runIds.add(r.id);
   if(r.answer!==null&&!capabilities[t.kind].choices.some(x=>x[0]===r.answer))return false;
   return (r.status!=='SUCCEEDED'||r.stage===4) && (r.status!=='WAITING_FOR_USER'||r.stage===1) && (r.status!=='RUNNING'||[0,2,3].includes(r.stage));
  });
 });
}
function load(){
 try{const raw=localStorage.getItem(KEY);if(raw){const parsed=JSON.parse(raw);if(!validState(parsed))throw new Error('INVALID');return parsed;}}
 catch(error){persistence=false;storageIssue='演示缓存不可用或格式异常，已切换为本页内存演示。不会覆盖原缓存；可通过“重置演示数据”恢复。';}
 return freshState();
}
let state=load();
function save(){
 state.revision++;
 if(!persistence)return;
 try{localStorage.setItem(KEY,JSON.stringify(state));}
 catch(error){persistence=false;storageIssue='无法保存演示状态，当前操作仅在本页保留。请勿将浏览器缓存视为企业服务端保存。';}
}
function toast(message){$('#toast').textContent=message;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{$('#toast').hidden=true;},4500);}
function event(run,message){run.events.push({at:now(),message});}
function taskRow(t){const r=runOf(t);return `<div class="task-row"><span class="task-type-icon ${t.kind}">${icon(t.kind)}</span><div class="task-copy"><button class="task-title" data-open="${esc(t.id)}">${esc(t.title)}</button><div class="task-meta"><span>${esc(t.project)}</span><span>${esc(t.id)}</span></div><button class="text-button open-task" data-open="${esc(t.id)}">${r.status==='WAITING_FOR_USER'?'处理待确认事项':r.status==='SUCCEEDED'?'查看候选结果':'打开任务'} ${icon('arrow')}</button></div>${badge(r.status)}</div>`;}
function businessCard(kind){const c=capabilities[kind];return `<article class="business-card ${kind}"><div class="business-card-body"><div class="business-title"><span class="business-icon">${icon(kind)}</span><div><h2>${c.name}</h2><small>${c.subtitle}</small></div></div><p class="business-description">${c.description}</p><dl class="io-list"><div><dt>输入</dt><dd>${c.input}</dd></div><div><dt>产出</dt><dd>${c.output}</dd></div></dl><div class="business-actions"><button class="button ${kind==='listing'?'primary':'subtle'}" data-new="${kind}">开始${c.short}示例 ${icon('arrow')}</button><button class="text-button" data-about="${kind}">了解使用流程</button></div></div><div class="business-foot">${icon('info')} ${kind==='listing'?'支持人工、医学、PK 与报告场景演示':'输出为规则候选，需由项目团队审核'}</div></article>`;}
function todoBox(t){const c=capabilities[t.kind];return `<div class="todo-box"><div class="todo-top">${icon('pending')}<span class="badge waiting">业务澄清 · 合成</span></div><h3>${c.question}</h3><p>${esc(t.title)}</p><button class="button" data-decision="${esc(t.id)}">去确认 ${icon('arrow')}</button></div>`;}
function renderHome(){
 const pending=state.tasks.filter(t=>runOf(t).status==='WAITING_FOR_USER');
 const tasks=[...state.tasks].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,3);
 return `<div class="page-heading"><div><h1>今天，从一项业务开始。</h1><p>选择工作，提供资料；把理解、处理和交付连在一起。</p></div><span class="date-label">你的临床数据管理工作区</span></div><div class="section-heading"><h2>发起工作 <small>不需要记住指令或工具名称</small></h2></div><div class="business-grid">${businessCard('listing')}${businessCard('dvp')}</div><div class="content-grid"><section class="panel"><div class="panel-heading"><h2>继续手头的工作</h2><button class="text-button" data-route="tasks">查看全部 ${icon('arrow')}</button></div>${tasks.length?tasks.map(taskRow).join(''):'<div class="empty"><p>还没有演示任务，从上方选择一项业务。</p></div>'}</section><section class="panel"><div class="panel-heading"><h2>待我处理 <span class="badge waiting">${pending.length}</span></h2><span class="dim"><small>需要你的判断</small></span></div>${pending.length?pending.slice(0,2).map(todoBox).join(''):'<div class="empty"><p>没有待确认事项。</p><span>模拟处理遇到歧义时，会在这里提醒你。</span></div>'}</section></div><div class="start-guide"><div><h3>第一次使用？跟着合成示例走一遍。</h3><p>选择资料 → 确认识别 → 处理澄清 → 获取候选说明，无需上传任何文件。</p></div><button class="text-button" data-route="help">查看上手指南 ${icon('arrow')}</button></div>`;
}
function renderTasks(){
 const filtered=state.tasks.filter(t=>(listFilter==='all'||t.kind===listFilter)&&`${t.title} ${t.id} ${t.project}`.toLowerCase().includes(searchQuery.toLowerCase()));
 return `<div class="page-heading"><div><h1>我的任务</h1><p>每项工作都有独立的资料、处理记录和候选结果。</p></div><button class="button primary" data-new="listing">新建示例任务</button></div><div class="toolbar"><div class="filter-group" aria-label="业务筛选">${[['all','全部任务'],['listing','Listing'],['dvp','DVP']].map(([v,l])=>`<button class="filter-button ${listFilter===v?'active':''}" data-filter="${v}" aria-pressed="${listFilter===v}">${l}</button>`).join('')}</div><input class="search" id="task-search" aria-label="搜索任务" placeholder="搜索任务名称、编号或项目" value="${esc(searchQuery)}"></div><section class="panel"><div class="table-scroll"><table><thead><tr><th>任务 / 合成项目</th><th>业务</th><th>运行状态</th><th>交付状态</th><th>操作</th></tr></thead><tbody>${filtered.map(t=>`<tr><td><button class="task-title" data-open="${esc(t.id)}">${esc(t.title)}</button><small>${esc(t.project)}</small><small>${esc(t.id)}</small></td><td>${capabilities[t.kind].short}</td><td>${badge(runOf(t).status)}</td><td><span class="badge outline">${runOf(t).status==='SUCCEEDED'?'候选 · 未审核':'尚无当前产物'}</span></td><td><button class="table-link" data-open="${esc(t.id)}">打开任务</button></td></tr>`).join('')}</tbody></table></div>${!filtered.length?'<div class="empty">未找到匹配任务，请调整筛选或创建示例任务。</div>':''}</section>`;
}
function renderPending(){const tasks=state.tasks.filter(t=>runOf(t).status==='WAITING_FOR_USER');return `<div class="page-heading"><div><h1>待我处理</h1><p>仅在资料或业务语义不明确时，请你作出判断。这里不是正式审批。</p></div></div><div class="panel">${tasks.length?tasks.map(todoBox).join(''):'<div class="empty"><p>当前没有待确认事项。</p><button class="button" data-route="tasks">查看我的任务</button></div>'}</div>`;}
function renderArtifacts(){
 const artifacts=state.tasks.flatMap(t=>t.runs.filter(r=>r.status==='SUCCEEDED').map(r=>({t,r})));
 return `<div class="page-heading"><div><h1>交付物</h1><p>这里只提供合成说明文件。程序执行、真实工作簿生成与业务审核均未发生。</p></div></div><div class="notice warning"><strong>候选与已审核，不能混为一谈</strong>即使模拟阶段已结束，结果仍是未经审核的示意内容，不能用于临床项目或生产 EDC。</div><section class="panel"><div class="table-scroll"><table><thead><tr><th>候选说明</th><th>关联任务 / 尝试</th><th>状态</th><th>操作</th></tr></thead><tbody>${artifacts.map(({t,r})=>`<tr><td>${capabilities[t.kind].artifact}<small>${esc(t.project)}</small></td><td>${esc(t.id)}<small>${esc(r.id)} ${r.id!==t.currentRunId?'（历史尝试）':'（当前尝试）'}</small></td><td><span class="badge waiting">合成候选 · 未审核</span></td><td><button class="table-link" data-download="${esc(t.id)}" data-run="${esc(r.id)}">下载说明 .md</button></td></tr>`).join('')}</tbody></table></div>${!artifacts.length?'<div class="empty">还没有候选说明。完成一条模拟任务后会显示在这里。</div>':''}</section>`;
}
function renderProjects(){return `<div class="page-heading"><div><h1>项目</h1><p>预置两个完全虚构的项目，只体验资料归属与任务组织，不读取本地文件。</p></div></div><div class="project-grid">${Object.entries(capabilities).map(([k,c])=>`<section class="panel project-card"><div class="project-code">${k==='listing'?'SYN-101':'SYN-202'} / 合成示例</div><h2>${c.project.split(' · ')[1]}</h2><p>${c.input}。所有文件名和识别结果均为内置演示内容。</p><div class="evidence-list">${c.files.map(f=>`<div class="evidence-row">${icon('file')}<div><h3>${f[0]}</h3><p>${f[1]} / ${f[2]}</p></div></div>`).join('')}</div><div class="action-row"><button class="button primary" data-new="${k}">${c.name}</button></div></section>`).join('')}</div>`;}
function renderHelp(){return `<div class="page-heading"><div><h1>从资料，到可解释的交付。</h1><p>不用学习提示词，也不必理解插件内部如何工作。</p></div></div><section class="panel help-section"><h2>用几分钟，体验一项完整工作</h2><ol><li><strong>选择业务。</strong>从“生成 Listing 程序”或“编制 DVP 草稿”进入。</li><li><strong>选择合成资料。</strong>系统展示资料角色；确认后创建带编号的模拟任务。</li><li><strong>推进模拟。</strong>每个阶段由你点击推进，不产生模型费用，也没有后台真实运行。</li><li><strong>处理必要澄清。</strong>选择需求基准或规则边界，再继续演示。</li><li><strong>获取候选说明。</strong>查看未执行的检查项，下载带有合成标识的 Markdown 说明。</li></ol><div class="action-row"><button class="button primary" data-new="listing">体验 Listing</button><button class="button" data-new="dvp">体验 DVP</button></div></section><section class="panel help-section"><h2>先看运行状态，再看交付状态</h2><p>“已结束 · 模拟”只说明演示阶段走完了；“候选 · 未审核”表示没有得到业务批准。这里没有真实检查通过、电子签名或正式发布能力。</p></section><section class="panel help-section"><h2>独立平台，适配 DSH</h2><p>这版界面独立于 DSH。正式系统可由平台管理项目、任务、待办与交付物，通过版本化适配器调用 DSH 引擎。平台不依赖 DSH 页面或内部组件；上游升级先验证适配器，不自动升级生产运行环境。</p><p class="spaced">当前仅验证交互，没有调用 DSH。浏览器缓存不是服务端任务库，也不支持多人协同；插件能力、身份权限、隔离执行和数据 API 仍需后续实现及验证。</p></section><section class="panel help-section"><h2>数据与恢复</h2><p>原型不上传、不读取文件，不使用外部字体或 CDN。演示任务仅保存到本浏览器专属缓存；清理浏览器数据会丢失记录。可取消任务、模拟故障并创建新尝试，旧尝试不会被覆盖。</p><p class="spaced">页面里的资料选择不改变两个业务插件现有的数据读取规则，尤其不会绕过 DVP 的 Cover 与评审信息限制。</p></section>`;}
function progressBody(t,r,historical){
 const c=capabilities[t.kind];
 let message='',cls='',action='';
 if(r.status==='CREATED'){message='<strong>模拟任务已创建，资料已绑定。</strong>下一步开始合成流程演示。不会调用模型或执行程序。';action=`<button class="button primary" data-command="start">开始模拟处理 ${icon('arrow')}</button>`;}
 if(r.status==='RUNNING'){message=`<strong>当前：${c.stages[r.stage]}</strong>这是手动推进的交互演示，没有后台实际执行。`;action=`<button class="button primary" data-command="advance" data-stage="${r.stage}">推进模拟至下一步 ${icon('arrow')}</button>`;}
 if(r.status==='WAITING_FOR_USER'){cls='warning';message=`<strong>需要你的判断：${c.question}</strong>${c.questionHint}`;action='<button class="button primary" data-tab="decision">处理待确认事项</button>';}
 if(r.status==='SUCCEEDED'){cls='success';message='<strong>模拟流程已结束，候选说明已准备。</strong>并未执行程序或规则检查。请查看“结果与检查”中的证据边界。';action='<button class="button primary" data-tab="results">查看候选结果</button>';}
 if(r.status==='FAILED'){cls='failed';message='<strong>演示故障：运行环境不可用。</strong>这是一条主动触发的合成故障。正式平台应由管理员配置环境，员工无需调试系统参数。可创建新尝试重新体验。';}
 if(r.status==='CANCELLED'){message='<strong>该次模拟已取消。</strong>没有真实进程运行；原待确认问题已失效。可创建新尝试，不覆盖旧记录。';}
 return `<div class="notice ${cls}">${message}</div><h3>处理进度 <span class="badge outline">合成阶段 ${Math.min(r.stage+1,4)} / 4</span></h3><ol class="stage-list">${c.stages.map((s,i)=>`<li class="${i<r.stage?'complete':i===r.stage?'current':''}"><span class="stage-circle">${i<r.stage?'✓':i+1}</span><div class="stage-copy"><strong>${s}</strong><p>${i<r.stage?'该模拟阶段已走完，非实际执行证据':i===r.stage?'当前演示阶段':'等待前序模拟阶段'}</p></div></li>`).join('')}</ol>${historical?'<div class="notice">你正在查看历史尝试，仅供回顾，不可继续处理。</div>':`<div class="action-row">${action}${['FAILED','CANCELLED'].includes(r.status)?'<button class="button primary" data-command="retry">创建新尝试</button>':''}</div>${isActive(r)?`<div class="sub-actions"><button class="text-button" data-command="cancel">取消这次模拟</button>${r.status==='RUNNING'?'<button class="text-button" data-command="fail">模拟环境故障</button>':''}</div>`:''}`}`;
}
function decisionBody(t,r,historical){
 const c=capabilities[t.kind];
 if(r.answer){const choice=c.choices.find(x=>x[0]===r.answer);return `<div class="notice success"><strong>已记录本次合成澄清</strong>${choice[1]}。仅适用于当前演示尝试，不构成正式审批或跨项目规则。</div><button class="button" data-tab="progress">返回处理进度</button>`;}
 if(r.status!=='WAITING_FOR_USER'||historical)return '<div class="empty"><p>该尝试没有可处理的澄清事项。</p><span>取消或被新尝试替代的问题不能继续回答。</span></div>';
 return `<div class="notice warning"><strong>业务澄清，不是正式审批</strong>回答仅绑定 ${esc(r.id)}，不会改变其他任务或真实项目。</div><h2>${c.question}</h2><p class="dim spaced">${c.questionHint}</p><form class="decision-form" id="decision-form" data-task="${esc(t.id)}" data-run="${esc(r.id)}">${c.choices.map(x=>`<label class="decision-option"><input type="radio" name="answer" value="${x[0]}" required><span><strong>${x[1]}</strong><small>${x[2]}</small></span></label>`).join('')}<div class="action-row"><button class="button primary" type="submit">确认并继续模拟</button></div></form>`;
}
function deliveryContract(t){
 const rows=t.kind==='listing'?[
 ['单文件 R','目标程序交付','自包含，不依赖 DSH / Node / 本机 source 脚本'],
 ['本地与服务器配置','目标配置交付','项目根、数据日、旧版日、输入输出分开绑定'],
 ['Excel / RDS','按 spec 定义的业务产物','不能固定为一个 sheet 或丢失 class / label'],
 ['需求映射与 QC 证据','独立检查记录','需求覆盖、连接基数、缺失 / 日期 / 精度、逐格读回'],
 ['异目录 / 服务器复跑','独立验收项','本地执行成功不能替代服务器复跑']
 ]:[
 ['公司模板草稿','8-sheet 规则工作簿','原型仅展示合同；真实工具写出始终为 CANDIDATE'],
 ['跨字段 / 字段级规则','规则 IR 与逐条诊断','不把 freeform 或 unresolved 算作解析成功'],
 ['正 / 反 / 恰边界用例','测试用例候选','TEST CASE 与 DM / DBD Comments 留空，由团队执行归档'],
 ['EDC 配置参考','通用表达式或 Rave 步骤','RENDER_REFERENCE_ONLY，复杂逻辑需人工确认']
 ];
 return `<h3>真实业务的交付清单 <span class="badge outline">本次均未实际生成</span></h3><div class="table-scroll spaced"><table><thead><tr><th>交付项</th><th>用途</th><th>验收边界</th></tr></thead><tbody>${rows.map(x=>`<tr>${x.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function resultsBody(t,r){
 const c=capabilities[t.kind];
 if(r.status!=='SUCCEEDED')return '<div class="empty"><p>当前尝试尚无候选结果。</p><button class="button" data-tab="progress">查看处理进度</button></div>';
 return `<div class="notice warning"><strong>合成候选，未经业务审核</strong>${c.limitation}</div><div class="artifact-box"><div class="section-heading"><h3>${c.artifact}</h3><span class="badge outline">说明文件 .md</span></div><p>内容包括合成输入、当前尝试、澄清选择、候选范围和未执行检查。不是实际程序、工作簿或审核凭据。</p><div class="action-row"><button class="button primary" data-download="${esc(t.id)}" data-run="${esc(r.id)}">${icon('download')} 下载合成说明</button></div></div>${deliveryContract(t)}<h3 class="spaced">结果与检查证据</h3><div class="evidence-list">${[['资料识别','合成示意','使用预设文件名和资料角色，未解析真实文件。'],[t.kind==='listing'?'程序执行':'规则校验','未执行',t.kind==='listing'?'未运行 R、未复跑服务器、未执行业务 QC。':'未执行 fire-when 校验或测试用例，未配置生产 EDC。'],['业务审核','未审核','没有正式审批、签名或业务验收记录。']].map(x=>`<div class="evidence-row">${icon('info')}<div><h3>${x[0]} <span class="badge outline">${x[1]}</span></h3><p>${x[2]}</p></div></div>`).join('')}</div>`;
}
function domainReview(t){
 const listing=t.kind==='listing';
 const scopeNotes={manual:'Manual：区分行条件、输出列与人工核查说明；人工说明不自动编为异常规则。',medical:'Medical：复用 Manual 的需求识别核心，医学核查内容及输出仍以本项目 spec 为准。','pk-be':'PK BE：核对周期、序列 / 处理、周期内给药参照和多工件；不能无条件套用 SAD/MAD。','pk-sad':'PK SAD/MAD：核对队列、名义日小时、多剂给药参照、基质和盲态适用条件。',report:'Report：入口与工具可复用，但成熟实战证据不足，业务验收需独立建立。'};
 const scopeNote=listing?scopeNotes[t.scene]:'DVP：公司模板结构与 EDC 无关规则 IR 分离；Rave 风格字段不能直接假定在其他 EDC 同构。';
 const rows=listing?[
 ['需求来源','合成 spec / DM_01 / 第 8 行','需保留来源坐标与需求版本'],
 ['行逻辑','全部适用记录 + 重复标记','flag=duplicated 不自动转为行过滤'],
 ['输出与关联','按 spec 列序、粒度和 ALS 映射','不得凭相似字段猜测；检查连接基数'],
 ['QC 合同','Excel 逐格；RDS 列序 / class / label / 缺失','独立 QC，不用生成代码自证'],
 ['服务器交付','单文件自包含 R + 本地 / 服务器配置','异目录复跑证据独立记录，原型未执行']
 ]:[
 ['跨字段规则','Edit Checks / SYN_EC_001','fire when VALUE > 10；完全虚构字段与阈值'],
 ['字段级规格','Edit Checks(Field Level)','IsRequired / IsLog / QueryFutureDate / QueryNonConformance'],
 ['规则类型','Date / Custom / Missing / Range','Query Type 非枚举值报诊断，不猜测'],
 ['用例候选','正例 11 / 反例 9 / 边界 10','仅说明候选设计，不代表已经执行'],
 ['人工与动态','Manual Review / Dynamic','无法解析逻辑保留 unresolved，交 DM 确认'],
 ['EDC 参考','通用表达式 / Rave 步骤','RENDER_REFERENCE_ONLY，不写生产 EDC']
 ];
 return `<div class="notice"><strong>${listing?'当前 Listing 场景':'当前 DVP 范围'}</strong>${esc(scopeNote)}</div><h3>${listing?'需求理解与交付合同':'规则与用例工作区'} <span class="badge outline">合成内容</span></h3><div class="table-scroll spaced"><table><thead><tr><th>业务环节</th><th>示例内容</th><th>处理要求</th></tr></thead><tbody>${rows.map(x=>`<tr>${x.map(y=>`<td>${esc(y)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="notice spaced"><strong>按现有插件能力设计，不把目标当作已完成</strong>${listing?'现有入口支持 overview / read_sheet / describe_dataset、知识检索与合成执行。通用项目级 R 执行、独立 QC 和服务器交付按目标呈现，本原型不证明整条链路已验收。':'现有工具提供 PDF 文本读取、模板 IR、规则诊断、用例候选、8-sheet 草稿写出与 EDC 参考。不是已验证的任意方案一键生成，TEST CASE / DM / DBD Comments 保持留空，由团队执行归档。'}</div>`;
}
function inputsBody(t){const c=capabilities[t.kind];const context=t.context||{};return `<div class="notice"><strong>资料快照 · 合成</strong>${t.kind==='listing'?`本地目录：${esc(context.root||'D:/Clinical/SYN-101')}<br>数据批次：${esc(context.batch||'2026-11-01')}<br>服务器根：${esc(context.server||'未配置')}`:`方案：${esc(context.protocol||'V1.0')} / 公司模板：${esc(context.template||'V2.0')}`}（均为虚构，未访问）。${t.kind==='listing'?'本地目录、数据批次、服务器路径分别绑定，不从 cwd 猜项目。':'先分类模板 sheet，再读取允许内容；扫描件返回 NEEDS_OCR，不假装已提取文本。'} 创建后不静默改变输入。</div>`+`<h3>${esc(t.project)}</h3><div class="evidence-list">${t.files.map(i=>c.files[i]).map(f=>`<div class="evidence-row">${icon('file')}<div><h3 class="file-name">${f[0]}</h3><p>${f[1]} / ${f[2]}</p></div><span class="badge outline">合成</span></div>`).join('')}</div>`;}
function renderDetail(){
 const t=state.tasks.find(x=>x.id===detailId);
 if(!t)return '<div class="empty"><h1>没有找到这个演示任务</h1><p>任务可能已被重置，请回到任务列表。</p><button class="button" data-route="tasks">返回我的任务</button></div>';
 const c=capabilities[t.kind];const r=t.runs.find(x=>x.id===viewedRun)||runOf(t);viewedRun=r.id;
 const historical=r.id!==t.currentRunId;
 const tabs=[['progress','处理进度'],['inputs','资料'],['business',t.kind==='listing'?'需求与 QC':'规则与用例'],['decision','待我处理'],['results','结果与检查'],['records','操作记录']];
 let body=detailTab==='business'?domainReview(t):detailTab==='inputs'?inputsBody(t):detailTab==='decision'?decisionBody(t,r,historical):detailTab==='results'?resultsBody(t,r):detailTab==='records'?r.events.map(e=>`<div class="record"><small>${stamp(e.at)} / 模拟记录</small>${esc(e.message)}</div>`).join(''):progressBody(t,r,historical);
 return `<button class="text-button back-link" data-route="tasks">‹ 返回我的任务</button><div class="detail-header"><div><h1>${esc(t.title)}</h1><div class="detail-meta"><span>${esc(t.id)}</span><span>${esc(t.project)}</span><span>创建于 ${stamp(t.createdAt)}</span></div></div>${badge(r.status)}</div><div class="detail-layout"><section class="panel"><div class="tabs" role="tablist" aria-label="任务详情">${tabs.map(([v,l])=>`<button id="tab-${v}" class="tab ${detailTab===v?'active':''}" role="tab" aria-selected="${detailTab===v}" aria-controls="task-panel" tabindex="${detailTab===v?'0':'-1'}" data-tab="${v}">${l}${v==='decision'&&r.status==='WAITING_FOR_USER'?' (1)':''}</button>`).join('')}</div><div class="detail-body" id="task-panel" role="tabpanel" aria-labelledby="tab-${detailTab}">${historical?'<div class="notice warning"><strong>历史尝试 · 只读</strong>这里的记录与当前尝试相互独立。</div>':''}${body}</div></section><aside class="detail-aside"><section class="panel"><div class="panel-heading"><h2>这项工作的上下文</h2></div><dl class="summary-list"><div><dt>业务能力</dt><dd>${c.name}</dd></div><div><dt>${c.sceneLabel}</dt><dd>${c.scenes.find(x=>x[0]===t.scene)?.[1]||'示例场景'}</dd></div><div><dt>当前查看的尝试</dt><dd><select id="run-select" aria-label="选择运行尝试">${t.runs.map((rr,i)=>`<option value="${esc(rr.id)}" ${rr.id===r.id?'selected':''}>第 ${i+1} 次 / ${statuses[rr.status][0]}${rr.id===t.currentRunId?'（当前）':''}</option>`).join('')}</select></dd></div><div><dt>交付状态</dt><dd><span class="badge waiting">${r.status==='SUCCEEDED'?'合成候选 · 未审核':'尚无当前产物'}</span></dd></div><div><dt>保存位置</dt><dd>${persistence?'仅本浏览器的演示缓存':'仅本页内存，未持久保存'}</dd></div></dl></section><div class="aside-note"><strong>平台管理业务，DSH 负责执行。</strong><br>此原型独立于 DSH，未接入执行引擎。后续通过版本化适配器接入，不依赖上游页面结构。</div></aside></div>`;
}
function render(){
 const pending=state.tasks.filter(t=>runOf(t).status==='WAITING_FOR_USER').length;
 $('#nav').innerHTML=navs.map(([id,label])=>`<a class="nav-item ${route===id?'active':''}" href="#${id}" ${route===id?'aria-current="page"':''}>${icon(id)}<span>${label}</span>${id==='pending'&&pending?`<span class="nav-count">${pending}</span>`:''}</a>`).join('');
 $('#breadcrumb').textContent=route==='detail'?'我的任务 / 任务详情':navs.find(n=>n[0]===route)?.[1]||'工作首页';
 $('#storage-warning').hidden=!storageIssue;$('#storage-warning').textContent=storageIssue;
 const pages={home:renderHome,tasks:renderTasks,pending:renderPending,project:renderProjects,artifacts:renderArtifacts,help:renderHelp,detail:renderDetail};
 $('#main').innerHTML=(pages[route]||renderHome)();
 document.title=`${route==='detail'?'任务详情':navs.find(n=>n[0]===route)?.[1]||'工作首页'} · 临床业务工作台原型`;
}
function navigate(target){window.location.hash=target;document.body.classList.remove('nav-open');$('#menu').setAttribute('aria-expanded','false');}
function parseRoute(){const hash=decodeURIComponent(location.hash.slice(1)||'home');const parts=hash.split('/');if(parts[0]==='task'){route='detail';detailId=parts[1]||'';detailTab=['progress','inputs','business','decision','results','records'].includes(parts[2])?parts[2]:'progress';if(parts[1]!==lastTask){viewedRun='';lastTask=parts[1];}}else{route=navs.some(n=>n[0]===hash)?hash:'home';}render();}
let lastTask='';
function openTask(id,tab='progress'){navigate(`task/${encodeURIComponent(id)}/${tab}`);if(location.hash===`#task/${encodeURIComponent(id)}/${tab}`)parseRoute();}
function openWizard(kind){dialogOpener=document.activeElement;wizardState={kind,step:0,context:{root:kind==='listing'?'D:/Clinical/SYN-101':'D:/Clinical/SYN-202',batch:'2026-11-01',server:'/clinical/SYN-101',protocol:'V1.0',template:'V2.0'},title:`${capabilities[kind].short} · 新建合成示例`,scene:capabilities[kind].scenes[0][0],files:capabilities[kind].files.map((_,i)=>i),confirmed:false,created:false};renderWizard();$('#wizard').showModal();}
function collectWizard(){if(!wizardState)return;for(const key of ['root','batch','server','protocol','template']){const field=$(`#context-${key}`);if(field)wizardState.context[key]=field.value;}const title=$('#task-title');const scene=$('#scene');if(title)wizardState.title=title.value;if(scene)wizardState.scene=scene.value;if($('#file-choices'))wizardState.files=[...$('#file-choices').querySelectorAll('input:checked')].map(x=>Number(x.value));if($('#synthetic-confirm'))wizardState.confirmed=$('#synthetic-confirm').checked;}
function renderWizard(){const w=wizardState,c=capabilities[w.kind];let body='';
 if(w.step===0)body=`<p>先选择业务场景，项目资料全部使用内置合成示例。</p><label class="field"><span>任务名称</span><input id="task-title" maxlength="80" required value="${esc(w.title)}"><small>给这项工作一个便于查找的名字。</small></label><label class="field"><span>合成项目</span><select aria-label="合成项目"><option>${c.project}</option></select></label><label class="field"><span>${c.sceneLabel}</span><select id="scene">${c.scenes.map(x=>`<option value="${x[0]}" ${w.scene===x[0]?'selected':''}>${x[1]}</option>`).join('')}</select></label>`;
 if(w.step===0)body+=w.kind==='listing'?`<div class="context-fields"><label class="field"><span>本地项目目录（虚构）</span><input id="context-root" value="${esc(w.context.root)}"><small>正式接入时由 DSH 扫描目录，员工不逐文件填写工具参数。本原型不访问该路径。</small></label><label class="field"><span>数据批次</span><select id="context-batch"><option ${w.context.batch==='2026-11-01'?'selected':''}>2026-11-01</option><option ${w.context.batch==='2026-10-01'?'selected':''}>2026-10-01</option></select><small>批次独立绑定，不跨批凑文件。</small></label><label class="field"><span>服务器项目根（虚构，可暂不填写）</span><input id="context-server" value="${esc(w.context.server)}"><small>本地成功不等于服务器复跑通过；不会自动同步目录。</small></label></div>`:`<div class="context-fields"><label class="field"><span>方案版本（合成）</span><input id="context-protocol" value="${esc(w.context.protocol)}"></label><label class="field"><span>公司模板版本（合成）</span><input id="context-template" value="${esc(w.context.template)}"></label><div class="notice">输入为方案 PDF 与公司模板；当前 EDC 选择是<strong>配置参考格式</strong>，不表示直接支持该系统生产写入。</div></div>`;
 if(w.step===0&&w.kind==='listing'&&w.scene==='report')body+='<div class="notice warning">Report 可选，但成熟实战证据少于 Manual / PK。不能因入口相同就视为业务成熟度相同。</div>';
 if(w.step===1)body=`<p>${w.kind==='listing'?'目录扫描结果示意：已识别 spec、ALS 和当前数据批次。':'方案与公司模板识别示意：PDF 文本层与规则 sheet 分类。'} 默认采用唯一候选；这里只操作合成选择，不读取文件。</p><div id="file-choices">${c.files.map((f,i)=>`<label class="file-choice"><input type="checkbox" value="${i}" ${w.files.includes(i)?'checked':''}><span><strong>${f[0]}</strong><small>${f[1]} / ${f[2]}</small></span></label>`).join('')}</div><div class="notice spaced">${w.kind==='dvp'?'DVP 演示不读取 Cover、签署内容或受试者信息。目标格式仅是配置参考，不写生产 EDC。':'真实项目应由平台识别资料角色；本页只演示交互，不执行任何资料读取。'}</div>`;
 if(w.step===2)body=`<p>确认资料角色后，创建一个可在本浏览器继续体验的模拟任务。</p><dl class="review-list"><dt>任务</dt><dd>${esc(w.title)}</dd><dt>项目</dt><dd>${c.project}</dd><dt>${c.sceneLabel}</dt><dd>${c.scenes.find(x=>x[0]===w.scene)[1]}</dd><dt>资料版本</dt><dd>${w.kind==='listing'?`目录 ${esc(w.context.root)}<br>数据批次 ${esc(w.context.batch)}<br>服务器 ${esc(w.context.server||'未配置')}`:`方案 ${esc(w.context.protocol)} / 模板 ${esc(w.context.template)}`}</dd><dt>资料识别</dt><dd>${w.files.map(i=>`${c.files[i][0]} → ${c.files[i][1]}`).join('<br>')}</dd><dt>预期产出</dt><dd>${c.artifact} / 候选、未审核</dd></dl><div class="notice warning">资料角色为内置示意；实际执行、规则校验及业务审核均不会发生。</div><label class="checkbox-confirm"><input id="synthetic-confirm" type="checkbox" ${w.confirmed?'checked':''}>我理解这是合成演示，不会生成可用于真实项目的交付物。</label>`;
 $('#wizard').innerHTML=`<div class="dialog-head"><div><h2 id="wizard-title">${c.name}</h2><p>合成示例向导 / 不接入真实业务插件</p></div><button class="icon-button" data-close-wizard aria-label="关闭向导">${icon('close')}</button></div><div class="wizard-steps">${['工作设置','选择资料','确认并创建'].map((l,i)=>`<div class="wizard-step ${i===w.step?'active':''}" ${i===w.step?'aria-current="step"':''}><span>${i+1}</span>${l}</div>`).join('')}</div><div class="wizard-body">${body}<div class="wizard-error" id="wizard-error" role="alert" hidden></div></div><div class="wizard-foot"><button class="button" ${w.step===0?'data-close-wizard':'data-wizard-back'}>${w.step===0?'取消':'上一步'}</button><small>仅本浏览器演示</small><button class="button primary" data-wizard-next>${w.step===2?'创建模拟任务':'下一步'} ${icon('arrow')}</button></div>`;
}
function wizardNext(){const w=wizardState;if(!w||w.created)return;collectWizard();let error='';if(w.step===0&&!w.title.trim())error='请输入任务名称，便于后续查找。';if(w.step===0&&w.kind==='listing'&&!w.context.root.trim())error='请填写演示项目目录；路径仅作为文本保存，不会被访问。';if(w.step===0&&w.kind==='dvp'&&(!w.context.protocol.trim()||!w.context.template.trim()))error='请填写方案与模板版本，便于绑定本次草稿来源。';if(w.step===1&&w.files.length!==capabilities[w.kind].files.length)error='这条演示路径需要全部示例资料，请勾选完整资料后继续。';if(w.step===2&&!w.confirmed)error='请先确认你理解合成演示的范围。';if(error){$('#wizard-error').textContent=error;$('#wizard-error').hidden=false;return;}if(w.step<2){w.step++;renderWizard();$('#wizard .wizard-body').setAttribute('tabindex','-1');$('#wizard .wizard-body').focus();return;}w.created=true;const id=`DEMO-${String(++state.seq).padStart(4,'0')}`;const r=seedRun(`${id}-R1`,'CREATED',0);r.events=[{at:now(),message:'创建模拟任务并保存合成资料选择。未调用 DSH。'}];state.tasks.unshift({id,title:w.title.trim(),kind:w.kind,context:{...w.context},project:capabilities[w.kind].project,scene:w.scene,files:[...w.files],createdAt:now(),currentRunId:r.id,runs:[r]});save();$('#wizard').close();wizardState=null;viewedRun=r.id;openTask(id);toast(`模拟任务 ${id} 已创建，未开始真实执行。`);}
function askConfirm(title,message,onConfirm,label='确认'){dialogOpener=document.activeElement;confirmAction=onConfirm;$('#confirm-dialog').innerHTML=`<div class="confirm-body"><h2 id="confirm-title">${esc(title)}</h2><p>${esc(message)}</p><div class="action-row"><button class="button" data-confirm-no>返回</button><button class="button primary" data-confirm-yes>${esc(label)}</button></div></div>`;$('#confirm-dialog').showModal();}
function command(action,stage){const t=state.tasks.find(x=>x.id===detailId);if(!t)return;const r=runOf(t);if(viewedRun&&viewedRun!==r.id){toast('历史尝试只读，请先切换到当前尝试。');return;}
 if(action==='cancel'){if(!isActive(r))return;const target=r.id;askConfirm('取消这次模拟？','这会终止当前演示尝试，其待确认问题将失效。不会删除历史记录，也没有真实进程需要终止。',()=>{if(runOf(t).id!==target||!isActive(r))return;r.status='CANCELLED';event(r,'操作者取消合成演示，待确认问题失效。');save();render();toast('本次模拟已取消。');},'取消模拟');return;}
 if(action==='retry'){if(!['FAILED','CANCELLED'].includes(r.status))return;const next=seedRun(`${t.id}-R${t.runs.length+1}`,'CREATED',0);next.events=[{at:now(),message:`由 ${r.id} 创建新模拟尝试，旧记录保留。`}];t.runs.push(next);t.currentRunId=next.id;viewedRun=next.id;detailTab='progress';toast('已创建新尝试，旧记录保留。');}
 else if(action==='start'&&r.status==='CREATED'){r.status='RUNNING';event(r,'开始手动合成流程；没有后台模型或程序执行。');}
 else if(action==='advance'&&r.status==='RUNNING'&&Number(stage)===r.stage){if(r.stage===0){r.stage=1;r.status='WAITING_FOR_USER';event(r,'合成资料存在歧义，等待操作者澄清。');}else if(r.stage===2){r.stage=3;event(r,'模拟准备候选说明；未执行程序或规则检查。');}else if(r.stage===3){r.stage=4;r.status='SUCCEEDED';event(r,'合成流程结束；候选说明可下载，未审核。');}else return;}
 else if(action==='fail'&&r.status==='RUNNING'){r.status='FAILED';event(r,'主动触发合成环境故障，无真实执行。');}
 else return;
 save();render();
}
function download(id,runId){const t=state.tasks.find(x=>x.id===id);const r=t?.runs.find(x=>x.id===runId);if(!t||!r||r.status!=='SUCCEEDED'){toast('该尝试还没有可下载的候选说明。');return;}const c=capabilities[t.kind];const choice=c.choices.find(x=>x[0]===r.answer);const text=`# ${c.artifact}\n\n> 交互原型 / 完全合成 / 未真实执行 / 未经业务审核\n\n任务：${t.id}\n尝试：${r.id}\n名称：${t.title}\n项目：${t.project}\n\n## 合成资料\n${t.files.map(i=>'- '+c.files[i][0]+'（仅示例名称）').join('\n')}\n\n## 澄清示意\n${choice?.[1]||'无'}。只适用于本演示，不构成正式批准。\n\n## 候选范围\n${c.limitation}\n\n## 检查证据\n- 文件识别：预设示意，未解析真实文件。\n- 程序/规则执行：未执行。\n- 服务器复跑：未执行。\n- 业务审核：未审核。\n- 生产 EDC：未接入。\n\n这是 Markdown 说明，不是实际 R 程序、DVP 工作簿、验证报告或电子签名。不得用于真实临床项目。\n`;const blob=new Blob([text],{type:'text/markdown;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`${t.id}-${r.id.split('-').pop()}-SYNTHETIC-NOT-VALIDATED.md`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('已下载合成说明，不是实际程序或工作簿。');}

document.addEventListener('click',e=>{
 const navigationLink=e.target.closest('#nav a,.brand');
 if(navigationLink){document.body.classList.remove('nav-open');$('#menu').setAttribute('aria-expanded','false');}
 const b=e.target.closest('button,[data-route]');if(!b)return;
 if(b.dataset.route){navigate(b.dataset.route);return;}
 if(b.dataset.new){openWizard(b.dataset.new);return;}
 if(b.dataset.about){navigate('help');return;}
 if(b.dataset.open){openTask(b.dataset.open);return;}
 if(b.dataset.decision){openTask(b.dataset.decision,'decision');return;}
 if(b.dataset.filter){listFilter=b.dataset.filter;render();return;}
 if(b.dataset.tab){detailTab=b.dataset.tab;render();$(`#tab-${detailTab}`)?.focus();return;}
 if(b.dataset.command){command(b.dataset.command,b.dataset.stage);return;}
 if(b.dataset.download){download(b.dataset.download,b.dataset.run);return;}
 if(b.hasAttribute('data-close-wizard')){$('#wizard').close();return;}
 if(b.hasAttribute('data-wizard-next')){wizardNext();return;}
 if(b.hasAttribute('data-wizard-back')){collectWizard();wizardState.step--;renderWizard();return;}
 if(b.hasAttribute('data-confirm-no')){confirmAction=null;$('#confirm-dialog').close();return;}
 if(b.hasAttribute('data-confirm-yes')){const act=confirmAction;confirmAction=null;$('#confirm-dialog').close();act?.();return;}
 if(b.id==='menu'){const open=document.body.classList.toggle('nav-open');b.setAttribute('aria-expanded',String(open));return;}
 if(b.id==='reset'){askConfirm('重置全部演示数据？','仅清除此原型的浏览器记录并恢复两个预置任务，不影响真实插件、DSH 或其他应用。',()=>{state=freshState();persistence=true;storageIssue='';save();navigate('home');render();toast('已恢复合成演示。');},'重置演示');}
});
document.addEventListener('input',e=>{if(e.target.id==='task-search'){searchQuery=e.target.value;const start=e.target.selectionStart;render();$('#task-search').focus();$('#task-search').setSelectionRange(start,start);}});
document.addEventListener('change',e=>{if(e.target.id==='scene'&&wizardState){collectWizard();renderWizard();$('#scene').focus();}if(e.target.id==='run-select'){viewedRun=e.target.value;render();}});
document.addEventListener('submit',e=>{if(e.target.id!=='decision-form')return;e.preventDefault();const t=state.tasks.find(x=>x.id===e.target.dataset.task);if(!t)return;const r=runOf(t);const answer=new FormData(e.target).get('answer');if(r.id!==e.target.dataset.run||r.status!=='WAITING_FOR_USER'||!capabilities[t.kind].choices.some(x=>x[0]===answer)){toast('该问题已失效，请打开当前任务。');return;}r.answer=answer;r.stage=2;r.status='RUNNING';event(r,`合成澄清已记录：${capabilities[t.kind].choices.find(x=>x[0]===answer)[1]}。非正式审批。`);save();detailTab='progress';render();toast('澄清已记录，可以继续模拟。');});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('nav-open')){document.body.classList.remove('nav-open');$('#menu').setAttribute('aria-expanded','false');$('#menu').focus();}if(e.target.matches('[role="tab"]')&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const tabs=[...document.querySelectorAll('[role="tab"]')];const i=tabs.indexOf(e.target);const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next].click();}});
for(const d of [$('#wizard'),$('#confirm-dialog')])d.addEventListener('close',()=>{if(d.id==='wizard')wizardState=null;if(d.id==='confirm-dialog')confirmAction=null;if(dialogOpener?.isConnected)dialogOpener.focus();});
window.addEventListener('hashchange',()=>{document.body.classList.remove('nav-open');$('#menu').setAttribute('aria-expanded','false');try{parseRoute();}catch(error){navigate('home');toast('链接格式无效，已返回首页。');}$('#main').focus();});
window.addEventListener('storage',e=>{if(e.key===KEY){persistence=false;storageIssue='另一个标签页修改了演示记录。本页已停止写入缓存；刷新可载入新状态。原型不提供多人或多标签页协同。';render();}});
try{parseRoute();}catch(error){location.hash='home';route='home';render();toast('链接格式无效，已返回首页。');}
