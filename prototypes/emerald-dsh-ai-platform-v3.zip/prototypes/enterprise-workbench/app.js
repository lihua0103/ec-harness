'use strict';
// Presentation prototype only: no DSH/model/API calls and no file-content reads.
const KEY = 'emerald.dsh.platform.prototype.v3';
const $ = selector => document.querySelector(selector);
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icons = {
 workspace:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18M9 9v11"/>',
 projects:'<path d="M3 7h7l2-3h8v16H3zM3 9h17"/>',
 tasks:'<rect x="5" y="4" width="15" height="17" rx="2"/><path d="M9 3h7M9 10h7m-7 4h7m-7 4h4"/>',
 applications:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 results:'<path d="M4 8h16v13H4zM3 4h18v4H3zM9 12h6"/>',
 settings:'<circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>',
 listing:'<path d="M5 3h10l4 4v14H5zM15 3v5h4M8 11h8m-8 4h8m-8 3h5"/>',
 dvp:'<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6z"/><path d="m8 12 3 3 5-6"/>',
 file:'<path d="M6 3h9l4 4v14H6zM15 3v5h4"/>',
 attach:'<path d="m9 14 7-7a3 3 0 0 1 4 4l-9 9a5 5 0 0 1-7-7L14 3m-7 13 9-9"/>',
 arrow:'<path d="M12 20V4m-6 6 6-6 6 6"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.file}</svg>`;
// User-confirmed business taxonomy. Internal method variants are not UI categories.
const LISTING_TYPES = ['Manual', 'Medical', 'PK', 'Report'];
const APPS = {
 listing: {name:'Listing 开发',description:'基于项目资料，协助理解需求、编写程序、诊断运行和整理交付。',placeholder:'例如：根据项目中的 Listing spec 和 ALS，完成本次 Manual Listing。先梳理需求与数据来源，有不明确的地方再向我确认。',output:['R 程序','Excel / RDS','QC 记录'],sampleRequest:'根据项目中的 spec 和 ALS，开发本次 Listing。先说明需求理解和处理计划，遇到不明确的业务要求向我确认。',files:[{name:'Listing_spec_V2.0.xlsx',role:'需求规格'},{name:'ALS_V1.0.xlsx',role:'结构定义'},{name:'SAS_20261101.zip',role:'数据批次'}]},
 dvp: {name:'DVP 编制',description:'基于方案和公司模板，协助整理规则草稿、诊断问题和准备测试用例。',placeholder:'例如：根据方案 PDF 和公司 DVP 模板编制规则草稿。保留规则来源，把需要人工确认的内容单独列出。',output:['DVP 草稿','规则诊断','用例候选'],sampleRequest:'根据方案 PDF 和公司 DVP 模板，准备 DVP 草稿及测试用例候选。标明规则来源和待确认项，不自行补全不明确的要求。',files:[{name:'Protocol_V1.0.pdf',role:'方案'},{name:'Company_DVP_V2.0.xlsx',role:'公司模板'}]}
};
const NAV = [['workspace','AI 工作区'],['projects','项目空间'],['tasks','工作记录'],['applications','应用中心'],['results','成果文件'],['settings','平台设置']];
let memoryOnly = false;
let warning = '';
let view = 'workspace';
let activeTaskId = null;
let taskFilter = 'all';
let search = '';
let dialogOpener = null;
let toastTimer;
function freshState(){return {version:3,revision:0,projects:[{id:'P001',name:'临床项目示例',code:'SYN-001',directory:'D:/Clinical/SYN-001',batch:'2026-11-01',server:''}],tasks:[],draft:{app:'listing',type:'Manual',projectId:'P001',prompt:'',files:[]}};}
function validFile(file){return file&&typeof file.name==='string'&&file.name.length<=255&&typeof file.role==='string'&&file.role.length<=80&&['sample','local'].includes(file.source);}
function validSelection(item){return item&&Object.hasOwn(APPS,item.app)&&LISTING_TYPES.includes(item.type)&&typeof item.projectId==='string';}
function validState(value){
 if(!value||value.version!==3||!Number.isInteger(value.revision)||!Array.isArray(value.projects)||!value.projects.length||value.projects.length>100||!Array.isArray(value.tasks)||value.tasks.length>200)return false;
 const projectIds=new Set();
 if(!value.projects.every(p=>p&&typeof p.id==='string'&&!projectIds.has(p.id)&&(['id','name','code','directory','batch','server'].every(k=>typeof p[k]==='string'&&p[k].length<=1000))&&(projectIds.add(p.id),true)))return false;
 const draft=value.draft;
 if(!validSelection(draft)||!projectIds.has(draft.projectId)||typeof draft.prompt!=='string'||draft.prompt.length>10000||!Array.isArray(draft.files)||draft.files.length>30||!draft.files.every(validFile))return false;
 const ids=new Set();
 return value.tasks.every(t=>t&&validSelection(t)&&projectIds.has(t.projectId)&&typeof t.id==='string'&&!ids.has(t.id)&&(ids.add(t.id),true)&&typeof t.title==='string'&&t.title.length<=120&&typeof t.request==='string'&&t.request.length<=10000&&['draft','sample','stopped'].includes(t.status)&&Number.isFinite(Date.parse(t.createdAt))&&Array.isArray(t.files)&&t.files.length<=30&&t.files.every(validFile)&&Array.isArray(t.messages)&&t.messages.length<=100&&t.messages.every(m=>['user','assistant'].includes(m.role)&&typeof m.text==='string'&&m.text.length<=12000));
}
function load(){try{const raw=localStorage.getItem(KEY);if(raw){const value=JSON.parse(raw);if(!validState(value))throw Error('INVALID');return value;}}catch(error){memoryOnly=true;warning='浏览器记录不可用，当前仅在本页保留。原记录不会被覆盖，可在平台设置中重置。';}return freshState();}
let state=load();
function persist(){state.revision++;if(!memoryOnly)try{localStorage.setItem(KEY,JSON.stringify(state));}catch(error){memoryOnly=true;warning='无法保存到浏览器，本页可继续使用，刷新后可能丢失更改。';}}
function toast(text){$('#toast').textContent=text;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{$('#toast').hidden=true;},4000);}
function currentTask(){return state.tasks.find(t=>t.id===activeTaskId);}
function selection(){return currentTask() || state.draft;}
function projectFor(item=selection()){return state.projects.find(p=>p.id===item.projectId)||state.projects[0];}
function status(task){return task.status==='sample'?'<span class="status-badge result">结果样式已预览</span>':task.status==='stopped'?'<span class="status-badge stopped">已归档</span>':'<span class="status-badge attention">待接入 DSH · 未执行</span>';}
function navigate(target){location.hash=target;closeMenu();}
function openTask(id){navigate(`work/${encodeURIComponent(id)}`);}
function closeMenu(){document.body.classList.remove('nav-open');$('.menu-button').setAttribute('aria-expanded','false');}
function savePrompt(){const field=$('#prompt');if(field){if(currentTask())currentTask().replyDraft=field.value;else state.draft.prompt=field.value;}}
function draftFiles(item=selection()){return item.files||[];}
function makeComposer(thread=false){
 const item=selection();const task=currentTask();const value=task?(task.replyDraft||''):state.draft.prompt;
 return `<form id="work-form" class="${thread?'thread-composer':''}">${!thread?`<div class="app-switch" aria-label="选择应用">${Object.entries(APPS).map(([id,a])=>`<button type="button" class="app-button ${item.app===id?'active':''}" data-app="${id}" aria-pressed="${item.app===id}">${icon(id)}${a.name}</button>`).join('')}</div>${item.app==='listing'?`<div class="scope-line"><span class="scope-label">Listing 类型</span><div class="type-options" aria-label="Listing 类型">${LISTING_TYPES.map(type=>`<button type="button" class="type-button ${item.type===type?'active':''}" data-type="${type}" aria-pressed="${item.type===type}">${type}</button>`).join('')}</div></div>`:'<div class="scope-line"><span class="scope-label">使用项目方案与公司模板，生成内容保留为待审核草稿。</span></div>'}`:''}<div class="composer"><textarea id="prompt" aria-label="${thread?'补充工作要求':'描述工作要求'}" maxlength="10000" placeholder="${escapeHtml(thread?'补充要求、说明修改意见，或向 AI 提问…':APPS[item.app].placeholder)}">${escapeHtml(value)}</textarea><div id="prompt-error" class="inline-error" role="alert" hidden></div><div class="composer-footer"><div class="composer-tools"><button type="button" class="attach-button" data-action="attach">${icon('attach')} 添加资料</button><button type="button" class="text-button" data-action="samples">使用示例资料</button></div><button type="submit" class="button primary">${thread?'发送补充':'提交工作'} ${icon('arrow')}</button></div></div><p class="composer-hint">${thread?'补充内容保存在本项工作中。':'选择项目、提供资料，直接描述你要完成的工作。'} 当前 DSH 未接入，只保存草稿并展示预设方案。</p></form>`;
}
function resourcePanel(){
 const item=selection(),project=projectFor(item),task=currentTask();
 return `<aside class="resource-panel" aria-label="资料与成果"><div class="resource-head"><h2>工作资料 <span class="muted">${item.files.length||''}</span></h2><button class="text-button" data-action="attach">添加</button></div><p class="resource-intro">${item.app==='listing'?'需求规格、ALS 与本次数据批次':'方案 PDF 与公司 DVP 模板'}。本原型只记录文件名，不读取内容。</p>${item.files.length?item.files.map((file,i)=>`<div class="file-row">${icon('file')}<div class="file-copy"><div class="file-name">${escapeHtml(file.name)}</div><small>${escapeHtml(file.role)} · ${file.source==='sample'?'示例':'仅文件名'}</small></div>${task?'':`<button class="remove-file" data-remove="${i}" aria-label="移除 ${escapeHtml(file.name)}">×</button>`}</div>`).join(''):`<div class="resource-empty">${icon('file')}尚未添加工作资料<br><button class="text-button" data-action="samples">载入示例资料</button></div>`}<div class="resource-section"><div class="resource-head"><h3>项目上下文</h3><button class="text-button" data-action="project-settings">查看</button></div><dl class="project-details"><dt>项目</dt><dd>${escapeHtml(project.code)}</dd><dt>目录</dt><dd>${escapeHtml(project.directory||'未设置')}</dd>${item.app==='listing'?`<dt>批次</dt><dd>${escapeHtml(project.batch||'未设置')}</dd>`:''}<dt>范围</dt><dd>${APPS[item.app].name}${item.app==='listing'?' / '+escapeHtml(item.type):''}</dd></dl></div><div class="resource-section"><h3>${task?.status==='sample'?'成果预览':'预期成果'}</h3><p>${task?.status==='sample'?'当前只有结果样式示意，没有实际生成业务文件。':'结果将与当前工作关联，不必到聊天记录里寻找附件。'}</p><div class="output-types">${APPS[item.app].output.map(x=>`<span>${x}</span>`).join('')}</div>${task?.status==='sample'?`<button class="text-button" data-download="${escapeHtml(task.id)}">下载原型说明 .md</button>`:''}</div><div class="engine-disclaimer">${icon('info')}<span>原型环境<br>不上传文件，不调用模型；示例结果不是业务交付。</span></div></aside>`;
}
function planContent(task){
 const listing=task.app==='listing';
 const rows=listing?[
 ['理解资料','结合 spec、ALS 和数据批次梳理需求，保留来源与待确认事项。'],
 ['开发与处理','依据当前需求组织 R 程序，执行后根据诊断修正，不让员工逐步驱动工具。'],
 ['检查与交付','分别呈现程序、业务产物、独立 QC 和服务器复跑状态，不以“生成成功”代替验收。']
 ]:[
 ['理解方案与模板','读取允许的方案文本和模板内容，保留规则来源，不猜测缺失的业务要求。'],
 ['编制与诊断','组织规则草稿与正反边界用例；无法解析或不明确的项交给项目团队确认。'],
 ['整理候选成果','呈现 DVP 草稿、诊断与用例候选，EDC 配置内容仅作参考。']
 ];
 return `<div class="plan-card"><h2>工作方案</h2><p>已保存你的要求和资料选择。下面是原型预设方案，尚未由 DSH 分析或执行。</p><div class="plan-list">${rows.map(([title,body])=>`<div class="plan-row">${icon('check')}<div><strong>${title}</strong><br>${body}</div></div>`).join('')}</div><div class="plan-actions"><button class="button primary" data-preview="${escapeHtml(task.id)}">查看结果样式</button><small>不启动真实任务，仅预览界面</small></div></div>`;
}
function exampleResults(task){
 const listing=task.app==='listing';
 return `<div class="plan-card"><h2>结果样式预览</h2><p>这一区域将承载实际工作成果。以下是合成示意，不存在可执行程序或工作簿文件。</p>${(listing?[['Listing 程序','R 单文件程序 · 待真实生成'],['Listing 数据输出','Excel / RDS · 待真实执行'],['检查与复跑记录','独立 QC / 服务器复跑 · 未执行']]:[['DVP 规则草稿','公司模板工作簿 · 待真实生成'],['规则诊断与待确认项','规则解释和来源 · 合成示意'],['测试用例候选','正例、反例、边界 · 未执行']]).map(([title,subtitle])=>`<div class="result-item">${icon('file')}<div><h3>${title}</h3><small>${subtitle}</small></div><span class="status-badge">未生成</span></div>`).join('')}<div class="inline-note">${listing?'程序生成、实际执行、独立 QC 和服务器复跑分别记录，不能合并成一个“完成”。':'草稿与测试用例均为候选；公司流程中的审核、UAT 和归档不由预览按钮代替。'}</div><div class="plan-actions"><button class="button" data-download="${escapeHtml(task.id)}">下载原型说明 .md</button><small>不是 R 程序、Excel 或验证报告</small></div></div>`;
}
function renderWorkspace(){
 const task=currentTask(),item=selection();
 return `<div class="workspace"><section class="conversation" aria-label="AI 工作区"><div class="context-bar"><div class="context-project">${icon('projects')}<label><span class="skip-link">当前项目</span><select id="project-select" aria-label="当前项目" ${task?'disabled':''}>${state.projects.map(p=>`<option value="${escapeHtml(p.id)}" ${item.projectId===p.id?'selected':''}>${escapeHtml(p.name)} / ${escapeHtml(p.code)}</option>`).join('')}</select></label></div><span class="context-tag">${task?'工作上下文已绑定':'项目资料与工作相互关联'}</span></div>${task?`<div class="thread-heading"><h1>${escapeHtml(task.title)}</h1><p>${escapeHtml(projectFor(task).code)} / ${APPS[task.app].name}${task.app==='listing'?' / '+escapeHtml(task.type):''} / ${escapeHtml(task.id)}</p><div class="thread-tools">${status(task)}<button class="text-button" data-action="new-task">新建工作</button>${task.status!=='stopped'?`<button class="text-button" data-archive="${escapeHtml(task.id)}">归档</button>`:''}</div></div><div class="thread">${task.messages.map((m,i)=>`<article class="message ${m.role}"><span class="message-avatar">${m.role==='user'?'我':'AI'}</span><div class="message-body"><div class="message-meta"><strong>${m.role==='user'?'你':'DSH 助手'}</strong>${m.role==='assistant'?'原型预设内容':''}</div><div class="message-content">${escapeHtml(m.text)}</div>${m.role==='assistant'&&i===1?planContent(task):''}</div></article>`).join('')}${task.status==='sample'?`<article class="message"><span class="message-avatar">AI</span><div class="message-body"><div class="message-meta"><strong>成果区</strong>界面示意</div>${exampleResults(task)}</div></article>`:''}</div>${task.status==='stopped'?'<div class="inline-note">这项工作已归档，记录保留。可从左侧新建工作继续。</div>':makeComposer(true)}`:`<div class="welcome"><h1>今天，需要 AI 协助什么工作？</h1><p>在项目中开展 Listing 开发与 DVP 编制。资料、沟通和成果，留在同一个工作空间。</p></div>${makeComposer()}<div class="suggestions">${item.app==='listing'?`<button class="suggestion" data-suggestion="requirements"><span>先梳理需求</span>理解 spec、ALS 与数据来源，列出待确认事项</button><button class="suggestion" data-suggestion="develop"><span>开始 Listing 开发</span>按当前项目需求编程，并整理检查与交付记录</button>`:`<button class="suggestion" data-suggestion="rules"><span>准备 DVP 草稿</span>结合方案与公司模板，整理规则及来源</button><button class="suggestion" data-suggestion="cases"><span>准备测试用例</span>为已有规则设计正例、反例与边界用例</button>`}</div><p class="workspace-footnote">项目保存工作上下文，沟通和成果始终关联当前工作。</p>`}</section>${resourcePanel()}</div>`;
}
function renderTasks(){
 const tasks=state.tasks.filter(t=>(taskFilter==='all'||t.app===taskFilter)&&`${t.title} ${t.request} ${projectFor(t).name}`.toLowerCase().includes(search.toLowerCase()));
 return `<div class="view-page"><div class="page-heading"><div><h1>工作记录</h1><p>按项目保留要求、沟通和成果，随时回到工作上下文。</p></div><button class="button primary" data-action="new-task">新建工作</button></div><div class="toolbar"><div class="filters">${[['all','全部'],['listing','Listing'],['dvp','DVP']].map(([v,label])=>`<button class="filter ${taskFilter===v?'active':''}" data-filter="${v}" aria-pressed="${taskFilter===v}">${label}</button>`).join('')}</div><input class="search" id="search" aria-label="搜索工作" value="${escapeHtml(search)}" placeholder="搜索工作要求或项目"></div><div class="table-wrap"><table><thead><tr><th>工作</th><th>项目</th><th>应用 / 类型</th><th>状态</th><th>操作</th></tr></thead><tbody>${tasks.map(t=>`<tr><td><button class="table-link" data-open="${escapeHtml(t.id)}">${escapeHtml(t.title)}</button><small>${escapeHtml(t.id)}</small></td><td>${escapeHtml(projectFor(t).code)}</td><td>${APPS[t.app].name}${t.app==='listing'?' / '+escapeHtml(t.type):''}</td><td>${status(t)}</td><td><button class="text-button" data-open="${escapeHtml(t.id)}">继续查看</button></td></tr>`).join('')}</tbody></table>${!tasks.length?'<div class="empty">暂无工作记录，选择项目后直接描述你的要求。<br><button class="button" data-action="new-task">前往 AI 工作区</button></div>':''}</div></div>`;
}
function renderProjects(){return `<div class="view-page"><div class="page-heading"><div><h1>项目空间</h1><p>项目统一管理目录与数据上下文，不在每次工作中重复填写。</p></div><button class="button primary" data-action="add-project">新建项目</button></div><div class="project-grid">${state.projects.map(p=>`<section class="project-card"><span class="status-badge">${escapeHtml(p.code)}</span><h2>${escapeHtml(p.name)}</h2><p>原型项目，仅保存配置文本，不访问目录。</p><dl class="project-details"><dt>目录</dt><dd>${escapeHtml(p.directory||'未配置')}</dd><dt>批次</dt><dd>${escapeHtml(p.batch||'未配置')}</dd><dt>服务器</dt><dd>${escapeHtml(p.server||'未配置')}</dd></dl><div class="project-actions"><button class="button primary" data-project-work="${escapeHtml(p.id)}">进入工作区</button><button class="button" data-edit-project="${escapeHtml(p.id)}">项目设置</button></div></section>`).join('')}</div></div>`;}
function renderApplications(){return `<div class="view-page"><div class="page-heading"><div><h1>应用中心</h1><p>业务能力作为应用接入统一平台，不要求员工记住插件或工具名称。</p></div></div><div class="app-grid">${Object.entries(APPS).map(([id,a])=>`<section class="application-card"><span class="application-icon">${icon(id)}</span><h2>${a.name}</h2><p>${a.description}</p>${id==='listing'?`<div class="type-options">${LISTING_TYPES.map(t=>`<span class="status-badge">${t}</span>`).join('')}</div>`:'<div class="output-types"><span>方案</span><span>公司模板</span><span>规则与用例</span></div>'}<div class="version-note">界面已提供 · DSH 运行接入未完成</div><button class="button primary" data-launch="${id}">进入应用</button></section>`).join('')}</div></div>`;}
function renderResults(){const tasks=state.tasks.filter(t=>t.status==='sample');return `<div class="view-page"><div class="page-heading"><div><h1>成果文件</h1><p>每份成果关联项目与工作，不把生成、检查和审核混为同一状态。</p></div></div><div class="inline-note snapshot-note">原型环境：这里只能下载交互说明。尚未生成真实 R 程序、DVP 工作簿或 QC 报告。</div><div class="table-wrap"><table><thead><tr><th>关联工作</th><th>应用</th><th>文件状态</th><th>操作</th></tr></thead><tbody>${tasks.map(t=>`<tr><td>${escapeHtml(t.title)}<small>${escapeHtml(projectFor(t).code)}</small></td><td>${APPS[t.app].name}</td><td><span class="status-badge">示意内容 · 未实际生成</span></td><td><button class="text-button" data-download="${escapeHtml(t.id)}">下载原型说明</button></td></tr>`).join('')}</tbody></table>${!tasks.length?'<div class="empty">真实成果将在 DSH 接入并执行后产生。<br>可先在工作区预览结果呈现方式。</div>':''}</div></div>`;}
function renderSettings(){return `<div class="view-page"><div class="page-heading"><div><h1>平台设置</h1><p>业务平台独立维护，执行引擎通过适配层接入。</p></div></div><section class="settings-panel"><h2>执行引擎</h2><div class="settings-row"><div>DeepSeek Harness<p>当前未连接，不调用模型、不执行工具。</p></div><span class="status-badge attention">未接入</span></div><div class="settings-row"><div>接入方式<p>平台 → 版本化适配器 → 固定版本 DSH。升级先做兼容测试。</p></div><span class="status-badge">目标架构</span></div><p>连接参数、凭据和后端适配尚未实现。本原型不提供看似已保存、实际无效的连接开关。</p></section><section class="settings-panel"><h2>演示记录</h2><div class="settings-row"><div>保存位置<p>${memoryOnly?'当前页内存':'此浏览器专属缓存'}，不是企业服务端任务库，不支持多人协同。</p></div><button class="button" data-action="reset">重置原型</button></div></section><section class="settings-panel"><h2>品牌</h2><p>沿用 EMERALD CLINICAL TRIALS。当前 Logo 为依据提供图片重绘的矢量原型，正式使用需替换为批准的原始资产。</p></section></div>`;}
function render(){
 const task=currentTask();const navView=activeTaskId?'workspace':view;
 $('#nav').innerHTML=NAV.map(([id,label])=>`<a class="nav-item ${navView===id?'active':''}" href="#${id}" ${navView===id?'aria-current="page"':''}>${icon(id)}${label}</a>`).join('');
 $('#recent-tasks').innerHTML=state.tasks.length?state.tasks.slice(0,6).map(t=>`<button class="recent-item" data-open="${escapeHtml(t.id)}" title="${escapeHtml(t.title)}">${escapeHtml(t.title)}</button>`).join(''):'<span class="recent-empty">从一项新的工作开始</span>';
 $('#breadcrumb').textContent=task?`AI 工作区 / ${APPS[task.app].name}`:NAV.find(x=>x[0]===view)?.[1]||'AI 工作区';
 $('#storage-warning').textContent=warning;$('#storage-warning').hidden=!warning;
 const pages={workspace:renderWorkspace,projects:renderProjects,tasks:renderTasks,applications:renderApplications,results:renderResults,settings:renderSettings};
 $('#main').innerHTML=(pages[view]||renderWorkspace)();
 document.title=`${task?task.title:NAV.find(x=>x[0]===view)?.[1]||'AI 工作区'} · EMERALD DSH AI 平台`;
}
function route(){
 const parts=location.hash.slice(1).split('/');
 if(parts[0]==='work'){let id;try{id=decodeURIComponent(parts[1]||'');}catch(error){id='';}activeTaskId=state.tasks.some(t=>t.id===id)?id:null;view='workspace';if(!activeTaskId)toast('没有找到这项工作，已返回工作区。');}
 else{activeTaskId=null;view=NAV.some(x=>x[0]===parts[0])?parts[0]:'workspace';}
 closeMenu();render();
}
function newWork(app,projectId){savePrompt();activeTaskId=null;state.draft={app:app||state.draft.app,type:state.draft.type,projectId:projectId||state.draft.projectId,prompt:'',files:[]};persist();navigate('workspace');view='workspace';render();$('#prompt')?.focus();}
function openDialog(title,body,actions){dialogOpener=document.activeElement;$('#dialog').innerHTML=`<div class="dialog-head"><h2 id="dialog-title">${escapeHtml(title)}</h2><button class="icon-button" data-action="close-dialog" aria-label="关闭">${icon('close')}</button></div><div class="dialog-body">${body}</div>${actions?`<div class="dialog-actions">${actions}</div>`:''}`;$('#dialog').showModal();}
function showHelp(){openDialog('如何使用平台',`<p>先选择项目，再选择 Listing 开发或 DVP 编制；提供资料并描述要求，工作和沟通会保存在同一个上下文中。</p><p><strong>Listing 类型只有四种：</strong>Manual、Medical、PK、Report。不会把内部方法分类作为业务入口。</p><p>这是交互原型。提交工作只保存草稿并显示预设方案；“查看结果样式”展示合成界面，不表示 AI 已运行。添加文件只保存名称，不读取或上传内容。</p><p>正式接入后，AI 负责执行与诊断，需要业务判断时才询问员工。上游变更由适配层隔离，并经过兼容验证。</p>`,`<button class="button primary" data-action="close-dialog">知道了</button>`);}
function editProject(id){
 const p=state.projects.find(x=>x.id===id)||{name:'',code:'',directory:'',batch:'',server:''};
 openDialog(id?'项目设置':'新建项目',`<p>一次设置，工作中复用。原型只保存配置文本，不访问目录或服务器。</p><form id="project-form" data-id="${escapeHtml(id||'')}">${[['name','项目名称'],['code','项目编号'],['directory','本地项目目录'],['batch','数据批次'],['server','服务器项目根（选填）']].map(([key,label])=>`<label class="field"><span>${label}</span><input name="${key}" maxlength="500" value="${escapeHtml(p[key])}" ${['name','code'].includes(key)?'required':''}></label>`).join('')}<div id="project-error" class="dialog-error" role="alert" hidden></div><button class="button primary" type="submit">保存项目</button></form>`);
}
function attachSamples(){savePrompt();const item=selection();for(const f of APPS[item.app].files){if(!item.files.some(x=>x.name===f.name))item.files.push({...f,source:'sample'});}persist();render();toast('已添加示例资料名称，不读取任何文件。');}
function submitWork(event){
 event.preventDefault();const prompt=$('#prompt').value.trim();const item=selection();
 if(!prompt){$('#prompt-error').textContent='请描述你希望完成的工作。';$('#prompt-error').hidden=false;$('#prompt').focus();return;}
 if(currentTask()){
  const task=currentTask();if(task.status==='stopped')return;
  if(task.messages.length>=98){toast('原型单项工作消息已达上限，请新建工作。');return;}
  task.messages.push({role:'user',text:prompt},{role:'assistant',text:'补充要求已保存到当前工作。DSH 尚未接入，当前不会调用模型、执行修改或产生新业务结果。'});task.replyDraft='';persist();render();toast('补充已保存，尚未由 AI 执行。');return;
 }
 if(!item.files.length){$('#prompt-error').textContent='请添加工作资料，或点击“使用示例资料”体验。';$('#prompt-error').hidden=false;return;}
 if(state.tasks.length>=200){toast('原型记录已达上限，请在平台设置中重置。');return;}
 const id=`WORK-${Date.now()}-${Math.random().toString(36).slice(2,6)}`;
 const task={id,app:item.app,type:item.type,projectId:item.projectId,title:prompt.slice(0,42)+(prompt.length>42?'…':''),request:prompt,createdAt:new Date().toISOString(),files:item.files.map(f=>({...f})),status:'draft',messages:[{role:'user',text:prompt},{role:'assistant',text:`已保存这项${APPS[item.app].name}工作${item.app==='listing'?'，类型为 '+item.type:''}。当前未连接 DSH，下面仅展示预设工作方案。不会假报资料已分析或任务已执行。`} ]};
 state.tasks.unshift(task);state.draft.prompt='';persist();openTask(id);toast('工作草稿已保存，DSH 尚未执行。');
}
function download(id){
 const task=state.tasks.find(t=>t.id===id);if(!task||task.status!=='sample')return;
 const text=`# EMERALD DSH AI 平台原型说明\n\n> 界面预览，不是业务交付。未连接模型、未分析资料、未执行程序或规则检查。\n\n工作：${task.id}\n项目：${projectFor(task).name}\n应用：${APPS[task.app].name}${task.app==='listing'?' / '+task.type:''}\n\n## 工作要求\n${task.request}\n\n## 资料名称（内容未读取）\n${task.files.map(f=>'- '+f.name).join('\n')}\n\n## 状态\n本文件仅说明原型交互；R / Excel / DVP 工作簿未生成，QC / UAT / 服务器复跑未执行，业务未审核。\n`;
 const url=URL.createObjectURL(new Blob([text],{type:'text/markdown;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download=`${task.id}-PROTOTYPE-NOT-EXECUTED.md`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('已下载原型说明，不是实际业务文件。');
}

document.addEventListener('click',event=>{
 if(event.target.closest('#nav a,.brand')){savePrompt();persist();closeMenu();}
 const button=event.target.closest('button');if(!button)return;
 if(button.dataset.app){savePrompt();state.draft.app=button.dataset.app;state.draft.files=[];persist();render();return;}
 if(button.dataset.type){savePrompt();if(LISTING_TYPES.includes(button.dataset.type)){state.draft.type=button.dataset.type;persist();render();}return;}
 if(button.dataset.open){savePrompt();persist();openTask(button.dataset.open);return;}
 if(button.dataset.launch){newWork(button.dataset.launch);return;}
 if(button.dataset.projectWork){newWork(undefined,button.dataset.projectWork);return;}
 if(button.dataset.editProject){editProject(button.dataset.editProject);return;}
 if(button.dataset.remove!==undefined){savePrompt();if(!currentTask())state.draft.files.splice(Number(button.dataset.remove),1);persist();render();return;}
 if(button.dataset.filter){taskFilter=button.dataset.filter;render();return;}
 if(button.dataset.preview){const task=currentTask();if(task&&task.id===button.dataset.preview&&task.status!=='stopped'){task.status='sample';persist();render();toast('已展示合成结果样式，没有执行真实任务。');}return;}
 if(button.dataset.download){download(button.dataset.download);return;}
 if(button.dataset.archive){const task=currentTask();if(task){savePrompt();task.status='stopped';persist();render();toast('工作已归档，记录保留。');}return;}
 if(button.dataset.suggestion){const text={requirements:'请先梳理项目中的 Listing spec 和 ALS，说明数据来源、输出要求及需要确认的问题，暂不编程。',develop:APPS.listing.sampleRequest,rules:APPS.dvp.sampleRequest,cases:'请根据项目中已有的 DVP 规则，准备正例、反例和边界测试用例候选，列出无法确定的业务条件。'}[button.dataset.suggestion];state.draft.prompt=text;persist();$('#prompt').value=text;$('#prompt').focus();return;}
 const action=button.dataset.action;
 if(action==='new-task'){newWork();return;}
 if(action==='samples'){attachSamples();return;}
 if(action==='attach'){$('#file-picker').click();return;}
 if(action==='help'){showHelp();return;}
 if(action==='close-dialog'){$('#dialog').close();return;}
 if(action==='menu'){const open=document.body.classList.toggle('nav-open');$('.menu-button').setAttribute('aria-expanded',String(open));return;}
 if(action==='add-project'){if(state.projects.length>=100){toast('原型项目数量已达上限。');return;}editProject();return;}
 if(action==='project-settings'){editProject(projectFor().id);return;}
 if(action==='reset'){openDialog('重置原型记录？','<p>只清理这版原型的浏览器记录，不影响旧版缓存、真实插件或其他应用。</p>','<button class="button" data-action="close-dialog">保留记录</button><button class="button primary" data-action="confirm-reset">重置</button>');return;}
 if(action==='confirm-reset'){state=freshState();memoryOnly=false;warning='';persist();$('#dialog').close();activeTaskId=null;view='workspace';navigate('workspace');render();toast('原型记录已重置。');}
});
document.addEventListener('input',event=>{if(event.target.id==='prompt'){savePrompt();persist();}if(event.target.id==='search'){search=event.target.value;const start=event.target.selectionStart;render();$('#search').focus();$('#search').setSelectionRange(start,start);}});
document.addEventListener('change',event=>{
 if(event.target.id==='project-select'&&!currentTask()){savePrompt();state.draft.projectId=event.target.value;state.draft.files=[];persist();render();}
 if(event.target.id==='file-picker'){
  savePrompt();const item=selection();const files=[...event.target.files];
  for(const file of files){if(item.files.length>=30)break;if(!item.files.some(f=>f.name===file.name))item.files.push({name:file.name.slice(0,255),role:'待 AI 识别',source:'local'});}
  event.target.value='';persist();render();toast('仅记录文件名，未读取或上传内容。');
 }
});
document.addEventListener('submit',event=>{
 if(event.target.id==='work-form'){submitWork(event);return;}
 if(event.target.id==='project-form'){
  event.preventDefault();const form=event.target;const values=Object.fromEntries(new FormData(form));for(const key of Object.keys(values))values[key]=values[key].trim();
  if(!values.name||!values.code){$('#project-error').textContent='请填写项目名称和编号。';$('#project-error').hidden=false;return;}
  const duplicate=state.projects.some(p=>p.code===values.code&&p.id!==form.dataset.id);
  if(duplicate){$('#project-error').textContent='项目编号已存在，请使用其他编号。';$('#project-error').hidden=false;return;}
  const existing=state.projects.find(p=>p.id===form.dataset.id);if(existing)Object.assign(existing,values);else state.projects.push({id:`P-${Date.now()}`, ...values});
  persist();$('#dialog').close();render();toast('项目配置已保存，仅保存文本，未访问目录。');
 }
});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&document.body.classList.contains('nav-open')){closeMenu();$('.menu-button').focus();}if(event.target.id==='prompt'&&(event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();$('#work-form').requestSubmit();}});
$('#dialog').addEventListener('close',()=>{if(dialogOpener?.isConnected)dialogOpener.focus();});
window.addEventListener('hashchange',()=>{route();$('#main').focus();});
window.addEventListener('storage',event=>{if(event.key===KEY){memoryOnly=true;warning='其他标签页已更新记录。本页停止写入缓存，请刷新载入新状态。';render();}});
route();
