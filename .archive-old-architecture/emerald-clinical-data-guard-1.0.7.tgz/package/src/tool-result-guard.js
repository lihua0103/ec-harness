import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { basename, extname, resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { scanDlp, redactSensitiveText } from './patterns.js';
import { planeOf } from './planes.js';

// 临床 Listing 只有本地注册工具生成的收据可以走受控恢复通道。它们仍会先
// 进入出域检查，只是在扫描期间用随机令牌关联的固定占位替换。
// 2026-08-24 架构重设计：IR 车道（submit_plan/execute）退役，代码车道
// run_code（元数据信封，trusted）与 publish（REAL 收据，走投影）上线。
const CLINICAL_LISTING_TOOLS = new Set([
  'clinical_listing_inspect',
  'clinical_listing_run_code',
]);
const ALL_CLINICAL_LISTING_TOOLS = new Set([
  ...CLINICAL_LISTING_TOOLS,
  'clinical_listing_publish',
]);

const TRUSTED_LISTING_MARKERS = new Set([
  'CLINICAL_LISTING_INSPECTION',
  'CLINICAL_LISTING_PLAN_RECEIPT',
  // 代码车道 run 信封：聚合元数据（行数/列名/dtype/空值计数），字符串字段
  // 已在 Python 侧 scrub，ここ信任透传让 harness 能读懂迭代反馈。
  'CLINICAL_LISTING_CODE_RECEIPT',
]);

// 只有本地工作流生成的、可解析且形状完整的控制面收据才能进入恢复通道。
// 工具名本身不是信任证明：错误文本、伪造 marker 和 execute 的 REAL 收据都必须
// 继续经过普通出域扫描。
//
// allowed 是闭集：多一个未知键即失信。这既挡住把真实数据挂在额外字段上的伪造
// 收据，也意味着生产者一加字段收据就整体落入 token 化路径。2026-08-23 修复：
// listing_inspector.inspect() 的 inferredScenario / scenarioConfidence /
// supportData 三键漏在集外，真实收据失信后 spec 全文被 scrub_text 打成 token，
// harness 无法理解 spec 需求。改生产者字段时必须同步这里，
// test_listing_receipt_keys_stay_within_node_whitelist 会守住这条约束。
function isTrustedListingReceipt(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const marker = value.clinicalGuard ?? value.clinical_guard;
  if (!TRUSTED_LISTING_MARKERS.has(marker) || value.dataClass !== 'METADATA_ONLY') return false;
  const fingerprint = value.schemaFingerprint ?? value.schema_fingerprint;
  if (typeof fingerprint !== 'string' || !fingerprint) return false;
  const allowed = new Set([
    'clinicalGuard', 'clinical_guard', 'status', 'stage', 'project', 'scenario',
    'inferredScenario', 'scenarioConfidence', 'supportData',
    'documents', 'datasets', 'schema', 'schemaFingerprint', 'schema_fingerprint',
    'missing', 'warnings', 'dataClass', 'validation', 'plan', 'result',
    'audit_id', 'auditId', 'outputCount', 'code', 'path', 'message',
    // 代码车道 run 信封（CLINICAL_LISTING_CODE_RECEIPT）
    'outputs', 'datasetsTouched', 'errorType',
  ]);
  if (Object.keys(value).some((key) => !allowed.has(key))) return false;
  if (marker === 'CLINICAL_LISTING_INSPECTION') {
    if (value.stage !== 'inspect' || !value.schema || typeof value.schema !== 'object'
        || Array.isArray(value.schema)) return false;
    return Object.entries(value.schema).every(([dataset, columns]) => (
      typeof dataset === 'string' && Array.isArray(columns)
      && columns.every((column) => typeof column === 'string')
    ));
  }
  if (marker === 'CLINICAL_LISTING_CODE_RECEIPT') {
    return value.stage === 'run'
      && ['ok', 'rejected', 'error'].includes(value.status);
  }
  return value.stage === 'validate'
    && (value.status === 'validated' || value.status === 'invalid' || value.status === 'rejected');
}

function containsTrustedListingReceipt(value) {
  if (Array.isArray(value)) return value.some(containsTrustedListingReceipt);
  if (!value || typeof value !== 'object') return false;
  if (isTrustedListingReceipt(value)) return true;
  if (value.type === 'text' && typeof value.text === 'string') {
    try {
      if (containsTrustedListingReceipt(JSON.parse(value.text))) return true;
    } catch {
      // 普通文本不是收据，继续检查其它宿主字段。
    }
  }
  return Object.values(value).some(containsTrustedListingReceipt);
}

const here = dirname(fileURLToPath(import.meta.url));
const extractor = join(here, '..', 'excel_header_extractor.py');

// FIX-8 (NFR-12): extractor 超时可配置，默认 10s，硬上限 30s；SIGTERM → 2s → SIGKILL。
const EXTRACTOR_TIMEOUT_DEFAULT_MS = 10_000;
const EXTRACTOR_TIMEOUT_MAX_MS = 30_000;
const EXTRACTOR_GRACE_MS = 2_000;
const DATA_QUERY_TOOL_RE = /^(?:fetch|query|read|export)_(?:database|dataset|records?|rows?)$/i;
const LOCAL_OUTPUT_TOOL_RE = /^(?:bash|pwsh|powershell|shell|command|exec|read|read_file|job_output)$/i;
const SOURCE_PATH_RE = /(?:[A-Za-z]:[\\/]|\/)[^\s"'<>|]+\.(?:sas7bdat|xpt|sas7bcat|xlsx|xlsm|xls|xlsb)\b/gi;

function protectedSourceFromExec(exec, config) {
  const values = Object.values(exec?.arguments ?? {}).filter((value) => typeof value === 'string');
  const candidates = values.flatMap((value) => value.match(SOURCE_PATH_RE) ?? []);
  for (const candidate of candidates) {
    const plane = planeOf(candidate, config);
    const ext = extname(candidate).toLowerCase();
    if (plane !== 'data') continue;
    if (['.sas7bdat', '.xpt', '.sas7bcat'].includes(ext)) return 'sas';
    if (['.xlsx', '.xlsm', '.xls', '.xlsb'].includes(ext)) return 'external_excel';
  }
  return undefined;
}

function dirname(path) {
  return path.slice(0, Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\')));
}

function join(...parts) {
  return parts.join('/').replace(/\\/g, '/');
}

export function extractPath(args = {}) {
  for (const key of ['path', 'file_path', 'filePath', 'filename', 'file', 'project', 'projectPath', 'specPath', 'sasPath']) {
    const value = args[key];
    if (typeof value === 'string' && value.trim()) return value;
  }
  return '';
}

/**
 * 本地凭据通道 (用户需求)：判断 filePath 是否位于配置的 credentialsDir 之内。
 */
export function isCredentialPath(filePath, credentialsDir) {
  if (!credentialsDir || typeof filePath !== 'string' || !filePath.trim()) return false;
  const base = resolve(credentialsDir);
  const target = resolve(filePath);
  const rel = relative(base, target);
  return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel);
}

/**
 * 凭据占位
 */
function credentialPlaceholder(path) {
  return {
    clinicalGuard: 'CREDENTIAL_LOCAL_ONLY',
    credentialRef: basename(path),
    message: '本地凭据文件：原值仅供本地工具使用，已阻止进入模型上下文。',
  };
}

function extractorTimeoutMs(config) {
  const raw = Number(config?.extractorTimeoutMs);
  if (!Number.isFinite(raw) || raw <= 0) return EXTRACTOR_TIMEOUT_DEFAULT_MS;
  return Math.min(raw, EXTRACTOR_TIMEOUT_MAX_MS);
}

function runExtractor(path, maxRows, timeoutMs) {
  return new Promise((resolve, reject) => {
    const args = [extractor, path, '--max-scan-rows', String(maxRows)];
    const child = spawn(process.env.PYTHON ?? (process.platform === 'win32' ? 'python' : 'python3'),
      args, { stdio: ['ignore', 'pipe', 'pipe'], env: (() => {
        const e = {};
        for (const k of ['PATH','SystemRoot','USERPROFILE','HOME','TEMP','TMP','LOCALAPPDATA','APPDATA','HOMEDRIVE','HOMEPATH','LD_LIBRARY_PATH','DYLD_LIBRARY_PATH']) {
          if (process.env[k] !== undefined) e[k] = process.env[k];
        }
        e.PYTHONIOENCODING = 'utf-8';
        e.PYTHONUTF8 = '1';
        if (process.env.EMERALD_AUDIT_ROOT) e.EMERALD_AUDIT_ROOT = process.env.EMERALD_AUDIT_ROOT;
        return e;
      })() });
    let out = '';
    let err = '';
    let killTimer;
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      killTimer = setTimeout(() => child.kill('SIGKILL'), EXTRACTOR_GRACE_MS);
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { out += chunk; });
    child.stderr.on('data', (chunk) => { err += chunk; });
    child.on('error', (error) => {
      clearTimeout(timer);
      clearTimeout(killTimer);
      reject(error);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      clearTimeout(killTimer);
      if (code !== 0) {
        reject(new Error(redactSensitiveText(err.trim()) || `excel extractor exited with ${code}`));
        return;
      }
      try {
        resolve(JSON.parse(out));
      } catch (error) {
        reject(new Error(redactSensitiveText(`invalid excel extractor response: ${error.message}`)));
      }
    });
  });
}

/**
 * =============================================================================
 * 2026-08-21: 临床数据安全架构（死底线）
 *
 * 规则优先级（基于 planeOf 判断）：
 * 1. spec/document 域 → 可信需求文档全文可读，不做自动脱敏
 * 2. data 域 → 禁止出域
 * 3. output 域 → 只读表结构
 * 4. 其他（包括需求、代码、日志和控制结果）→ 保持原始语义
 * =============================================================================
 */

/**
 * 数据文件占位符（只返回表结构信息）
 */
function dataOnlyPlaceholder(path, kind) {
  return {
    clinicalGuard: 'DATA_BLOCKED',
    kind,
    file: redactSensitiveText(basename(path)),
    message: '临床数据内容已屏蔽；仅允许获批的本地 Listing 工作流处理，禁止发送给模型。',
    allowedRead: 'STRUCTURE_ONLY',  // 标记允许读取表结构
  };
}

export function shouldReplaceResult() {
  // 始终进入安全处置流程
  return true;
}

function textContent(text) {
  return [{ type: 'text', text }];
}

function contentOnly(result, text, protectedDataSource, protectedDataToken) {
  const block = { type: 'text', text };
  if (protectedDataSource && protectedDataToken) {
    block.clinicalGuard = 'PROTECTED_DATA_SOURCE';
    block.protectedDataSource = protectedDataSource;
    block.protectedDataToken = protectedDataToken;
  }
  return { content: [block] };
}

function existingContent(result) {
  return Array.isArray(result?.content) ? result.content : [];
}

// 宿主会把工具返回包装成 tool-result 内容块，Listing 的 JSON 文本通常位于
// block.content 内而不是顶层 content。收据标记必须跟随实际文本块，否则
// 出域检查只能看到普通字符串，无法区分控制面 schema 与真实数据。
function markListingReceipt(value, token) {
  if (!containsTrustedListingReceipt(value)) return value;
  if (Array.isArray(value)) return value.map((item) => markListingReceipt(item, token));
  if (!value || typeof value !== 'object') return value;
  if (value.type === 'text' && typeof value.text === 'string') {
    let parsed;
    try { parsed = JSON.parse(value.text); } catch { return value; }
    if (!containsTrustedListingReceipt(parsed)) return value;
    return {
      ...value,
      clinicalGuard: 'TRUSTED_LISTING_RECEIPT',
      trustedListingToken: token,
    };
  }
  return Object.fromEntries(Object.entries(value).map(([key, item]) => (
    [key, markListingReceipt(item, token)]
  )));
}

async function scrubUntrustedListingContent(value, runtime) {
  if (Array.isArray(value)) {
    return Promise.all(value.map((item) => scrubUntrustedListingContent(item, runtime)));
  }
  if (!value || typeof value !== 'object') return value;
  if (value.type === 'text' && typeof value.text === 'string') {
    const checked = await runtime.request({ operation: 'scrub_text', text: value.text, profile: 'strict' });
    if (!checked.ok || typeof checked.text !== 'string') {
      return { ...value, text: JSON.stringify({
        clinicalGuard: 'CHECK_FAILED', reason: 'Listing 结果安全检查失败',
      }) };
    }
    return { ...value, text: checked.text };
  }
  const entries = await Promise.all(Object.entries(value).map(async ([key, item]) => (
    [key, await scrubUntrustedListingContent(item, runtime)]
  )));
  return Object.fromEntries(entries);
}

// execute 收据的控制面投影。
//
// 2026-08-23 修复：execute 收据此前无条件走 scrubUntrustedListingContent，
// 连 JSON 的 key 都被打成 [TEXT:..]，harness 读不出"执行是否成功、产物叫什么、
// 有几行"。但 execute 是 dataClass: REAL 阶段，不能像 inspect 那样整体信任透传
// ——收据里可能夹带 payload / rows 之类的真实数据字段。
//
// 因此这里不做信任判定，改为按白名单重建：只挑出控制面字段，其余一律丢弃。
// 与闭集白名单相反，重建是"未列出即不存在"，生产者新增字段最坏是丢信息而不是
// 泄漏，也不会让收据整体退化成 token。
function projectExecuteReceipt(receipt) {
  const sheets = (list) => (Array.isArray(list) ? list : []).map((sheet) => ({
    name: typeof sheet?.name === 'string' ? sheet.name.slice(0, 128) : '',
    rowCount: Number.isFinite(sheet?.rowCount) ? sheet.rowCount : 0,
    columnCount: Number.isFinite(sheet?.columnCount) ? sheet.columnCount : 0,
  }));
  const artifact = (item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
    const projected = {};
    for (const key of ['id', 'name', 'kind']) {
      if (typeof item[key] === 'string') projected[key] = item[key];
    }
    if (Array.isArray(item.sheets)) projected.sheets = sheets(item.sheets);
    return projected;
  };

  const projected = { clinicalGuard: 'CLINICAL_LISTING_RECEIPT', dataClass: 'METADATA_ONLY' };
  for (const key of ['status', 'stage', 'project', 'scenario', 'code', 'path', 'message']) {
    if (typeof receipt[key] === 'string') projected[key] = receipt[key];
  }
  const fingerprint = receipt.schemaFingerprint ?? receipt.schema_fingerprint;
  if (typeof fingerprint === 'string' && fingerprint) projected.schemaFingerprint = fingerprint;
  const single = artifact(receipt.artifact);
  if (single) projected.artifact = single;
  if (Array.isArray(receipt.artifacts)) {
    projected.artifacts = receipt.artifacts.map(artifact).filter(Boolean);
  }
  if (Array.isArray(receipt.warnings)) {
    projected.warnings = receipt.warnings.filter((item) => typeof item === 'string');
  }
  projected.note = '执行收据已投影为控制面元数据；产物内容未读取，未随收据出域。';
  return projected;
}

function projectExecuteContent(value) {
  if (Array.isArray(value)) return value.map(projectExecuteContent);
  if (!value || typeof value !== 'object') return value;
  if (value.type === 'text' && typeof value.text === 'string') {
    let parsed;
    try { parsed = JSON.parse(value.text); } catch { return null; }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    const marker = parsed.clinicalGuard ?? parsed.clinical_guard;
    if (marker !== 'CLINICAL_LISTING_RECEIPT') return null;
    return { type: 'text', text: JSON.stringify(projectExecuteReceipt(parsed)) };
  }
  const entries = Object.entries(value).map(([key, item]) => [key, projectExecuteContent(item)]);
  if (entries.some(([, item]) => item === null)) return null;
  return Object.fromEntries(entries);
}

function blockedContent(reason) {
  return contentOnly(null, JSON.stringify({
    clinicalGuard: 'BLOCKED',
    reason,
  }));
}

function canonicalPathProjection(result, trustedControlToken) {
  const meta = result?.meta;
  if (meta?.shape !== 'paths' || !Array.isArray(meta.paths)) return null;
  return {
    clinicalGuard: 'CONTROL_PATHS',
    trustedControlToken,
    paths: meta.paths.filter((path) => typeof path === 'string'),
    truncated: Boolean(meta.truncated),
    total: Number.isFinite(meta.total) ? meta.total : meta.paths.length,
    note: '仅返回路径控制信息；未读取或返回任何文件内容。',
  };
}

/**
 * 2026-08-21: 智能安全处置
 *
 * 核心逻辑：
 * 1. doc/docs/spec/als/template 目录 → 可信文档全文豁免自动脱敏
 * 2. 数据文件 → 只读表结构
 * 3. SAS data → 禁止出域
 * 4. 其余结果原样放行
 */
export async function safeToolResult(exec, result, runtime, config, trustedDocumentToken) {
  if (CLINICAL_LISTING_TOOLS.has(String(exec?.name ?? ''))) {
    if (!containsTrustedListingReceipt(existingContent(result))) {
      return { content: await scrubUntrustedListingContent(existingContent(result), runtime) };
    }
    return {
      content: markListingReceipt(existingContent(result), trustedDocumentToken),
    };
  }
  if (ALL_CLINICAL_LISTING_TOOLS.has(String(exec?.name ?? ''))) {
    // execute 收据优先走控制面投影：harness 需要读懂执行结果，投影只保留
    // 白名单字段，夹带的真实数据字段被丢弃。投影不适用时才回退到 token 化。
    const projected = projectExecuteContent(existingContent(result));
    if (projected) return { content: projected };
    return { content: await scrubUntrustedListingContent(existingContent(result), runtime) };
  }

  const path = extractPath(exec.arguments ?? {});
  const localPath = path && !isAbsolute(path) && config.workspaceRoot
    ? resolve(config.workspaceRoot, path) : path;
  const ext = extname(path).toLowerCase();

  // glob 等工具的 canonical meta.paths 属于控制面。只从结构化元数据重建，
  // 不信任显示文本，也不读取路径指向的文件内容。
  const pathProjection = canonicalPathProjection(result, trustedDocumentToken);
  if (pathProjection) {
    return contentOnly(result, JSON.stringify(pathProjection));
  }

  // 命令串车道：shell/read/job_output 只带 command 时 extractPath 取不到路径，
  // planeOf('') 无法识别来源，真实 stdout 会原样回到模型。此处从命令串提取来源。
  // 仅在无显式路径参数时生效，避免夺走 path 场景的表头/结构投影。
  const commandSource = !path && LOCAL_OUTPUT_TOOL_RE.test(String(exec?.name ?? ''))
    ? protectedSourceFromExec(exec, config)
    : undefined;
  if (commandSource) {
    return contentOnly(
      result,
      JSON.stringify(dataOnlyPlaceholder('', `${commandSource.toUpperCase()}_OUTPUT`)),
      commandSource,
      config.protectedDataToken,
    );
  }

  // 无路径的数据查询能力无法用 planeOf 判定，按工具来源直接阻断。
  if (DATA_QUERY_TOOL_RE.test(String(exec?.name ?? ''))) {
    return contentOnly(result, JSON.stringify(dataOnlyPlaceholder('', 'DATA_QUERY')));
  }

  // =============================================================================
  // 2026-08-21: 核心业务规则处置（基于 planeOf 判断）
  // =============================================================================

  // 1. 凭据文件
  if (isCredentialPath(path, config.credentialsDir)) {
    return contentOnly(result, JSON.stringify(credentialPlaceholder(path)));
  }

  // 2. 来源域处置（基于 planeOf）
  const plane = planeOf(path, config);
  const protectedDataSource = plane === 'data' && ['.sas7bdat', '.xpt', '.sas7bcat'].includes(ext)
    ? 'sas'
    : (plane === 'data' && ['.xlsx', '.xlsm', '.xls', '.xlsb'].includes(ext)
      ? 'external_excel'
      : undefined);
  if (plane === 'data' && !['.xlsx', '.xlsm', '.xls', '.xlsb'].includes(ext)) {
    return contentOnly(result, JSON.stringify(dataOnlyPlaceholder(path, 'DATA_PLANE')), protectedDataSource, config.protectedDataToken);
  }

  // 普通错误属于控制/诊断语义；明确数据能力、凭据与数据域已在上方阻断。
  if (result?.isError) {
    return { content: existingContent(result) };
  }

  if (plane === 'spec' || plane === 'document') {
    // 文档域由配置路径建立信任，内容完整供模型理解需求，不做形态识别脱敏。
    return {
      content: existingContent(result).map((block) => (
        block?.type === 'text' ? {
          ...block,
          clinicalGuard: 'TRUSTED_DOCUMENT_CONTENT',
          trustedDocumentToken,
        } : block
      )),
    };
  }
  if (plane === 'output') {
    // output 域：只读表结构
    if (['.xlsx', '.xls', '.csv'].includes(ext)) {
      if (!existsSync(localPath)) {
        return contentOnly(result, JSON.stringify({
          clinicalGuard: 'CHECK_FAILED',
          reason: '目标文件不存在',
        }));
      }
      try {
        const headers = await runExtractor(
          localPath, config.maxScanRows ?? 20, extractorTimeoutMs(config),
        );
        return contentOnly(result, JSON.stringify({
          clinicalGuard: 'EXCEL_STRUCTURE_ONLY',
          ...headers,
          note: '数据内容已屏蔽，仅显示表结构',
        }));
      } catch (error) {
        return contentOnly(result, JSON.stringify({
          clinicalGuard: 'CHECK_FAILED',
          reason: '表结构读取失败',
          detail: redactSensitiveText(error.message),
        }));
      }
    }
  }

  // 3. 数据文件（Excel/SAS/CSV）→ 只读表结构
  if (['.sas7bdat', '.xpt'].includes(ext)) {
    return contentOnly(result, JSON.stringify(dataOnlyPlaceholder(path, 'SAS_DATA')));
  }

  if (['.xlsx', '.xlsm', '.xls', '.xlsb', '.csv'].includes(ext)) {
    if (!existsSync(localPath)) {
      return contentOnly(result, JSON.stringify({
        clinicalGuard: 'CHECK_FAILED',
        reason: '目标文件不存在',
      }), protectedDataSource, config.protectedDataToken);
    }
    try {
      const headers = await runExtractor(
        localPath, config.maxScanRows ?? 20, extractorTimeoutMs(config),
      );
      return contentOnly(result, JSON.stringify({
        clinicalGuard: 'EXCEL_STRUCTURE_ONLY',
        ...headers,
        note: '数据内容已屏蔽，仅显示表结构',
      }), protectedDataSource, config.protectedDataToken);
    } catch (error) {
      return contentOnly(result, JSON.stringify({
        clinicalGuard: 'CHECK_FAILED',
        reason: '表结构读取失败',
        detail: redactSensitiveText(error.message),
      }), protectedDataSource, config.protectedDataToken);
    }
  }

  // 5. zip 文件 → 检查是否包含数据
  if (ext === '.zip') {
    return contentOnly(result, JSON.stringify(dataOnlyPlaceholder(path, 'ZIP_ARCHIVE')));
  }

  // 6. 普通需求、代码、日志与控制结果保持可读；不做无来源的全局 token 化。
  return { content: existingContent(result) };
}
