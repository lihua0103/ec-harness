import { defineTool } from '@deepseek-ai/dsh-tools';

const SCENARIOS = ['medical', 'rbqm', 'manual', 'report'];

// F-1（生产阻断，2026-08-22 RBQM_test 72 数据集实测）：listing 的 inspect/execute
// 是重本地 I/O 操作（解压归档、读全部 SAS 域 metadata、pandas 关系运算、写 Excel），
// 在真实项目规模下必然超过通用安全检查的 30s 默认超时，导致工具调用以
// "security worker request timeout after 30000ms" 失败、整轮 listing 中断。
// 超时按操作类型区分：validate 只做 schema 校验（不读记录）保持短超时，
// inspect/execute 给足本地计算时间。三者均可经 config 覆写以适配超大项目。
// 2026-08-24 架构重设计（用户裁决）：IR 三阶段退役，代码车道上线。模型全权
// 编写 pandas 变换代码；本地沙箱（白名单 AST + 受限运行时 + 子进程隔离）保证
// SAS 行级数据与 doc/ 外真实数据零出域。run 只回聚合元数据信封，模型据信封
// 迭代；publish 重放最近一次成功代码并由固定 Writer 产出 Excel。
const LISTING_TIMEOUT_DEFAULT_MS = {
  listing_inspect: 600_000,
  listing_run_code: 600_000,
  listing_publish: 900_000,
};

function listingTimeoutMs(config, operation) {
  const override = Number(config?.listingTimeoutMs?.[operation] ?? config?.listingTimeoutMs);
  if (Number.isFinite(override) && override > 0) return override;
  return LISTING_TIMEOUT_DEFAULT_MS[operation];
}

const RESULT_SCHEMA = { type: 'object', additionalProperties: false, properties: {
  ok: { type: 'boolean', required: true }, action: { type: 'string', required: true },
  inspection: { type: 'object', additionalProperties: true }, receipt: { type: 'object', additionalProperties: true }, reason: { type: 'string' }, code: { type: 'string' },
  retryable: { type: 'boolean' },
} };
const CODE_SCHEMA = { type: 'string', required: true, description: 'pandas 变换代码。可用：datasets（按名取 DataFrame，如 datasets["dm"]）、pd、np、math 与纯计算内建。禁用：import、下划线属性、文件/网络/序列化 IO（read_*/to_*/load/save 等）、eval/exec/query。代码必须赋值 result（单个 DataFrame）或 outputs（{listing 名: DataFrame}）。数据值不会回传，只回行数/列名/dtype/空值计数。' };

function workflowContext(config, exec) {
  return {
    mode: config.mode, dataProtectionEnabled: config.dataProtectionEnabled, localDataAccess: config.localDataAccess,
    localDataRoot: exec?.agent?.session?.header?.cwd ?? config.localDataRoot,
    outputPlaneRoot: config.outputPlaneRoot,
    credentialsDir: config.credentialsDir, sessionId: exec?.agent?.sessionId ?? config.sessionId ?? 'unknown-session',
    userId: exec?.agent?.userId ?? config.userId ?? 'anonymous',
  };
}

function commonParameters() {
  return { project: { type: 'string', required: true, description: '当前会话工作区内的相对项目目录；当前根使用 "."。'}, scenario: { type: 'string', enum: SCENARIOS, description: '可选；省略时由 specification 自动推断。' }, credentialRef: { type: 'string', required: true, description: '本地凭据目录内的相对引用；无加密归档时传空字符串。凭据内容永不进入模型或收据。' } };
}

function registerTool(ctx, runtime, config, definition) {
  return ctx.tools.register(defineTool({
    // Listing 收据是控制面元数据。必须保持紧凑的单行 JSON，避免 pretty-print
    // 把大型 schema 展开成上千个物理行，触发出域检查的整表转储红线。
    // 这不改变收据内容，也不影响 post-execute 的信任标记与二次检查。
    output: { schema: RESULT_SCHEMA, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
    ...definition,
    execute: async (args, exec) => {
      const timeoutMs = listingTimeoutMs(config, definition.operation);
      let response;
      try {
        response = await runtime.request({ operation: definition.operation, project: args.project, scenario: args.scenario, code: args.code, credentialRef: args.credentialRef, context: workflowContext(config, exec) },
          { timeoutMs });
      } catch (error) {
        // F-1: 超时/运行时不可用返回结构化可重试收据，而不是裸 Error。
        // 裸 Error 会让模型无法区分"本地计算还没跑完"和"计划被拒绝"，
        // 只能重开一轮；结构化收据让模型明确知道可以原样重试。
        if (!/timeout after \d+ms/.test(String(error?.message ?? ''))) throw error;
        return {
          ok: false, action: definition.operation.replace(/_/g, '-'), code: 'LISTING_TIMEOUT', retryable: true,
          reason: `本地 listing 操作在 ${Math.round(timeoutMs / 1000)}s 内未完成。真实记录未出域，可原样重试；若持续超时请提高 listingTimeoutMs.${definition.operation} 或缩小计划输出范围。`,
        };
      }
      if (!response.ok) throw new Error(response.reason || 'clinical listing operation failed');
      // worker 的 requestId 只属于内部 JSON 行协议，不得进入 DSH 工具合同。
      const { requestId: _requestId, ...businessResponse } = response;
      return businessResponse;
    },
  }));
}

export function registerClinicalListingPlugin(ctx, runtime, config) {
  if (config.localDataAccess !== 'uat-local') return () => {};
  const disposers = [];
  disposers.push(registerTool(ctx, runtime, config, {
    name: 'clinical_listing_inspect', operation: 'listing_inspect',
    description: '读取临床 Listing spec 正文、ALS 映射和 SAS/XPT schema 结构，只返回需求与元数据，不返回真实数据值。',
    parameters: commonParameters(),
    presentCall: (args) => ({
      card: 'generic',
      title: `Listing Inspect: ${args.scenario}`,
      kind: 'search',
      content: [{
        type: 'text',
        text: '阶段 1/2：读取规格、ALS 与归档目录元数据；不解压临床数据。',
      }],
    }),
  }));
  disposers.push(registerTool(ctx, runtime, config, {
    name: 'clinical_listing_run_code', operation: 'listing_run_code',
    description: '在本地沙箱执行 pandas 变换代码并返回聚合元数据信封（行数/列名/dtype/空值计数）。数据值绝不出域；据信封迭代代码。',
    parameters: { ...commonParameters(), code: CODE_SCHEMA }, presentCall: (args) => ({ card: 'workflow', title: `Listing Run Code: ${args.scenario}`, kind: 'execute' }),
  }));
  disposers.push(registerTool(ctx, runtime, config, {
    name: 'clinical_listing_publish', operation: 'listing_publish',
    description: '重放最近一次成功代码，由本地固定 Writer 产出 Excel 交付物（CONTENTS 目录页、复核列、公式注入防护），返回 artifact 元数据。',
    parameters: commonParameters(), presentCall: (args) => ({ card: 'workflow', title: `Listing Publish: ${args.scenario}`, kind: 'execute' }),
  }));
  if (ctx.systemPrompt?.section) disposers.push(ctx.systemPrompt.section({
    name: 'tool:clinical-listing-lifecycle', order: 95,
    text: '临床 Listing 按代码车道循环执行：clinical_listing_inspect 阅读 spec 正文、ALS 字段结构和本地 schema；随后用 clinical_listing_run_code 提交 pandas 代码（datasets 按名取数、pd/np/math 可用、禁 import 与一切文件网络 IO），依据返回的元数据信封（行数/列名/空值计数）迭代修正；代码稳定后用 clinical_listing_publish 发布 Excel。模型绝不能读取或生成 SAS/XPT 数据行、单元格值或派生数据值——沙箱只回聚合元数据，Excel 由本地固定 Writer 产出。不得使用通用 shell、文件读取或脚本绕过本地车道。',
  }));
  return () => disposers.forEach((dispose) => dispose?.());
}
