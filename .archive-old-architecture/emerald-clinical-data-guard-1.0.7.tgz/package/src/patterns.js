import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const source = JSON.parse(readFileSync(join(here, '..', 'security', 'node_patterns.json'), 'utf8'));

export const dlpPatterns = source.map(({ source: pattern, flags = '', label, severity = 'block' }) => ({
  label,
  severity,
  regex: new RegExp(pattern, flags),
}));

const safePatterns = [
  /^Day\s*\d+$/i,
  /^Week\s*\d+$/i,
  /^Cycle\s*\d+$/i,
  /^Visit\s*\d+$/i,
  /^Baseline$/i,
  /^Screening$/i,
];

// 真实缺陷修复：'标识+YYYYMMDD' 文档版本号（DVP20260610、SPEC20260610）不是
// 受试者编号。与 Python 两侧 is_document_version_number 同一纯格式判据（无关键词
// 豁免——关键词豁免是 ST-D-5 已知泄露通道）：尾部 8 位数字构成合法 YYYYMMDD
// （年 1900-2099、月 01-12、日 01-31）即认定为日期。
// 受试者编号不受影响：A1234567 只有 7 位数字，S0001234 的"0012"月份非法。
const YYYYMMDD_RE = /^(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])$/;

function isDocumentVersionNumber(matchedText) {
  const digits = String(matchedText ?? '').trim().replace(/^[A-Za-z]+/, '');
  return digits.length === 8 && YYYYMMDD_RE.test(digits);
}

// 代码模板占位符（f-string/format/%-格式化/shell 变量）。与 Python 侧
// _TEMPLATE_PLACEHOLDER_RE 同口径。
const TEMPLATE_PLACEHOLDER_RE = /\{[^{}]*\}|%\(?[A-Za-z_]\w*\)?[sdrfgex]|\$\{?\w+\}?/g;

/**
 * 真实缺陷（2026-08-21 RBQM_test 实测）：写执行器脚本被 quickGuard 拦死。
 * `*_ASSIGN` 模式只看"字段名后跟非空白"，于是代码里的
 *   USUBJID=f'{STUDYID}-{site}-{i:03d}'   （构造表达式）
 *   USUBJID=u, / USUBJID=x['USUBJID'],    （变量引用）
 * 全被当成患者数据阻断——agent 因此写不出任何真实执行器脚本。
 *
 * 纯格式判据（非关键词豁免）：赋值右侧剥掉占位符后若不含任何字面数字，
 * 该命中承载的是符号（变量名/表达式）而非数据值。
 * 真实赋值不受影响：USUBJID=010-001-1001 / USUBJID: 2026-03-18 /
 * USUBJID=1001 的字面数字在剥离后仍在 → 照常阻断；
 * 混合形态 f'{STUDY}-001-1001' 的字面尾段 -001-1001 保留 → 阻断。
 * 与 Python `_looks_like_data_value`（无数字即非数据值）同口径。
 */
function isSymbolicAssignment(matchedText) {
  const rhs = String(matchedText ?? '').replace(/^[A-Za-z_]+\s*[=:]\s*/, '');
  TEMPLATE_PLACEHOLDER_RE.lastIndex = 0;
  const stripped = rhs.replace(TEMPLATE_PLACEHOLDER_RE, '');
  return !/\d/.test(stripped);
}

// 操作性标识（文件路径/文件名）区间——agent 必须原样回传给工具的参数形态。
// 真实缺陷（2026-08-20 工作台实测）：read_file 参数里的路径含模式形态被拦/
// 被 token 化，模型拿假路径读文件直接 not found。用户规则：路径/文件名是
// 辅助读取的操作数据，三车道一律原样放行。与 Python patterns.py 同口径。
const OPERATIONAL_PATH_RES = [
  /[A-Za-z]:[\\/]+(?:[^\\/:*?"<>|\r\n\\/]+[\\/]+)*[^\\/:*?"<>|\r\n\\/]*/g,
  /(?:\\\\|\/\/)[^\\/:*?"<>|\r\n\\/]+(?:[\\/]+[^\\/:*?"<>|\r\n\\/]+)+/g,
  /(?<![\w.])(?:\/[\w.\-]+)+\/?/g,
  // 相对多段路径，必须以带扩展名文件名收尾（meta.paths 真实形态；
  // 收尾约束排除 "A1234567\\n" 类转义序列被误当路径造成数据值逃逸）。
  // 分隔符 [\\/]+ 覆盖 JSON 序列化后的双反斜杠——单分隔符写法会让首段
  // （项目目录名）掉出区间被 token 化成假路径（与 Python 同口径修复）。
  /[\w\-. ]{1,64}(?:[\\\/]+[\w\-. ]{1,64}){1,}[\\\/]*[\w\-.]{0,120}\.[A-Za-z]\w{0,7}\b/g,
  /[\w\-. ]{1,64}[\\\/]+[\w\-.]{1,120}\.[A-Za-z]\w{0,7}\b/g,
];
const FILENAME_TOKEN_RE = /[\w\-. ]{0,118}[\w\-]\.[A-Za-z]\w{0,7}\b/g;

// S4（JS/Python 豁免对齐）：token 区间。脱敏产出的 token 形态 [KIND:hex8]
// 属于可证明安全类，但 HMAC hex 偶发"字母前缀+6-8位数字"形态（如 cc562813）
// 会命中 ALPHA_SUBJECT_ID，造成"token 化之后反而被拦"。与 Python 侧
// egress_checkpoint._TOKEN_SPAN_RE 同一判据、按位置豁免。
const TOKEN_SPAN_RE = /\[[A-Z]{2,6}:[0-9a-f]{8}\]/g;

// S4：SAS 日期字面量 `'01JAN2024'd` / `"01jan2024"d` 是 SAS 语法常量，
// 不是患者数据。真实缺陷（RBQM_test）：写 SAS 程序含该字面量被 quickGuard
// 拦死，agent 写不出执行器脚本。判据是 SAS 字面量语法（引号 + 尾随 d），
// 不是"文本里出现了日期"，因此裸 01JAN2024 仍按 SAS_DATE 处置。
const SAS_DATE_LITERAL_RE = /(['"])\d{2}[A-Za-z]{3}\d{4}\1d\b/g;

function spansOf(value, regexes) {
  const spans = [];
  for (const re of regexes) {
    re.lastIndex = 0;
    let match;
    while ((match = re.exec(value)) !== null) {
      if (match[0].length === 0) { re.lastIndex += 1; continue; }
      spans.push([match.index, match.index + match[0].length]);
    }
  }
  return spans;
}

function operationalSpans(value) {
  return spansOf(value, [...OPERATIONAL_PATH_RES, FILENAME_TOKEN_RE]);
}

/**
 * S4：与 Python 出域车道对齐的严重度判定。
 *
 * Python 侧对纯日期形态只给 WARN（与其他信号复合才阻断），Node 侧此前只有
 * "命中=阻断"一档，导致写 spec 的 2024-01-01 被拦死。quickGuard 是布尔门，
 * 因此 warn 级命中在这里不阻断——它们仍会在 worker 的 check_tool 与出域
 * 检查点被按 WARN 口径记录，防线没有削弱。
 */
export function scanDlpDetailed(text) {
  const value = String(text ?? '');
  const opSpans = operationalSpans(value);
  const exemptSpans = spansOf(value, [TOKEN_SPAN_RE, SAS_DATE_LITERAL_RE]);
  const warnings = [];
  for (const { regex, label, severity } of dlpPatterns) {
    // 必须遍历同一模式的**全部**命中，不能只看首个：豁免判据（安全词/文档
    // 版本号/代码模板/操作性路径）逐命中生效，若首个命中被豁免就 continue 到
    // 下一模式，同模式后面的真实数据值会被静默漏掉（泄露通道）。
    const all = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : `${regex.flags}g`);
    let match;
    while ((match = all.exec(value)) !== null) {
      if (match[0].length === 0) { all.lastIndex += 1; continue; }
      // ST-P1-6: 安全词豁免必须整体等于命中串，不能因命中串"包含"安全词子串就放行
      // （否则 USUBJID=SCREENING-01-123456 因含 Screening 被整体豁免泄露）。
      if (safePatterns.some((safe) => safe.test(match[0].trim()))) continue;
      // ALPHA_SUBJECT_ID 的文档版本号形态排除，与 Python 车道口径一致。
      if (label === 'ALPHA_SUBJECT_ID' && isDocumentVersionNumber(match[0])) continue;
      // 符号赋值（USUBJID=f'{...}' / USUBJID=u）不是数据值，与 Python 车道同口径。
      if ((label === 'USUBJID_ASSIGN' || label === 'SUBJID_ASSIGN')
          && isSymbolicAssignment(match[0])) continue;
      const start = match.index;
      const end = start + match[0].length;
      // 操作性标识（路径/文件名）区间内的命中不是临床数据
      if (opSpans.some(([a, b]) => a <= start && end <= b)) continue;
      // S4: token 区间与 SAS 日期字面量区间内的命中不是数据值
      if (exemptSpans.some(([a, b]) => a <= start && end <= b)) continue;
      if (severity === 'warn') {
        if (!warnings.includes(label)) warnings.push(label);
        continue;
      }
      return { blocked: label, warnings };
    }
  }
  return { blocked: null, warnings };
}

export function scanDlp(text) {
  return scanDlpDetailed(text).blocked;
}

export function redactSensitiveText(text) {
  return String(text ?? '')
    .replace(/[\r\n]+/g, ' ')
    // FIX-3 (AR-2.9): 本地路径（Windows 盘符 / UNC / Unix 绝对路径）→ [PATH]
    .replace(/[A-Za-z]:\\[^\s"']*/g, '[PATH]')
    .replace(/\\\\[^\s"']+/g, '[PATH]')
    .replace(/(^|[\s"'(=])((?:\/[\w.-]+){2,})/g, '$1[PATH]')
    .replace(/\b[A-Za-z]{1,4}\d{6,8}\b/g, '[SUBJ]')
    .replace(/\b\d{3,4}-\d{3,6}\b/g, '[SUBJ]')
    .replace(/\b\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2})?)?\b/g, '[DATE]')
    .slice(0, 120);
}
