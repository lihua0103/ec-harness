import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { delimiter, join } from 'node:path';
import { existsSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { defineTool } from '@deepseek-ai/dsh-tools';
import { registerBranding } from './branding.js';
import { scanDlp } from './patterns.js';
import { planeOf, parseRootsEnv, validatePlaneRoots } from './planes.js';
import { safeToolResult, shouldReplaceResult } from './tool-result-guard.js';
import { registerClinicalListingPlugin } from './clinical-listing-plugin.js';

// FIX-6 (R-9): 安全检查请求超时（默认 30s，可配置）。
const REQUEST_TIMEOUT_DEFAULT_MS = 30_000;
// FIX-11 (Claude P2-1): worker 心跳——30s 间隔、5s 超时、3 次失败标记 degraded 并重启。
const HEARTBEAT_INTERVAL_MS = 30_000;
const HEARTBEAT_TIMEOUT_MS = 5_000;
const HEARTBEAT_MAX_FAILURES = 3;

export class SecurityRuntime {
  constructor(config) {
    this.config = config;
    this.pending = new Map();
    this.seq = 0;
    this.broken = false;
    this.degraded = false;
    this.heartbeatFailures = 0;
    this.heartbeatTimer = null;
    // E-2: 最近一次 worker 启动横幅（无 requestId 的结构化行，如依赖缺失）。
    this.startupNotice = null;
    // 同一 SecurityRuntime 生命周期内固定；worker 心跳/超时重启后继续复用，
    // 避免同一值在同一模型会话中映射成不同 token。
    this.sessionKey = randomBytes(32).toString('hex');
    this.#spawnWorker();
  }

  // E-2（2026-08-22 e2e 审计）：解释器钉死。此前未显式配置时按 PATH 解析
  // `python`，宿主 PATH 前置的其他发行版 python（缺 pyreadstat）会被随机选中，
  // worker 启动即崩并以 EBADF 之类无语义错误杀掉整轮运行。解析顺序：
  // config → PYTHON 环境变量（start.ps1 注入 venv 绝对路径）→ 本产品部署
  // 约定的仓库根 .venv → PATH 兜底。
  #resolvePython() {
    if (this.config?.python) return this.config.python;
    if (process.env.PYTHON) return process.env.PYTHON;
    const pluginRoot = fileURLToPath(new URL('..', import.meta.url));
    const candidates = process.platform === 'win32'
      ? [join(pluginRoot, '..', '.venv', 'Scripts', 'python.exe')]
      : [join(pluginRoot, '..', '.venv', 'bin', 'python'),
         join(pluginRoot, '..', '.venv', 'bin', 'python3')];
    for (const candidate of candidates) {
      if (existsSync(candidate)) return candidate;
    }
    return process.platform === 'win32' ? 'python' : 'python3';
  }

  #spawnWorker() {
    const config = this.config;
    const python = this.#resolvePython();
    const cwd = fileURLToPath(new URL('..', import.meta.url));
    this.startupNotice = null;
    // ST-P2-3: worker 只继承最小 env 白名单，防止不可信 Excel 解析漏洞
    // 导致 LLM API Key 等宿主凭据被收割。所有需要的运行时量显式传递。
    const env = {};
    // PATH/SystemRoot/USERPROFILE/HOME: 让 Python 能找到标准库和 CRT
    for (const key of ['PATH', 'SystemRoot', 'USERPROFILE', 'HOME', 'TEMP', 'TMP',
                       'LOCALAPPDATA', 'APPDATA', 'HOMEDRIVE', 'HOMEPATH',
                       'LD_LIBRARY_PATH', 'DYLD_LIBRARY_PATH']) {
      if (process.env[key] !== undefined) env[key] = process.env[key];
    }
    env.EMERALD_WORKER_ROOT = cwd;
    env.EMERALD_SESSION_KEY = this.sessionKey;
    // 协议层 UTF-8 兜底（E2E-1 修复）
    env.PYTHONIOENCODING = 'utf-8';
    env.PYTHONUTF8 = '1';
    const pythonPaths = [cwd];
    if (process.env.PYTHONPATH) pythonPaths.push(process.env.PYTHONPATH);
    env.PYTHONPATH = pythonPaths.join(delimiter);
    // 审计/授权 root 路径（若已配置）
    if (process.env.EMERALD_AUDIT_ROOT) env.EMERALD_AUDIT_ROOT = process.env.EMERALD_AUDIT_ROOT;
    if (process.env.EMERALD_AUTHZ_ROOT) env.EMERALD_AUTHZ_ROOT = process.env.EMERALD_AUTHZ_ROOT;
    const child = spawn(python, ['-m', 'security.worker'], {
      cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
      env,
    });
    this.child = child;
    this.buffer = '';
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => this.#onOutput(chunk));
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', () => {});
    // 仅当退出的仍是当前 worker 时才判定运行时损坏（避免重启竞态误杀新进程）。
    child.on('error', (error) => {
      if (this.child === child) this.#failAll(error);
    });
    child.on('exit', () => {
      if (this.child !== child) return;
      // E-2: worker 退出前若留下结构化启动横幅（如依赖缺失），把它拼进错误，
      // 让上层拿到可行动诊断，而不是无语义的 "worker exited"/EBADF。
      const notice = this.startupNotice;
      this.#failAll(notice
        ? new Error(`security worker exited: ${notice.code ?? 'UNKNOWN'} - ${notice.reason ?? 'no reason'}`)
        : new Error('security worker exited'));
    });
  }

  // FIX-6 (R-9): EPIPE / 进程崩溃 → 标记损坏、kill 并拒绝全部 pending。
  #failAll(error) {
    this.broken = true;
    for (const { reject, timer } of this.pending.values()) {
      clearTimeout(timer);
      reject(error);
    }
    this.pending.clear();
    try { this.child.kill(); } catch { /* already dead */ }
  }

  #onOutput(chunk) {
    this.buffer += chunk;
    let index;
    while ((index = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, index).trim();
      this.buffer = this.buffer.slice(index + 1);
      if (!line) continue;
      let response;
      try {
        response = JSON.parse(line);
      } catch {
        response = { ok: false, code: 'SECURITY_UNAVAILABLE', reason: 'invalid worker response' };
      }
      const pending = this.pending.get(response.requestId);
      if (pending) {
        this.pending.delete(response.requestId);
        clearTimeout(pending.timer);
        pending.resolve(response);
      } else if (response.code) {
        // E-2: 不对应任何 pending 请求的结构化横幅（worker 启动预检输出）——
        // 记录为启动诊断，worker 退出时并入错误信息；不影响协议分发。
        this.startupNotice = response;
      }
    }
  }

  request(payload, options = {}) {
    const requestId = `req-${++this.seq}`;
    const configured = Number(this.config?.requestTimeoutMs);
    const timeoutMs = Number(options.timeoutMs) > 0
      ? Number(options.timeoutMs)
      : (configured > 0 ? configured : REQUEST_TIMEOUT_DEFAULT_MS);
    return new Promise((resolve, reject) => {
      if (this.broken || this.child.exitCode !== null || this.child.killed) {
        // E-2: 已损坏时若持有启动横幅（依赖缺失等），把可行动诊断带给调用方。
        const notice = this.startupNotice;
        reject(new Error(notice
          ? `security worker unavailable: ${notice.code ?? 'UNKNOWN'} - ${notice.reason ?? 'no reason'}`
          : 'security worker unavailable'));
        return;
      }
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        const timeout = new Error(`security worker request timeout after ${timeoutMs}ms`);
        // Python worker 串行处理请求。仅从 pending 中移除超时请求会让子进程继续
        // 占用队列，后续调用看起来像无响应；超时必须终止旧 worker 并立即重建。
        reject(timeout);
        this.#restartWorker(new Error('security worker restarted after a timed-out request'));
      }, timeoutMs);
      this.pending.set(requestId, { resolve, reject, timer });
      this.child.stdin.write(JSON.stringify({ requestId, ...payload }) + '\n', (error) => {
        if (error) {
          // FIX-6 (R-9): stdin EPIPE → worker 损坏，kill 并拒绝全部 pending。
          this.pending.delete(requestId);
          clearTimeout(timer);
          this.#failAll(error);
          reject(error);
        }
      });
    });
  }

  // FIX-11 (Claude P2-1): ping/pong 心跳，3 次失败标记 degraded 并自动重启 worker。
  // 间隔/超时/阈值可经 config 覆盖（测试注入小值驱动）。
  startHeartbeat() {
    if (this.heartbeatTimer) return;
    const intervalMs = Number(this.config?.heartbeatIntervalMs) > 0
      ? Number(this.config.heartbeatIntervalMs) : HEARTBEAT_INTERVAL_MS;
    const probeTimeoutMs = Number(this.config?.heartbeatTimeoutMs) > 0
      ? Number(this.config.heartbeatTimeoutMs) : HEARTBEAT_TIMEOUT_MS;
    const maxFailures = Number.isInteger(this.config?.heartbeatMaxFailures)
      ? Number(this.config.heartbeatMaxFailures) : HEARTBEAT_MAX_FAILURES;
    const ping = async () => {
      if (this.broken) {
        // worker 已退出/损坏：计入心跳失败，达到阈值自动重启恢复服务。
        this.heartbeatFailures += 1;
        if (this.heartbeatFailures >= maxFailures) {
          this.degraded = true;
          this.#restartWorker();
        }
        return;
      }
      try {
        await this.request({ operation: 'ping' }, { timeoutMs: probeTimeoutMs });
        this.heartbeatFailures = 0;
        this.degraded = false;
      } catch {
        this.heartbeatFailures += 1;
        if (this.heartbeatFailures >= maxFailures) {
          this.degraded = true;
          this.#restartWorker();
        }
      }
    };
    this.heartbeatTimer = setInterval(ping, intervalMs);
    this.heartbeatTimer.unref?.();
  }

  #restartWorker(reason = new Error('security worker restarted')) {
    const previous = this.child;
    this.broken = true;
    for (const { reject, timer } of this.pending.values()) {
      clearTimeout(timer);
      reject(reason);
    }
    this.pending.clear();
    try { previous.kill(); } catch { /* already dead */ }
    this.heartbeatFailures = 0;
    this.broken = false;
    this.#spawnWorker();
  }

  dispose() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    try { this.child.kill(); } catch { /* already dead */ }
  }
}

function validateConfig(raw = {}) {
  // 兼容测试数据环境关闭主动阻断，但零出域脱敏始终生效。
  const dataProtectionEnabled = raw.dataProtectionEnabled
    ?? process.env.DATA_PROTECTION_ENABLED !== '0';
  const mode = raw.mode ?? process.env.DATA_PROTECTION_MODE ?? (dataProtectionEnabled ? 'enforce' : 'disabled');
  if (!['enforce', 'shadow', 'disabled'].includes(mode)) {
    throw new Error(`invalid DATA_PROTECTION_MODE: ${mode}`);
  }
  const approvalId = raw.approvalId ?? process.env.DATA_PROTECTION_APPROVAL_ID;
  const approvedBy = raw.approvedBy ?? process.env.DATA_PROTECTION_APPROVED_BY;
  if (mode === 'disabled' && (!approvalId || !approvedBy)) {
    throw new Error('disabled mode requires approvalId and approvedBy');
  }
  const maxScanRows = Number(raw.maxScanRows ?? process.env.MAX_SCAN_ROWS ?? 20);
  if (!Number.isInteger(maxScanRows) || maxScanRows < 1 || maxScanRows > 200) {
    throw new Error('maxScanRows must be an integer from 1 to 200');
  }
  // 本地凭据通道：credentialsDir 下的文件是本地凭据（如压缩包密码），
  // 原值只在本地工具间流转，绝不进 LLM 上下文。默认关闭。
  const credentialsDir = raw.credentialsDir ?? process.env.EMERALD_CREDENTIALS_DIR;
  // UAT 本地数据处理车道：只允许项目根目录内的本地转换；它不改变
  // llm/stream 与 post-execute 的出域防线，也不放行 expected/网络/数据转储。
  const localDataAccess = raw.localDataAccess ?? process.env.EMERALD_LOCAL_DATA_ACCESS ?? 'disabled';
  if (!['disabled', 'uat-local'].includes(localDataAccess)) {
    throw new Error(`invalid localDataAccess: ${localDataAccess}`);
  }
  const localDataRoot = raw.localDataRoot ?? process.env.EMERALD_LOCAL_DATA_ROOT;
  // F-1: listing 重操作超时覆写。默认值由 clinical-listing-plugin.js 按操作
  // 类型给出；此处只做形状与范围校验，避免误配成 0/负数把重操作打回 30s 默认。
  const listingTimeoutMs = raw.listingTimeoutMs
    ?? (process.env.EMERALD_LISTING_TIMEOUT_MS ? Number(process.env.EMERALD_LISTING_TIMEOUT_MS) : undefined);
  if (listingTimeoutMs !== undefined) {
    const values = typeof listingTimeoutMs === 'object' && listingTimeoutMs !== null
      ? Object.values(listingTimeoutMs) : [listingTimeoutMs];
    if (!values.length || values.some((value) => !Number.isFinite(Number(value)) || Number(value) <= 0)) {
      throw new Error('listingTimeoutMs must be a positive number of milliseconds');
    }
  }
  // 来源域（Provenance Plane）配置（2026-08-21 架构）：
  //   dataPlaneRoots     数据域——通用工具直接读取被拒，仅插件受控能力处理
  //   specPlaneRoots     规格档（spec/ALS/template 子目录）——通用读取仅结构
  //   documentPlaneRoots 辅助档——Excel 仅表头字段，文本走脱敏车道
  //   outputPlaneRoot    产物域——交付物，模型只见收据/表头
  // 全部默认空：不配置 = 与既有行为完全一致（向后兼容）。
  const asRootList = (value) => {
    if (Array.isArray(value)) return value.filter((x) => typeof x === 'string' && x.trim());
    if (typeof value === 'string' && value.trim()) return [value];
    return [];
  };
  const config = {
    ...raw,
    mode,
    dataProtectionEnabled,
    approvalId,
    approvedBy,
    maxScanRows,
    credentialsDir,
    localDataAccess,
    localDataRoot,
    listingTimeoutMs,
    dataPlaneRoots: asRootList(raw.dataPlaneRoots ?? parseRootsEnv(process.env.EMERALD_DATA_PLANE_ROOTS)),
    specPlaneRoots: asRootList(raw.specPlaneRoots ?? parseRootsEnv(process.env.EMERALD_SPEC_PLANE_ROOTS)),
    documentPlaneRoots: asRootList(raw.documentPlaneRoots ?? parseRootsEnv(process.env.EMERALD_DOCUMENT_PLANE_ROOTS)),
    outputPlaneRoot: raw.outputPlaneRoot ?? process.env.EMERALD_OUTPUT_PLANE_ROOT,
    authorizationRoot: raw.authorizationRoot ?? process.env.EMERALD_AUTHZ_ROOT,
  };
  const planeErrors = validatePlaneRoots(config);
  if (planeErrors.length) {
    throw new Error(`invalid plane roots: ${planeErrors.join('; ')}`);
  }
  return config;
}





function context(config, exec = {}) {
  const workspaceRoot = exec.agent?.session?.header?.cwd ?? config.localDataRoot;
  return {
    mode: config.mode,
    // 2026-08-21: 全局开关 - 数据保护默认打开，关闭时跳过所有数据拦截
    // 用于测试数据场景：如果拿到测试数据，其他就不存在数据出域问题
    dataProtectionEnabled: config.dataProtectionEnabled,
    // FIX-9 (BR-06.5): 身份默认值非空，Python 侧哈希真实生效。
    sessionId: exec.agent?.sessionId ?? config.sessionId ?? config.authorizationSession ?? 'unknown-session',
    userId: exec.agent?.userId ?? config.userId ?? config.authorizationUser ?? 'anonymous',
    workspaceRoot,
    localDataAccess: config.localDataAccess,
    // Web UI 为每个会话选择的 cwd 是本次工具调用的权威项目根。
    // 静态 localDataRoot 仅兼容没有会话 cwd 的旧宿主。
    localDataRoot: workspaceRoot,
    approvalId: config.approvalId,
    approvedBy: config.approvedBy,
    credentialsDir: config.credentialsDir,
  };
}

function modelRequestPayload(options) {
  const { signal, ...payload } = options;
  return payload;
}

function maskTrustedDocuments(value, token, restored = new Map(), path = []) {
  if (Array.isArray(value)) return value.map(
    (item, index) => maskTrustedDocuments(item, token, restored, [...path, index]),
  );
  if (!value || typeof value !== 'object') return value;
  if (value.type === 'text'
      && value.clinicalGuard === 'PROTECTED_DATA_SOURCE'
      && value.protectedDataToken === token
      && (value.protectedDataSource === 'sas' || value.protectedDataSource === 'external_excel')) {
    protectedSources.add(value.protectedDataSource);
    const { clinicalGuard, protectedDataSource, protectedDataToken, ...block } = value;
    return { ...block, text: 'protected data source' };
  }
  if (value.type === 'text'
      && value.clinicalGuard === 'TRUSTED_DOCUMENT_CONTENT'
      && value.trustedDocumentToken === token
      && typeof value.text === 'string') {
    restored.set(JSON.stringify([...path, 'text']), value.text);
    const { clinicalGuard, trustedDocumentToken, ...block } = value;
    return { ...block, text: 'trusted document content' };
  }
  // 2026-08-23: TRUSTED_LISTING_RECEIPT 掩码（修复 inspect 返回大量元数据时 llm/stream 误拦截）
  if (value.type === 'text'
      && value.clinicalGuard === 'TRUSTED_LISTING_RECEIPT'
      && value.trustedListingToken === token
      && typeof value.text === 'string') {
    restored.set(JSON.stringify([...path, 'text']), value.text);
    const { clinicalGuard, trustedListingToken, ...block } = value;
    return { ...block, text: 'trusted listing receipt' };
  }
  if (value.type === 'text'
      && typeof value.text === 'string'
      && value.text.includes('"clinicalGuard":"CONTROL_PATHS"')
      && value.text.includes(`"trustedControlToken":"${token}"`)) {
    try {
      const projection = JSON.parse(value.text);
      if (projection.clinicalGuard === 'CONTROL_PATHS'
          && projection.trustedControlToken === token
          && Array.isArray(projection.paths)
          && projection.paths.every((item) => typeof item === 'string')) {
        restored.set(JSON.stringify([...path, 'text']), JSON.stringify({
          ...projection,
          trustedControlToken: undefined,
        }));
        return { ...value, text: 'trusted local path control metadata' };
      }
    } catch {
      // 非 canonical JSON 继续进入普通 smart_guard，不建立豁免。
    }
  }
  return Object.fromEntries(Object.entries(value).map(
    ([key, item]) => [key, maskTrustedDocuments(item, token, restored, [...path, key])],
  ));
}

function protectedDataSourceOf(value, token) {
  const found = new Set();
  const visit = (item) => {
    if (Array.isArray(item)) {
      item.forEach(visit);
      return;
    }
    if (!item || typeof item !== 'object') return;
    if (item.type === 'text'
        && item.clinicalGuard === 'PROTECTED_DATA_SOURCE'
        && item.protectedDataToken === token
        && (item.protectedDataSource === 'sas' || item.protectedDataSource === 'external_excel')) {
      found.add(item.protectedDataSource);
    }
    Object.values(item).forEach(visit);
  };
  visit(value);
  if (found.has('sas')) return 'sas';
  if (found.has('external_excel')) return 'external_excel';
  return undefined;
}

function restoreTrustedDocuments(value, restored, path = []) {
  const original = restored.get(JSON.stringify(path));
  if (original !== undefined) return original;
  if (Array.isArray(value)) return value.map(
    (item, index) => restoreTrustedDocuments(item, restored, [...path, index]),
  );
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(
    ([key, item]) => [key, restoreTrustedDocuments(item, restored, [...path, key])],
  ));
}

const ALLOWED_CONTENT_BLOCKS = new Set(['text', 'reasoning', 'tool-call', 'tool-result']);

const LOCAL_DATA_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    clinicalGuard: { type: 'string', required: true, const: 'LOCAL_METADATA_ONLY' },
    path: { type: 'string', required: true },
    fileType: { type: 'string', required: true },
    sheets: {
      type: 'array',
      required: true,
      items: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          rowCount: { type: 'integer', required: true },
          columns: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
    },
  },
};

function registerLocalMetadataTool(ctx, runtime, config) {
  if (config.localDataAccess !== 'uat-local') return () => {};
  const promptDisposer = ctx.systemPrompt?.section?.({
    name: 'tool:local-data-metadata',
    order: 99,
    text: 'For UAT clinical source files, use local_data_metadata to inspect only schema metadata (file type, sheet names, row counts, and column names). Do not use bash, read_file, pwsh, or scripts to open source data files. The tool never returns data rows or cell values.',
  }) ?? (() => {});
  const toolDisposer = ctx.tools.register(defineTool({
    name: 'local_data_metadata',
    description: 'Inspect a UAT source file locally and return only non-value metadata: file type, sheet names, row counts, and column names. No records, cell values, subject identifiers, dates, or query text are returned.',
    parameters: {
      path: {
        type: 'string',
        required: true,
        description: 'Relative path under the current Web UI session workspace. Supported: xlsx, xls, csv, sas7bdat, xpt.',
      },
    },
    output: {
      schema: LOCAL_DATA_OUTPUT_SCHEMA,
      render: (_args, value) => [{
        type: 'text',
        text: JSON.stringify(value),
      }],
    },
    execute: async (args, exec) => {
      const response = await runtime.request({
        operation: 'inspect_local_data',
        path: args.path,
        context: context(config, exec),
      });
      if (!response.ok) throw new Error(response.reason ?? 'local metadata inspection failed');
      return {
        clinicalGuard: 'LOCAL_METADATA_ONLY',
        ...response.metadata,
      };
    },
    presentCall: (args) => ({
      card: 'generic',
      title: `Inspect local metadata: ${args.path}`,
      kind: 'read',
      locations: [{ path: args.path }],
    }),
  }));
  return () => {
    toolDisposer?.();
    promptDisposer?.();
  };
}

function validateMessageShape(messages) {
  if (!Array.isArray(messages)) return 'messages 必须是数组';
  for (const message of messages) {
    if (!message || typeof message !== 'object') return '消息必须是对象';
    if (typeof message.content !== 'string' && !Array.isArray(message.content)) {
      return '消息内容必须是字符串或 typed content 数组';
    }
    if (Array.isArray(message.content)) {
      for (const block of message.content) {
        if (!block || typeof block !== 'object' || !ALLOWED_CONTENT_BLOCKS.has(block.type)) {
          return `不支持的内容块类型: ${block?.type ?? 'unknown'}`;
        }
      }
    }
  }
  return null;
}

export default function clinicalDataGuard(ctx, rawConfig = {}) {
  const config = validateConfig(rawConfig);
  const runtime = new SecurityRuntime(config);
  const trustedDocumentToken = randomBytes(32).toString('hex');
  runtime.startHeartbeat();
  const branding = registerBranding(ctx, config);
  const localMetadataTool = registerLocalMetadataTool(ctx, runtime, config);
  const clinicalListingPlugin = registerClinicalListingPlugin(ctx, runtime, config);
  const disposers = [
    () => runtime.dispose(),
    branding,
    localMetadataTool,
    clinicalListingPlugin,
  ];

  // L3 用户决策（FIX-4 / FR-13）：outcome 为 allowed-once 时按用户选择落授权类别。
  async function requestL3Decision(exec, userPrompt) {
    if (!ctx.approval?.request) return { allowed: false, blockedNoChannel: true };
    let outcome = await ctx.approval.request({
      agent: exec.agent,
      toolName: exec.name,
      callId: exec.callId,
      signal: exec.signal,
      reason: `${userPrompt ?? '敏感临床数据需要用户决策。'} 选项：跳过（默认）/ 脱敏后继续 / 允许（需授权）`,
    });
    let choice = 'redacted-continue';
    if (typeof outcome === 'object' && outcome) {
      choice = outcome.choice ?? 'redacted-continue';
      outcome = outcome.outcome;
    }
    if (outcome !== 'allowed-once') return { allowed: false, blockedNoChannel: false };
    const category = choice === 'allow-audited' ? 'L3_ALLOW_AUDITED' : 'L3_REDACTED_CONTINUE';
    const authorization = await runtime.request({
      operation: 'authorize',
      root: config.authorizationRoot,
      user: exec.agent?.userId ?? config.authorizationUser ?? config.userId,
      session: exec.agent?.sessionId ?? config.authorizationSession ?? config.sessionId,
      category,
      operator: config.approvedBy ?? config.authorizationUser,
    });
    if (!authorization.ok) return { allowed: false, blockedNoChannel: false, authzFailed: true };
    return { allowed: true, category };
  }

  const quickGuard = ctx.tools.guard((exec) => {
    // Dedicated UAT metadata inspection has a narrower, independently validated
    // data boundary in the worker. Generic argument DLP must not reject its
    // legitimate local path before that boundary can enforce root containment.
    if (['local_data_metadata', 'clinical_listing_inspect', 'clinical_listing_run_code', 'clinical_listing_publish'].includes(exec.name)
        && config.localDataAccess === 'uat-local') {
      return undefined;
    }
    const args = exec.arguments ?? {};
    const serialized = JSON.stringify(args);
    const hit = scanDlp(serialized);
    if (hit) return `[clinical-data-guard] 工具参数包含疑似临床数据（${hit}），已阻断。`;
    return undefined;
  });
  disposers.push(quickGuard);

  const pre = ctx.on('tools/pre-execute', async (exec, next) => {
    let check;
    try {
      check = await runtime.request({
        operation: 'check_tool',
        tool: exec.name,
        args: exec.arguments ?? {},
        context: context(config, exec),
      });
    } catch (error) {
      return { kind: 'deny', reason: `[clinical-data-guard] 安全运行时不可用，已拒绝执行：${error.message}` };
    }
    if (!check.ok) {
      const localLane = check.code === 'LOCAL_DATA_ACCESS_REQUIRED'
        && config.localDataAccess === 'uat-local';
      if (localLane) {
        return { kind: 'deny', reason: `[clinical-data-guard] 本地 UAT 数据处理需要受限本地执行车道：${check.reason}` };
      }
      return { kind: 'deny', reason: `[clinical-data-guard] ${check.reason} (audit:${check.audit_id ?? 'none'})` };
    }
    // 本地数据处理放行：程序可按 ALS/spec 查询 SAS 字段并本地加工。
    // 读取级别不再拦截，数据出境保护由 post-execute 结果投影与 llm/stream 出境检查负责。
    return next();
  });
  disposers.push(pre);

  const post = ctx.on('tools/post-execute', async (exec, result, next) => {
    if (config.mode === 'enforce' && shouldReplaceResult(exec)) {
      const decision = await safeToolResult(exec, result, runtime, {
        ...config,
        workspaceRoot: context(config, exec).workspaceRoot,
        protectedDataToken: trustedDocumentToken,
      }, trustedDocumentToken);
      if (decision.needsApproval) {
        // FIX-4/FIX-13: user decisions may replace model-facing content, but
        // must never replace canonical value with a generic cross-tool shape.
        // DSH revalidates an accepted `value` against the originating tool's
        // output schema; glob/pwsh/read/get_goal/job_list therefore use content.
        if (!ctx.approval?.request) {
          return {
            kind: 'accept',
            content: [{
              type: 'text',
              text: JSON.stringify({
                clinicalGuard: 'BLOCKED',
                reason: '敏感数据需要用户决策，当前部署无审批通道，结果已 fail-closed。',
              }),
            }],
          };
        }
        const l3 = await requestL3Decision(exec, decision.userPrompt);
        if (!l3.allowed) {
          return {
            kind: 'accept',
            content: [{
              type: 'text',
              text: JSON.stringify({
                clinicalGuard: 'BLOCKED',
                reason: '用户未授权查看敏感数据组合，结果已阻断。',
              }),
            }],
          };
        }
        if (l3.category === 'L3_ALLOW_AUDITED') {
          // “允许并审计”只记录用户决策，不改变零出域边界。模型始终只见
          // token 化内容；原始 canonical value 继续留在本地执行作用域。
          return { kind: 'accept', content: decision.scrubbedContent };
        }
        // 脱敏后继续：只返回 scrubbed content，原始 value 仍留在执行局部。
        return { kind: 'accept', content: decision.scrubbedContent };
      }
      return { kind: 'accept', content: decision.content ?? result.content };
    }
    return next();
  });
  disposers.push(post);

  const stream = ctx.on('llm/stream', async function* streamGuard(options, next) {
    const shapeError = validateMessageShape(options.messages ?? []);
    if (shapeError) throw new Error(`[clinical-data-guard] ${shapeError}`);
    const restoredDocuments = new Map();
    const payload = maskTrustedDocuments(
      modelRequestPayload(options), trustedDocumentToken, restoredDocuments,
    );
    const protectedDataSource = protectedDataSourceOf(
      modelRequestPayload(options), trustedDocumentToken,
    );
    const check = await runtime.request({
      operation: 'check_llm',
      payload,
      context: {
        ...context(config),
        scanScope: 'full_generate_options',
        ...(protectedDataSource ? { protectedDataSource } : {}),
      },
    });
    if (!check.ok) {
      if (check.code === 'SECURITY_UNAVAILABLE') throw new Error(check.reason);
      throw new Error(`[clinical-data-guard] 临床数据出域已阻断 (audit:${check.audit_id ?? 'none'})`);
    }
    // worker 返回经过来源边界检查的载荷。普通需求保持原样；只有受控调用方
    // 显式产生的 token 才会存在于上下文。只传入新对象，避免修改只读属性。
    if (check.payload && typeof check.payload === 'object' && !Array.isArray(check.payload)) {
      // DSH 传入的 options 可能含只读 provider/model；禁止就地修改。
      // 只复制可枚举载荷字段，并用脱敏载荷覆盖原值。
      yield* next({
        ...options,
        ...restoreTrustedDocuments(check.payload, restoredDocuments),
      });
      return;
    }
    yield* next();
  });
  disposers.push(stream);

  return () => disposers.reverse().forEach((dispose) => dispose());
}

clinicalDataGuard.inject = ['tools', 'llm', 'webServer', 'systemPrompt'];
