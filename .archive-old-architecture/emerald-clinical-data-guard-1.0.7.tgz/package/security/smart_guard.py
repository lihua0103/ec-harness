"""智能数据识别与统一 token 化 (Smart Guard) — 白名单式安全证明

架构倒转（用户需求 2026-08-20）：
旧体系是黑名单——枚举"什么长得像临床数据"，认出才处置；每个新场景
（新编号形态/新日期写法/多表头/横纵向表）都要补一条正则，补丁永远追不上
真实形态全集：漏认=泄露，误认=BLOCK 钉死会话。

本模块只回答一个问题："这个 token 能否被证明不是数据值？"
  能证明（纯字母词/散文/中文文本/协议日程标签/CDISC 字段名/路径/UUID/
  已 token 化产物）→ 原样放行；
  证明不了 → HMAC token 化（[KIND:hex8]，同值同 token）后放行。

三个动作，没有第四个：
  PASS      可证明安全
  TOKENIZE  其余一切 —— 新形态自动落进来，无需新正则
  BLOCK     仅一条硬红线：大规模数据转储（数据行数超阈值）

为什么这终结补丁竞赛：
  1. 泄露方向：任何含数字的值（编号/日期/测量值，无论什么格式）默认
     token 化；数据行里的字母值（AE 术语/状态/性别）随行连坐 token 化。
     不认识 ≠ 放过。
  2. 误拦方向：除转储红线外没有 BLOCK。误判的代价从"会话钉死"降为
     "多 hash 一个值"，模型仍可 join/去重/计数，harness 工作流不中断。
  3. 自愈：token 形态 [KIND:hex8] 属于可证明安全类，重扫幂等，
     历史误报不会把会话永久拦死。

旧模式库（patterns.py）降级为"语义标注器"：能认出的值打上 SUBJ/DATE/CODE
语义前缀帮助 LLM 理解 token 角色；认不出的兜底为 VAL/NUM/TEXT。
正则从守门员变成标签工，误报不再有代价。

已知残余风险（明示接受，与体量红线互补）：
  - 散文行中 ≤2 位的纯字母数字小编号（Day 3 / v2 / 第5条）放行——
    协议日程与版本号的可读性需要；孤立两位数不构成可识别的患者数据。
  - 无任何数字上下文的孤立中文/字母词（如单独一格"张三"）与散文词
    不可分；真实导出行携带日期/编号，会触发整行连坐 token 化。
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, List, Tuple

from security.patterns import (
    CDISC_CORE_FIELDS,
    DATE_PATTERNS,
    MEDICAL_CODE_PATTERNS,
    SUBJECT_ID_PATTERNS,
    ends_with_alpha_segment,
    is_document_version_number,
    operational_spans,
)
from security.tokenizer import token_for

# 历史体量阈值，仅为兼容 is_mass_data_dump 的默认参数签名而保留；已不参与判定。
MASS_DUMP_DATA_LINES = 200

# 已 token 化产物的行内形态（tokenizer.TOKEN_RE 是全匹配锚定版，这里要行内找）。
_TOKEN_INLINE_RE = re.compile(r'\[[A-Z]{2,6}:[0-9a-f]{8}\]')

_CJK_RE = re.compile(r'[一-鿿]')

# ---------------------------------------------------------------------------
# CJK 数字运行段归一化（2026-08-21 dumpxl 事故：编码规避通道）
# ---------------------------------------------------------------------------
# 真实事故：会话 agent 自写 dumpxl.py 把阿拉伯数字映射成中文数字
# （5.0→五.零、D1→D一、28天→二八天），注释直言 "so the auto-redaction
# layer doesn't eat the output"。形态识别车道全部失效。
# 判据：**运行段**（≥2 个 CJK 数字，中间可夹 .,-,:：）才归一——
# "一零一"→101、"五.零"→5.0、"二八"→28；单个 CJK 数字（"一个"、"第一行"）
# 是自然中文散文，保持原样（与散文小编号豁免同口径）。
# 残余（明示接受）：含十/百/千/万的复合写法（"一百零一"）不在此列；
# 路径中的 CJK 数字段会被改写为阿拉伯形态（操作性标识含 CJK 数字段罕见）。
_CJK_DIGIT_TABLE = str.maketrans('零〇一二三四五六七八九', '00123456789')
_CJK_RUN_RE = re.compile(
    r'[零〇一二三四五六七八九](?:[.,\-:：]?[零〇一二三四五六七八九])+'
)


def _normalize_cjk_digit_runs(line: str) -> str:
    return _CJK_RUN_RE.sub(lambda m: m.group(0).translate(_CJK_DIGIT_TABLE), line)

# 英文虚词（散文判据用；不追求完备——散文有多个虚词，数据行一个都没有）。
_FUNC_WORDS = frozenset("""
the a an and or of to in for on with by is are was were be been being
shall should must may might will would can could do does did done
all any each per not no nor if then than as at from into over under
this that these those it its their there which who whom whose when where
""".split())

# 协议日程标签（Day 3 / Week 12 / Cycle 2 / D14 / V5 / Visit 3）——
# 方案/spec 的结构词汇，不是受试者数据值。纯格式判据，无关键词豁免语义。
_SCHEDULE_LABEL_RE = re.compile(
    r'^(?:day|week|cycle|visit|month|hour|d|c|w|v|m)\s?-?\d{1,3}$', re.IGNORECASE)
# 访视窗标签形态 "Date(D1)" / "Dose(C2)+"（历史误报 20260820_150945 的根治点：
# 此前是 BLOCK 误报，现在即使不豁免也只是多 hash 一个标签；豁免保 spec 可读）。
_SPEC_LABEL_RE = re.compile(r'^[A-Za-z]{1,12}\([A-Za-z]?\d{1,3}\)[+\-]?$')

_EDGE_PUNCT = '.,;:!?()[]{}<>"\'`|'

# 2026-08-21: 文件元信息豁免模式
# tar/ls/dir 等命令输出的文件列表格式，不是患者数据

# 文件名后跟数字的模式（文件大小）
# 例如：ae.sas7bdat 911513 120
# 其中 911513 是文件大小，不是患者数据
# 匹配：第一部分是 "扩展名 数字"，如 "ae.sas7bdat 911513"
_FILE_META_RE = re.compile(
    r'^\S+\.(?:sas7bdat|xlsx|xls|csv|zip|txt|py|js|md)\s+\d+(?:\s+\d+)*'
)

# PowerShell 命令输出格式（路径 => 目标）
# 例如：python.exe => C:\Users\...\python.exe
_PWSH_PATH_RE = re.compile(r'\w+\.exe\s*=>\s*')

# 目录列表格式（Mode Name Length 表头行）
# 例如：Mode   Name            Length
_DIRECTORY_HEADER_RE = re.compile(
    r'^(?:Mode|[d-])|(?:Name|Size|Length)\s*$',
    re.IGNORECASE
)

# 如果一行包含目录表头关键词，认为是目录列表，不是数据
def _looks_like_directory_list(line: str) -> bool:
    """判断一行是否像目录列表（Mode/Name/Length 格式）。"""
    line_lower = line.lower()
    # 检查是否包含目录列表特征
    has_mode = 'mode' in line_lower
    has_name = 'name' in line_lower
    has_size = 'size' in line_lower
    has_length = 'length' in line_lower
    # 如果有 2 个以上目录列表关键词，认为是目录头
    return sum([has_mode, has_name, has_size, has_length]) >= 2

# 语义标注顺序：格式更具体的先标（与 tokenizer.tokenize_clinical_text 同理由）。
# SUBJECT_ID_PATTERNS 所有模式按构造都要求含数字，纯字母连字词（state-of-the-art）
# 不会命中——这是它可安全用于散文的前提。desc 保留：散文车道的文档编号豁免
# 需要区分模式（纯格式判据，非关键词豁免）。
_SEMANTIC_PASSES: List[Tuple[re.Pattern, str, str]] = (
    [(p, 'DATE', d) for p, d in DATE_PATTERNS]
    + [(p, 'CODE', d) for p, d in MEDICAL_CODE_PATTERNS]
    + [(p, 'SUBJ', d) for p, d in SUBJECT_ID_PATTERNS]
)


@dataclass
class ScrubStats:
    """一次扫描的汇总统计（零数据值，可直接进审计）。"""
    lines_total: int = 0
    lines_changed: int = 0
    data_lines: int = 0
    tokens_hashed: int = 0

    def merge(self, other: "ScrubStats") -> None:
        self.lines_total += other.lines_total
        self.lines_changed += other.lines_changed
        self.data_lines += other.data_lines
        self.tokens_hashed += other.tokens_hashed


def is_mass_data_dump(stats: ScrubStats, threshold: int = MASS_DUMP_DATA_LINES) -> bool:
    """恒为 False：体量不是判据。

    2026-08-23 事故（session-533e96b1，turn 2）：会话上下文累积到 241 个
    "数据行" 命中 200 硬阈值，整轮被 "临床数据出域已阻断" 打断。载荷里
    没有任何 SAS 数据集或 doc 外 Excel 的 data 数据——全是 spec 正文、
    plan JSON、工具收据和模型自己的推理文本。行数越多只说明会话越长。

    判据回到来源域：真实 records 由 protectedDataSource（sas /
    external_excel）在同一检查点硬阻断，与体量无关。签名保留，调用方
    （worker 的 needs_user、egress_checkpoint 的体量红线）无需改造。
    """
    return False


# ---------------------------------------------------------------------------
# 行级散文判据
# ---------------------------------------------------------------------------

def _visible(token: str) -> str:
    """token 中"还未被 hash 的部分"——已 token 化片段不参与任何判定。"""
    return _TOKEN_INLINE_RE.sub('', token)


def _is_prose(text: str) -> bool:
    """判断一行（已剥离操作性区间）是否散文/需求文本。

    统计判据而非形态枚举：散文有虚词/成句中文/低数字密度；
    数据行是分隔符结构 + 高数字 token 占比。判错的代价是不对称的：
    散文误判为数据行 → 多 hash 几个词（可用性小损）；
    数据行误判为散文 → 数字 token 仍被 hash（安全不失守，见 _scrub_line）。
    """
    tokens = text.split()
    if not tokens:
        return True
    digit_toks = sum(1 for t in tokens if any(c.isdigit() for c in _visible(t)))
    delims = text.count('|') + text.count('\t') + text.count(';')
    if delims >= 3 and digit_toks >= 2:
        return False
    if digit_toks / len(tokens) >= 0.4:
        return False
    words = [t.strip(_EDGE_PUNCT).lower() for t in tokens]
    func_hits = sum(1 for w in words if w in _FUNC_WORDS)
    cjk_chars = len(_CJK_RE.findall(text))
    alpha_words = sum(1 for w in words if w.isalpha())
    return func_hits >= 2 or cjk_chars >= 6 or (alpha_words >= 6 and digit_toks <= 1)


# ---------------------------------------------------------------------------
# token 级白名单判定
# ---------------------------------------------------------------------------

def _split_edge_punct(token: str) -> Tuple[str, str, str]:
    core = token.strip(_EDGE_PUNCT)
    if not core:
        return '', token, ''
    start = token.find(core)
    return token[:start], core, token[start + len(core):]


def _digit_replacement(core: str, prose: bool) -> str | None:
    """含数字 token 的处置。None = 可证明安全放行；否则返回替换 token。"""
    visible = _visible(core)
    digits = sum(c.isdigit() for c in visible)
    if digits == 0:
        return None
    if _SCHEDULE_LABEL_RE.match(visible) or _SPEC_LABEL_RE.match(core):
        return None  # 协议日程/访视窗标签：结构词汇
    if prose and digits <= 2 and (
            visible.isdigit()
            or re.fullmatch(r'[\d.]+', visible)
            or (visible.isalnum() and not visible[0].isdigit())):
        return None  # 散文中的小编号/章节号（Day 3 / v2 / 3.2），明示接受的残余风险
    if prose and '-' in visible and not visible[0].isdigit() \
            and ends_with_alpha_segment(visible):
        return None  # 散文中的字母末段文档编号（CGB3002-TEST），出域侧同款纯格式判据
    kind = 'NUM' if visible.isdigit() else 'VAL'
    return token_for(core, kind)


def _word_is_safe_in_data_row(core: str) -> bool:
    """数据行中字母/中文 token 的白名单：结构词汇可留，值词汇连坐 hash。

    表头行天然不含数字 token，不会走到这里（整行原样放行——需求3：
    表头结构字段可读）。走到这里说明本行已有值被 hash，剩余字母词
    （AE 术语/状态/性别/人名）是同一行的患者级数据，必须连坐。
    """
    lowered = core.lower()
    if lowered in _FUNC_WORDS or lowered in CDISC_CORE_FIELDS:
        return True
    if _SCHEDULE_LABEL_RE.match(core) or _SPEC_LABEL_RE.match(core):
        return True
    return False


# ---------------------------------------------------------------------------
# 行处理
# ---------------------------------------------------------------------------

# 段级保护区：语义/兜底两个 pass 都不得触碰的形态。
#   1. 已产出的 token（幂等性根基——重扫绝不二次 hash）
#   2. 协议日程标签短语（Day 14 / Week 12 / Visit 3，跨空格，逐词判定看不见）
#   3. 访视窗标签（Date(D1) / Dose(C2)+）
_PROTECT_RES = [
    _TOKEN_INLINE_RE,
    re.compile(r'\b(?:day|week|cycle|visit|month|hour)\s?-?\d{1,3}\b', re.IGNORECASE),
    re.compile(r'\b[A-Za-z]{1,12}\([A-Za-z]?\d{1,3}\)[+\-]?'),
]


def _stash_protected(seg: str) -> Tuple[str, List[str], int]:
    """把保护区形态换成无数字占位符（索引用字母编码，占位符本身绝不会
    被任何数字/日期模式命中）。返回 (换后文本, 原文列表, 其中已有token数)。"""
    stashed: List[str] = []
    pre_tokens = 0

    def _encode(i: int) -> str:
        return ''.join(chr(97 + int(d)) for d in str(i))

    for idx, regex in enumerate(_PROTECT_RES):
        def _repl(m, is_token=(idx == 0)):
            nonlocal pre_tokens
            if is_token:
                pre_tokens += 1
            stashed.append(m.group(0))
            return f'\x00{_encode(len(stashed) - 1)}\x00'
        seg = regex.sub(_repl, seg)
    return seg, stashed, pre_tokens


def _restore_protected(seg: str, stashed: List[str]) -> str:
    def _decode(s: str) -> int:
        return int(''.join(str(ord(c) - 97) for c in s))
    return re.sub(r'\x00([a-z]+)\x00', lambda m: stashed[_decode(m.group(1))], seg)


def _merged_op_spans(line: str) -> List[Tuple[int, int]]:
    merged: List[List[int]] = []
    for a, b in sorted(operational_spans(line)):
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def _scrub_segment(seg: str, prose: bool) -> Tuple[str, int, int]:
    """处理一个非操作性文本段。返回 (新文本, hash的值token数, hash的词token数)。"""
    # 保护区 stash：已有 token / 日程标签 / 访视窗标签先摘走，
    # 任何后续 pass 都看不见它们——这同时给出幂等性与 spec 结构词保护。
    seg, stashed, pre_tokens = _stash_protected(seg)

    # 语义标注：认得出的形态给准确前缀（SUBJ/DATE/CODE），帮助 LLM 推理。
    # 标注产物计入 value_hashed——否则"仅语义命中"的数据行不计入 data_lines，
    # 体量红线被架空。
    # 散文（spec/需求文本）车道复用出域侧的纯格式文档编号判据：
    # DVP20260610（标识+YYYYMMDD）与 DS5565-0002-NIS-MA（字母末段）是文档
    # 编号而非受试者编号，spec 可读性依赖它们原样保留（需求2）。数据行
    # （非散文）不豁免——同形态出现在数据行按数据处置，fail-safe。
    value_hashed = 0
    for pattern, kind, desc in _SEMANTIC_PASSES:
        def _repl(m, kind=kind, desc=desc):
            nonlocal value_hashed
            exempt = prose and kind == 'SUBJ' and (
                (desc == "字母前缀编号" and is_document_version_number(m.group(0)))
                or (desc in ("USUBJID格式", "复合站点编号")
                    and ends_with_alpha_segment(m.group(0))))
            if exempt:
                stashed.append(m.group(0))  # stash 原文防兜底数字 pass 误伤
            else:
                value_hashed += 1
                stashed.append(token_for(m.group(0), kind))
            i = len(stashed) - 1
            return '\x00' + ''.join(chr(97 + int(d)) for d in str(i)) + '\x00'
        seg = pattern.sub(_repl, seg)



    # 白名单兜底：语义标注漏掉的一切含数字 token 一律 hash。
    # 与占位符同词的残段（PT-2026-XY-0099 被语义标注吃掉前三段后剩 "-0099"）
    # 不能整词跳过——按占位符切开，含数字的残片逐片 hash，不留裸数字。
    matches = list(re.finditer(r'\S+', seg))
    replacements: dict[int, str] = {}
    placeholder_re = re.compile(r'\x00[a-z]+\x00')
    for i, m in enumerate(matches):
        word = m.group(0)
        if '\x00' in word:
            pieces = placeholder_re.split(word)
            if any(any(c.isdigit() for c in piece) for piece in pieces):
                rebuilt, pos = [], 0
                for pm in placeholder_re.finditer(word):
                    piece = word[pos:pm.start()]
                    if any(c.isdigit() for c in piece):
                        value_hashed += 1
                        piece = token_for(piece, 'VAL')
                    rebuilt.append(piece + pm.group(0))
                    pos = pm.end()
                tail = word[pos:]
                if any(c.isdigit() for c in tail):
                    value_hashed += 1
                    tail = token_for(tail, 'VAL')
                replacements[i] = ''.join(rebuilt) + tail
            continue
        prefix, core, suffix = _split_edge_punct(word)
        if not core:
            continue
        repl = _digit_replacement(core, prose)
        if repl is not None:
            replacements[i] = prefix + repl + suffix
            value_hashed += 1

    # 数据行连坐：本段行内已有值被 hash（含此前轮次的 token）→ 剩余非白名单
    # 字母/中文词也是同行患者级数据（AE 术语、状态、人名），一并 hash。
    word_hashed = 0
    row_has_values = value_hashed > 0 or pre_tokens > 0
    if not prose and row_has_values:
        for i, m in enumerate(matches):
            if i in replacements or '\x00' in m.group(0):
                continue
            prefix, core, suffix = _split_edge_punct(m.group(0))
            if not core or not any(c.isalpha() for c in core):
                continue  # 空/纯符号（分隔符等）
            if _word_is_safe_in_data_row(core):
                continue
            replacements[i] = prefix + token_for(core, 'TEXT') + suffix
            word_hashed += 1

    if replacements:
        out: List[str] = []
        last = 0
        for i, m in enumerate(matches):
            if i in replacements:
                out.append(seg[last:m.start()])
                out.append(replacements[i])
                last = m.end()
        out.append(seg[last:])
        seg = ''.join(out)
    return _restore_protected(seg, stashed), value_hashed, word_hashed


def _scrub_line(line: str, profile: str) -> Tuple[str, bool, int]:
    """处理一行。返回 (新行, 是否数据行, hash总数)。

    2026-08-21 修复：
    - 目录列表行（Mode/Name/Length）不脱敏
    - 文件元信息行（文件名 + 数字大小）不脱敏

    操作性区间（路径/文件名）原样保留。
    """
    # 2026-08-21: 目录列表豁免（目录表头行不脱敏）
    if _looks_like_directory_list(line):
        return line, False, 0

    spans = _merged_op_spans(line)
    segs: List[Tuple[bool, str]] = []
    last = 0
    for a, b in spans:
        if a > last:
            segs.append((False, line[last:a]))
        segs.append((True, line[a:b]))
        last = b
    if last < len(line):
        segs.append((False, line[last:]))

    plain = ' '.join(seg for is_op, seg in segs if not is_op)
    prose = _is_prose(plain)
    # spec 车道：散文按散文，仅数据形态行做 hash——调用方声明来源是
    # spec/ALS/template（需求2：需求文档全文可读）时用 profile="spec"。
    # strict（默认）与 spec 的差别只在散文行小编号的宽严，安全兜底相同。

    # 2026-08-21: 文件元信息豁免
    # tar/ls/dir 等命令输出的文件列表格式：ae.sas7bdat 911513 120
    # 数字是文件大小，不是患者数据
    if not prose and _FILE_META_RE.match(line):
        return line, False, 0

    # 2026-08-21: PowerShell 路径输出格式放行
    # python.exe => C:\Users\...\python.exe
    if not prose and _PWSH_PATH_RE.search(line):
        return line, False, 0

    out: List[str] = []
    value_hashed = word_hashed = 0
    for is_op, seg in segs:
        if is_op:
            out.append(seg)
            continue
        new_seg, v, w = _scrub_segment(seg, prose or (profile == 'spec'))
        out.append(new_seg)
        value_hashed += v
        word_hashed += w
    is_data_row = (not prose) and value_hashed > 0
    return ''.join(out), is_data_row, value_hashed + word_hashed


# ---------------------------------------------------------------------------
# 行切分（真实换行 + JSON 转义换行）
# ---------------------------------------------------------------------------
# 真实缺陷（2026-08-21 RBQM_test 实测）：工具结果在 tool-result-guard 里先经
# JSON.stringify 再送 scrub_text，多行输出的换行变成**字面两字符** "\\n"，
# str.splitlines() 看不见 → 整个目录清单被当成"一行"。一行里数字 token 占比高
# → _is_prose 判非散文 → 触发"数据行连坐"，把表头 Mode/Name/Length 与目录名
# 一并 TEXT hash 掉（用户观感"脱敏过头"）。
# 按行切分是 _is_prose / 连坐判据的作用域前提，必须在此处恢复。
_LINE_SPLIT_RE = re.compile(r'\\r\\n|\\n|\\r|\r\n|\n|\r')


def _split_lines(text: str) -> List[Tuple[str, str]]:
    """切成 [(行内容, 行分隔符)]，分隔符原样保留以保证输出可无损重组。

    同时识别真实换行与 JSON 转义换行（字面 \\n），两者都是行边界。
    """
    parts: List[Tuple[str, str]] = []
    pos = 0
    for m in _LINE_SPLIT_RE.finditer(text):
        parts.append((text[pos:m.start()], m.group(0)))
        pos = m.end()
    parts.append((text[pos:], ''))
    return parts


# ---------------------------------------------------------------------------
# 公共 API
# ---------------------------------------------------------------------------

def smart_scrub_text(text: str, profile: str = 'strict') -> Tuple[str, ScrubStats]:
    """对任意文本做白名单式统一 token 化。

    保证（幂等）：输出再扫一遍不再变化——token 形态属于可证明安全类。
    保证（零出域）：除散文小编号与操作性路径外，任何含数字的值都不以
    原文出现在输出里；数据行的字母值随行连坐。代码、日志和 fixture 也
    必须经过同一规则，因为其中可能嵌入真实临床常量。
    """
    stats = ScrubStats()
    if not isinstance(text, str) or not text:
        return text, stats

    out_parts: List[str] = []
    for line, separator in _split_lines(text):
        stats.lines_total += 1
        # CJK 数字运行段先归一化（编码规避防线），再进入行级判据。
        normalized = _normalize_cjk_digit_runs(line)
        new_line, is_data, hashed = _scrub_line(normalized, profile)
        if is_data:
            stats.data_lines += 1
        if hashed:
            stats.lines_changed += 1
            stats.tokens_hashed += hashed
        out_parts.append(new_line)
        out_parts.append(separator)
    return ''.join(out_parts), stats


# 仅 GenerateOptions 顶层的模型采样参数可作为协议配置保留数字。
# 任意消息、工具结果、arguments 或未知嵌套对象中的数字都属于不受信数据。
_TOP_LEVEL_NUMERIC_OPTIONS = frozenset({
    "temperature", "maxTokens", "max_tokens", "topP", "top_p", "topK", "top_k",
    "seed", "n", "frequencyPenalty", "frequency_penalty", "presencePenalty",
    "presence_penalty", "timeout", "timeoutMs", "timeout_ms",
})

# 技术 ID 只有在 GenerateOptions 顶层且形态可验证时才保留。不能按键名在
# 任意深度豁免，否则业务对象中的 id/timestamp 会成为确定性出域旁路。
_TOP_LEVEL_TECHNICAL_IDS = {
    "id": re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", re.I),
    "requestId": re.compile(r"^(?:req|request)[_-][A-Za-z0-9_-]{6,128}$"),
    "request_id": re.compile(r"^(?:req|request)[_-][A-Za-z0-9_-]{6,128}$"),
    "toolCallId": re.compile(r"^call_[A-Za-z0-9_-]{6,128}$"),
    "tool_call_id": re.compile(r"^call_[A-Za-z0-9_-]{6,128}$"),
    "traceId": re.compile(r"^[0-9a-f]{16,32}$", re.I),
    "trace_id": re.compile(r"^[0-9a-f]{16,32}$", re.I),
}


def _record_structured_value(stats: ScrubStats) -> None:
    stats.lines_total += 1
    stats.lines_changed += 1
    stats.data_lines += 1
    stats.tokens_hashed += 1

def smart_scrub_structure(payload: Any, profile: str = 'strict',
                          _stats: ScrubStats | None = None,
                          _path: Tuple[str, ...] = ()) -> Tuple[Any, ScrubStats]:
    """递归 token 化任意嵌套结构（llm/stream 出域保底的载荷形态）。

    - 字符串值与键名走 smart_scrub_text；
    - 仅顶层、形态有效的协议 ID 可保留；
    - 仅顶层已知模型采样参数可保留数字；
    - 其他数字标量统一 token 化，布尔值与空值保留。
    """
    stats = _stats if _stats is not None else ScrubStats()
    if isinstance(payload, str):
        scrubbed, s = smart_scrub_text(payload, profile)
        stats.merge(s)
        return scrubbed, stats
    if isinstance(payload, dict):
        result = {}
        for key, value in payload.items():
            key_str = str(key)
            new_key, ks = smart_scrub_text(key_str, profile)
            stats.merge(ks)
            is_top_level = not _path
            id_pattern = _TOP_LEVEL_TECHNICAL_IDS.get(key_str) if is_top_level else None
            if id_pattern and isinstance(value, str) and id_pattern.fullmatch(value):
                result[new_key] = value
                continue
            if (is_top_level and key_str in _TOP_LEVEL_NUMERIC_OPTIONS
                    and isinstance(value, (int, float)) and not isinstance(value, bool)):
                result[new_key] = value
                continue
            new_value, _ = smart_scrub_structure(
                value, profile, stats, _path + (key_str,))
            result[new_key] = new_value
        return result, stats
    if isinstance(payload, list):
        return [smart_scrub_structure(item, profile, stats, _path + ("[]",))[0]
                for item in payload], stats
    if isinstance(payload, bool) or payload is None:
        return payload, stats
    if isinstance(payload, (int, float)):
        _record_structured_value(stats)
        return token_for(str(payload), "VAL"), stats
    return payload, stats
