"""DSH 临床数据守卫的常驻安全检查进程。

协议：每行一个 JSON 请求，每行一个 JSON 响应。进程只输出脱敏摘要，
任何导入或检查异常都转换为 fail-closed 响应，绝不放行未知故障。

FIX-3 (R-6 / AR-2.9): 所有异常回执经 sanitize_error 统一脱敏（路径→[PATH]、
受试者/日期→占位），绝不外泄 str(exc) 原文与本地路径。
FIX-6 (AR-2.6): 单行解析失败返回 SECURITY_UNAVAILABLE 并继续服务后续请求。
FIX-8 (FR-06-03): inspect_file 遍历全部 sheet 并使用配置 max_scan_rows。
FIX-9 (BR-06.5): 上下文键名统一（camelCase/snake_case 均可消费）。
L3_ALLOW_AUDITED 仅作为本地审计决策记录，不改变模型零出域边界。
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any

from security.ai_operations_monitor import (
    AIOperationMonitor,
    DangerousOperationBlocked,
    check_tool_call,
)
from security.data_egress_guard import (
    DataRiskLevel,
    ClinicalDataDetector,
    StreamingScrubber,
)
from security.egress_authz import authorize_category, consume_category, is_authorizable
from security.egress_checkpoint import EgressViolation, check_egress_v2
from security.local_data_inspector import LocalDataInspectionError, inspect_local_data
from security.data_egress_guard import scan_xlsx_sheet_safe
from security.patterns import clean_surrogates, sanitize_error
from security.smart_guard import smart_scrub_text


def _result(ok: bool, **fields: Any) -> dict[str, Any]:
    return {"ok": ok, **fields}


# E-2（2026-08-22 e2e 审计）：worker 启动依赖预检清单，与 requirements.txt 对齐。
# 此前落在缺依赖解释器上的 worker 会在首个重操作时崩溃，traceback 写入已失效
# stderr 句柄产生 EBADF，以无语义方式杀掉整轮运行。启动即 fail-fast：
# stdout 输出一条结构化横幅并退出，Node 侧捕获后给出可行动诊断。
WORKER_REQUIRED_MODULES = ("pandas", "pyreadstat", "openpyxl", "xlrd", "pyzipper")


def missing_worker_dependencies(importer=None, stop_on_first: bool = False):
    """返回缺失的必需依赖名列表；全部齐备时为空列表。importer 可注入测试。

    stop_on_first=True 时命中首个缺失立即返回——预检线程据此第一时间发
    横幅退出，不等其余重依赖（pandas 等导入需秒级）完成。
    """
    import importlib

    import_module = importer or importlib.import_module
    missing: list[str] = []
    for name in WORKER_REQUIRED_MODULES:
        try:
            import_module(name)
        except ImportError as exc:
            missing.append(str(getattr(exc, "name", None) or name))
            if stop_on_first:
                break
    return missing


def _emit(response: dict[str, Any]) -> None:
    """安全写出响应行（真实故障修复：孤立代理字符）。

    DSH harness 的 JSON 可携带 \\udXXX 孤立代理（读 GBK 文件名等场景），
    直接 ensure_ascii=False 写 stdout 会抛 UnicodeEncodeError 杀死 worker，
    导致后续全部请求挂起。任何失败都不允许中断服务循环。
    """
    try:
        line = clean_surrogates(json.dumps(response, ensure_ascii=False, separators=(",", ":")))
        sys.stdout.write(line + "\n")
    except UnicodeEncodeError:
        sys.stdout.write(json.dumps(
            {"ok": False, "code": "SECURITY_UNAVAILABLE",
             "reason": "response encoding failure", "requestId": response.get("requestId")},
            ensure_ascii=True,
        ) + "\n")
    sys.stdout.flush()


class _XlrdSheetAdapter:
    """把 xlrd sheet 适配为 scan_xlsx_sheet_safe 需要的 openpyxl 风格接口。"""

    def __init__(self, sheet):
        self._sheet = sheet
        self.max_row = sheet.nrows

    def iter_rows(self, min_row=1, values_only=True):
        for index in range(min_row - 1, self._sheet.nrows):
            yield tuple(self._sheet.row_values(index))


class _XlrdWorkbook:
    """把 xlrd workbook 适配为 openpyxl 风格的 sheetnames/下标访问。"""

    def __init__(self, workbook):
        self._workbook = workbook

    @property
    def sheetnames(self):
        return self._workbook.sheet_names()

    def __getitem__(self, name):
        return _XlrdSheetAdapter(self._workbook.sheet_by_name(name))


def _scan_workbook(workbook, max_rows):
    """FIX-8 (FR-06-03): 遍历全部 sheet，使用配置 max_scan_rows，返回首个用户决策提示。"""
    prompt = None
    options = None
    for sheet_name in workbook.sheetnames:
        report = scan_xlsx_sheet_safe(workbook[sheet_name], sheet_name, max_rows=max_rows)
        found = report.get("user_prompt") or {}
        if found:
            prompt = found.get("message")
            options = found.get("options")
            break
    return prompt, options


def _normalize_context(context: Any) -> dict[str, Any]:
    """FIX-9: Node 侧 camelCase 上下文键名统一为 Python 消费侧 snake_case。"""
    if not isinstance(context, dict):
        return {}
    normalized = dict(context)
    for camel, snake in (("sessionId", "session_id"), ("userId", "user_id")):
        if snake not in normalized or normalized.get(snake) in (None, ""):
            normalized[snake] = normalized.get(camel)
    return normalized


def _handle(request: dict[str, Any]) -> dict[str, Any]:
    operation = request.get("operation")
    context = _normalize_context(request.get("context"))
    mode = str(context.get("mode", "enforce")).lower()

    # 兼容测试数据环境关闭主动阻断；零出域脱敏不受该开关影响。
    data_protection_enabled = context.get("dataProtectionEnabled", True)

    if operation == "check_tool":
        try:
            tool_name = str(request.get("tool", ""))
            args = request.get("args", {})
            # The dedicated local metadata tool is itself the capability boundary:
            # it is allowed only in explicit UAT-local mode and only its worker
            # implementation can open local source files.
            if tool_name == "local_data_metadata":
                if context.get("localDataAccess") != "uat-local":
                    return _result(False, code="LOCAL_DATA_ACCESS_REQUIRED",
                                   reason="local metadata inspection is disabled")
                return _result(True, action="allow")
            # First apply the UAT capability policy, then the generic dangerous-
            # operation monitor. Generic shell/read/write access to source files
            # is never a substitute for local_data_metadata.
            monitor = AIOperationMonitor()
            try:
                monitor.check_local_data_policy(tool_name, args, context)
            except DangerousOperationBlocked as exc:
                return _result(False, code="LOCAL_DATA_ACCESS_REQUIRED",
                               audit_id=exc.audit_id, reason=exc.threat.reason)
            check_tool_call(tool_name, args, context)
            return _result(True, action="allow")
        except DangerousOperationBlocked as exc:
            if mode == "shadow":
                return _result(True, action="observed", audit_id=exc.audit_id,
                               reason=exc.threat.reason)
            return _result(False, code="DANGEROUS_OPERATION", audit_id=exc.audit_id,
                           reason=exc.threat.reason)

    if operation == "check_llm":
        # 数据保护关闭时原样放行；token 化仅属于明确的数据二次处理车道。
        if not data_protection_enabled:
            payload = request.get("payload", {})
            return _result(True, action="allow", payload=payload,
                          tokens_hashed=0, data_lines=0)
        payload = request.get("payload", {})
        try:
            evidence = check_egress_v2(payload, context)
            return _result(True, action=("scrubbed" if evidence.get("tokens_hashed") else "allow"), **evidence)
        except EgressViolation as exc:
            if mode == "shadow":
                return _result(True, action="observed", audit_id=exc.audit_id,
                               threats=len(exc.threats))
            return _result(False, code="EGRESS_VIOLATION", audit_id=exc.audit_id,
                           threats=len(exc.threats))

    if operation == "inspect_local_data":
        if context.get("localDataAccess") != "uat-local":
            return _result(
                False,
                code="LOCAL_DATA_ACCESS_REQUIRED",
                reason="this UAT task requires the explicit local metadata inspection lane",
            )
        try:
            metadata = inspect_local_data(
                str(context.get("localDataRoot") or ""),
                str(request.get("path") or ""),
            )
        except LocalDataInspectionError as exc:
            return _result(False, code="LOCAL_DATA_INSPECTION_DENIED", reason=str(exc))
        except Exception as exc:
            return _result(False, code="SECURITY_UNAVAILABLE", reason=sanitize_error(exc))
        return _result(True, action="local-metadata", metadata=metadata)

    # 2026-08-24 架构重设计（用户裁决）：IR 车道（listing_validate_plan /
    # listing_execute）退役，由代码车道（listing_run_code / listing_publish）替代。
    # 模型全权编写 pandas 代码；沙箱保证 SAS 行级数据与 doc/ 外数据零出域。
    if operation in {"listing_inspect", "listing_run_code", "listing_publish"}:
        if context.get("localDataAccess") != "uat-local":
            return _result(False, code="LOCAL_DATA_ACCESS_REQUIRED",
                           reason="clinical listing requires uat-local mode")
        # E-1（2026-08-22 e2e 审计）：导入必须先于主 try 完成。此前 import 放在
        # try 内而 `except ListingWorkflowError:` 引用导入名——任何导入失败
        # （缺依赖/代码漂移）都会让 except 子句抛 UnboundLocalError，把真实的
        # ImportError 永久掩盖。导入失败单独回结构化收据，保留脱敏后的真因。
        try:
            from security.listing_code_lane import (
                publish_listing_code,
                run_listing_code,
            )
            from security.listing_workflow import ListingWorkflowError, inspect_listing
        except Exception as exc:
            return _result(False, code="LISTING_STACK_UNAVAILABLE",
                           reason=sanitize_error(exc))
        try:
            project = str(request.get("project") or "")
            raw_scenario = request.get("scenario")
            scenario = str(raw_scenario) if raw_scenario else None
            if operation == "listing_inspect":
                credential_ref = str(request.get("credentialRef") or "") or None
                credentials_dir = str(context.get("credentialsDir") or "") or None
                return _result(True, action="listing-inspect", inspection=inspect_listing(
                    local_data_root=str(context.get("localDataRoot") or ""),
                    project=project, scenario=scenario,
                    credential_ref=credential_ref, credentials_dir=credentials_dir,
                ))
            if operation == "listing_run_code":
                return _result(True, action="listing-run-code", receipt=run_listing_code(
                    local_data_root=str(context.get("localDataRoot") or ""),
                    project=project, scenario=scenario,
                    code=request.get("code"),
                    credential_ref=str(request.get("credentialRef") or "") or None,
                    credentials_dir=str(context.get("credentialsDir") or "") or None,
                    session_id=str(context.get("sessionId") or "unknown-session"),
                ))
            return _result(True, action="listing-publish", receipt=publish_listing_code(
                local_data_root=str(context.get("localDataRoot") or ""),
                project=project, scenario=scenario,
                credential_ref=str(request.get("credentialRef") or "") or None,
                credentials_dir=str(context.get("credentialsDir") or "") or None,
                session_id=str(context.get("sessionId") or "unknown-session"),
                output_plane_root=str(context.get("outputPlaneRoot") or "") or None,
            ))
        except ListingWorkflowError as exc:
            # E-3: ListingWorkflowError 的文案本身即模型安全（不含路径/记录），
            # 保留原文与结构化 code，让 AI 能据此采取动作（如补凭据），
            # 而不是收到一句无法行动的 "operation failed"。
            return _result(False, code=getattr(exc, "code", "LISTING_WORKFLOW_ERROR"),
                           reason=str(exc))
        except Exception as exc:
            return _result(False, code="WORKFLOW_UNAVAILABLE", reason=sanitize_error(exc))

    if operation == "scrub_row":
        row = request.get("row", [])
        row_text = " ".join(str(value) for value in (row if isinstance(row, list) else [row]))
        scrubbed_text, stats = smart_scrub_text(
            row_text, str(request.get("profile", "strict")))
        return _result(
            True,
            row=[scrubbed_text],
            risk_level=("SUSPICIOUS_LOW" if stats.data_lines > 0 else "SAFE"),
            patterns=[],
            evidence=[],
            recommendation=("SCRUB" if stats.tokens_hashed else "PASS"),
            # 2026-08-23：体量不构成拦截或询问理由，不再调用 is_mass_data_dump
            # （函数本体按"不启用，先不删"保留）。真实数据由 protectedDataSource
            # 按来源域阻断。
            needs_user=False,
            scrubbed_rows=stats.lines_changed,
            data_lines=stats.data_lines,
            tokens_hashed=stats.tokens_hashed,
        )

    if operation == "scrub_text":
        # 显式二次处理能力，仅供误表头/元数据等受控调用方使用；普通工具结果
        # 与模型请求不会自动进入此操作。
        text = str(request.get("text", ""))
        profile = str(request.get("profile", "strict"))
        scrubbed_text, stats = smart_scrub_text(text, profile)
        # 2026-08-23：同 scrub_row，体量不再触发用户询问。
        needs_user = False
        return _result(
            True,
            text=scrubbed_text,
            scrubbed_rows=stats.lines_changed,
            data_lines=stats.data_lines,
            tokens_hashed=stats.tokens_hashed,
            needs_user=needs_user,
            user_prompt=(
                "数据安全检查：检测到整表级数据转储。选项：跳过（默认）/ 脱敏后继续 / 允许（需授权）"
                if needs_user else None
            ),
        )

    if operation == "inspect_file":
        path = str(request.get("path", ""))
        if not path.lower().endswith((".xlsx", ".xls")):
            return _result(True, needs_user=False)
        max_rows = max(1, int(request.get("max_scan_rows", 200)))
        try:
            if path.lower().endswith(".xls"):
                # 真实故障修复：openpyxl 不支持 .xls（真实 .xls 预检一律失败导致
                # agent 被拒）。.xls 走 xlrd 只读解析；SpreadsheetML XML 伪装的
                # .xls（如 *PROD.xls）由 xlrd 抛错进入 fail-closed。
                import xlrd
                workbook = xlrd.open_workbook(path, on_demand=True)
                try:
                    prompt, options = _scan_workbook(_XlrdWorkbook(workbook), max_rows)
                finally:
                    workbook.release_resources()
            else:
                import openpyxl
                workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
                try:
                    prompt, options = _scan_workbook(workbook, max_rows)
                finally:
                    workbook.close()
        except Exception as exc:
            # FIX-3: 异常原文不得回传（可能含本地路径/受试者标记/孤立代理）。
            return _result(False, code="SECURITY_UNAVAILABLE",
                           reason=sanitize_error(exc))
        return _result(
            True,
            needs_user=bool(prompt),
            user_prompt=prompt,
            options=options,
        )

    if operation == "authorize":
        category = str(request.get("category", ""))
        if not is_authorizable(category):
            return _result(False, code="INVALID_CATEGORY")
        record = authorize_category(
            request.get("root"),
            request.get("user"),
            request.get("session"),
            category,
            request.get("operator"),
        )
        return _result(bool(record.get("ok")), categories=record.get("categories", []))

    if operation == "ping":
        # FIX-11: 心跳探活——只需返回响应即证明 worker 存活。
        return _result(True, action="pong")

    if operation == "consume_authorization":
        # 仅供本地审计工作流消费记录；llm/stream 不调用此操作放行原文。
        consumed = consume_category(
            request.get("root"),
            request.get("user"),
            request.get("session"),
            str(request.get("category", "L3_ALLOW_AUDITED")),
        )
        return _result(consumed)

    return _result(False, code="UNKNOWN_OPERATION")


def main() -> int:
    # 真实故障修复（P0）：zh-CN Windows 下 sys.stdin/stdout 默认 cp936，
    # Node 侧按 UTF-8 写入的中文请求会被解码为乱码并产生孤立代理字符，
    # 既使出域指纹 .encode('utf-8') 崩溃（全线 fail-closed 停摆），
    # 也会让中文检测在乱码上运行而静默失效。协议层强制 UTF-8，
    # 不依赖 PYTHONIOENCODING/PYTHONUTF8 外部环境变量。
    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    # E-2: 依赖预检 fail-fast。预检在后台线程执行（完整 import pandas 等
    # 需数秒，不能挡在协议路径上——ping/check_tool 必须立即可答）；缺依赖
    # 时输出不带 requestId 的结构化横幅并立即退出，Node 侧记录为启动诊断，
    # 触发 fail-closed。完整 import（而非 find_spec）同时能暴露包损坏
    # （如 pyreadstat DLL 加载失败），这类故障 find_spec 探不出来。
    import threading

    def _preflight() -> None:
        missing = missing_worker_dependencies(stop_on_first=True)
        if missing:
            _emit({
                "ok": False,
                "code": "WORKER_DEPENDENCY_MISSING",
                "reason": "worker python is missing required packages: "
                          + ", ".join(sorted(set(missing))),
            })
            # 横幅已 flush；直接终止，避免与主线程的输出交错撕裂响应行。
            os._exit(3)

    threading.Thread(target=_preflight, daemon=True).start()
    for line in sys.stdin:
        if not line.strip():
            continue
        request_id = None
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("request must be an object")
            request_id = request.get("requestId")
            response = _handle(request)
        except Exception as exc:
            # FIX-3 / FIX-6 (AR-2.6): 畸形行不再让进程崩溃（UnboundLocalError 已修），
            # 返回 SECURITY_UNAVAILABLE 并继续服务后续请求。
            # TEMP-DIAG（临时诊断，定位后删除）: 附带异常类型与出错函数名。
            import traceback as _tb
            _where = ""
            try:
                frames = traceback.extract_tb(sys.exc_info()[2])
                if frames:
                    _where = f" <{_where_diag}>" if False else f" [{type(exc).__name__}@{frames[-1].name}:{frames[-1].lineno}]"
            except Exception:
                pass
            response = _result(False, code="SECURITY_UNAVAILABLE",
                               reason=sanitize_error(exc) + _where)
        response["requestId"] = request_id
        _emit(response)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
