"""沙箱子进程入口：`python -m security.sandbox_runner`。

协议：stdin 一行 job JSON → stdout 一行 result JSON。本进程是**受信固定代码**：
- 执行前重新跑白名单 AST（纵深防御，父层已查过一遍）
- 数据集只能经注入的 ``datasets`` 注册表按需读取（复用 IR 执行器的 canonical
  列名投影，避免 inspect/执行口径分叉）
- run 模式只产出聚合元数据信封；publish 模式由本文件的固定 Writer 落盘 Excel，
  模型代码永远不接触文件写出
- 任何异常收敛为 {type, message}，消息经 sanitize_error 脱敏后仍由父层二次 scrub

stdout 除结果行外不得写任何内容；pandas 警告走 stderr，不回传。
"""
from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any

MAX_OUTPUTS = 64
MAX_COLUMNS = 512
MAX_NAME_CHARS = 64
MAX_AVAILABLE_HINT = 50


class SandboxDataError(RuntimeError):
    """数据集不可用等模型可行动的错误（文案为元数据，不含路径）。"""


class DatasetRegistry(Mapping):
    """名称 → DataFrame 的懒加载只读注册表。

    大小写不敏感；同一数据集多副本视为不可用（不猜选）。读取复用
    listing_executor._read 的 canonical 列名逻辑。
    """

    def __init__(self, files: dict[str, str]) -> None:
        self._files = {str(name).casefold(): str(path) for name, path in files.items()}
        self._cache: dict[str, Any] = {}

    def __getitem__(self, key: str) -> Any:
        name = str(key).casefold()
        if name not in self._cache:
            path = self._files.get(name)
            if path is None:
                available = sorted(self._files)[:MAX_AVAILABLE_HINT]
                raise SandboxDataError(
                    f"dataset '{name}' is not available; available datasets: "
                    + (", ".join(available) if available else "(none)"))
            from security.listing_executor import _read

            self._cache[name] = _read(Path(path))
        return self._cache[name]

    def __iter__(self):
        return iter(self._files)

    def __len__(self) -> int:
        return len(self._files)


def _import_pandas():
    import pandas as pd

    return pd


def _collect_outputs(namespace: dict[str, Any]) -> dict[str, Any]:
    pd = _import_pandas()
    if "outputs" in namespace:
        raw = namespace["outputs"]
        if not isinstance(raw, dict) or not raw:
            raise SandboxDataError(
                "'outputs' must be a non-empty dict of {listing name: DataFrame}")
        frames = {}
        for name, frame in raw.items():
            if not isinstance(frame, pd.DataFrame):
                raise SandboxDataError(
                    f"output '{str(name)[:MAX_NAME_CHARS]}' is not a DataFrame")
            frames[str(name)] = frame
        if len(frames) > MAX_OUTPUTS:
            raise SandboxDataError(f"too many outputs (limit {MAX_OUTPUTS})")
        return frames
    if "result" in namespace:
        frame = namespace["result"]
        if not isinstance(frame, pd.DataFrame):
            raise SandboxDataError("'result' must be a DataFrame")
        return {"result": frame}
    raise SandboxDataError(
        "code must assign 'result' (a DataFrame) or 'outputs' (a dict of DataFrames)")


def _envelope(frames: dict[str, Any], datasets_touched: list[str]) -> dict[str, Any]:
    outputs = []
    for name, frame in frames.items():
        columns = []
        for column in list(frame.columns)[:MAX_COLUMNS]:
            series = frame[column]
            columns.append({
                "name": str(column)[:MAX_NAME_CHARS],
                "dtype": str(series.dtype),
                "nullCount": int(series.isna().sum()),
            })
        outputs.append({
            "name": str(name)[:MAX_NAME_CHARS],
            "rowCount": int(len(frame)),
            "columnCount": int(len(frame.columns)),
            "columns": columns,
        })
    return {
        "status": "ok",
        "mode": "run",
        "outputs": outputs,
        "datasetsTouched": datasets_touched[:MAX_AVAILABLE_HINT],
    }


def _clean_cell(value: Any) -> Any:
    pd = _import_pandas()
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value


def _write_workbook(
    staging: Path, scenario: str, frames: dict[str, Any],
    review_columns: list[str], contents_sheet_name: str,
) -> dict[str, Any]:
    """固定 Writer：CONTENTS 目录页 + 每 listing 一 sheet + 复核列。

    复用 IR 执行器的格式红线（表头样式、冻结/筛选、公式注入防护、原子落盘），
    保证两条车道产出物格式一致；模型代码不参与写文件。
    """
    import openpyxl

    from security.listing_executor import (
        _CONTENTS_HEADERS,
        _atomic_save,
        _finish_sheet,
        _sheet_name,
        _style_header,
    )

    staging.mkdir(parents=True, exist_ok=True)
    path = staging / f"{scenario.upper()}_LISTINGS.xlsx"
    workbook = openpyxl.Workbook()
    workbook.iso_dates = True
    try:
        contents = workbook.active
        contents.title = "Contents"
        contents.append(_CONTENTS_HEADERS)
        _style_header(contents, 1, len(_CONTENTS_HEADERS))
        used = {str(contents_sheet_name).casefold()}
        for index, (name, frame) in enumerate(frames.items(), start=1):
            sheet_name = _sheet_name(name, used)
            contents.append([index, sheet_name, "", "", "", int(len(frame)), 0, 0])
            cell = contents.cell(contents.max_row, 2)
            cell.hyperlink = f"#'{sheet_name}'!A1"
            cell.style = "Hyperlink"
        _finish_sheet(contents, 1, len(_CONTENTS_HEADERS), 1, 1)

        used = {str(contents_sheet_name).casefold()}
        for name, frame in frames.items():
            sheet_name = _sheet_name(name, used, contents_sheet_name)
            sheet = workbook.create_sheet(sheet_name)
            back = sheet.cell(1, 1, "Go back")
            back.hyperlink = f"#'{contents_sheet_name}'!A1"
            back.style = "Hyperlink"
            labels = [str(column) for column in frame.columns] + list(review_columns)
            sheet.append(labels)
            _style_header(sheet, 2, len(labels))
            padding = [""] * len(review_columns)
            for row in frame.itertuples(index=False, name=None):
                sheet.append([_clean_cell(value) for value in row] + padding)
            _finish_sheet(sheet, 2, len(labels), 1, 0)
        _atomic_save(workbook, path)
    finally:
        workbook.close()
    return {
        "status": "ok",
        "mode": "publish",
        "artifacts": [{
            "file": path.name,
            "sheets": [
                {"name": str(name)[:MAX_NAME_CHARS], "rowCount": int(len(frame)),
                 "columnCount": int(len(frame.columns)) + len(review_columns)}
                for name, frame in frames.items()
            ],
        }],
    }


def _error_envelope(exc: BaseException) -> dict[str, Any]:
    from security.patterns import sanitize_error

    try:
        message = sanitize_error(exc) or type(exc).__name__
    except Exception:
        message = type(exc).__name__
    return {
        "status": "error",
        "error": {"type": type(exc).__name__, "message": str(message)[:300]},
    }


def execute_job(job: dict[str, Any]) -> dict[str, Any]:
    from security.code_sandbox import SandboxViolation, build_namespace, check_code

    mode = str(job.get("mode") or "run")
    code = job.get("code") or ""
    try:
        check_code(code)
        datasets = DatasetRegistry(job.get("datasets") or {})
        namespace = build_namespace(datasets)
        # 受信侧 compile：模型代码无 eval/exec 通道，唯一执行入口在这里。
        exec(compile(code, "<listing-code>", "exec"), namespace)  # noqa: S102
        frames = _collect_outputs(namespace)
        if mode == "publish":
            staging = job.get("staging")
            if not staging:
                raise SandboxDataError("publish mode requires a staging directory")
            result = _write_workbook(
                Path(staging), str(job.get("scenario") or "listing"), frames,
                [str(item) for item in (job.get("reviewColumns") or [])],
                str(job.get("contentsSheetName") or "Contents"),
            )
        else:
            result = _envelope(frames, sorted(datasets._cache))
        return result
    except SandboxViolation as exc:
        return {
            "status": "rejected",
            "error": {"type": "SandboxViolation", "message": str(exc)[:300]},
        }
    except BaseException as exc:  # noqa: BLE001 - 收敛一切异常为脱敏信封
        return _error_envelope(exc)


def main() -> int:
    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    line = sys.stdin.readline()
    try:
        job = json.loads(line)
        if not isinstance(job, dict):
            raise ValueError("job must be an object")
        result = execute_job(job)
    except Exception as exc:  # noqa: BLE001
        result = _error_envelope(exc)
    sys.stdout.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
