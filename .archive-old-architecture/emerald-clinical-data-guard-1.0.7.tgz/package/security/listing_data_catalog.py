"""临床 Listing 的受控本地数据目录。

项目目录是只读数据域。运行时解压目录始终位于系统临时区；inspect 只索引归档
目录与明文数据集，execute 才按 ListingPlan 引用的数据集最小化解压。
"""
from __future__ import annotations

import shutil
import tempfile
import zipfile
from pathlib import Path

from security.archive_passwords import extract_dataset_archive
from security.path_policy import PathPolicyError

SOURCE_SUFFIXES = {".sas7bdat", ".xpt", ".csv"}
IGNORED_DIRECTORIES = {".clinical-listing", "_work", "__pycache__"}


class DatasetCatalog:
    def __init__(
        self,
        project: Path,
        credential: bytes | str | None = None,
        required_datasets: set[str] | None = None,
        materialize_archives: bool = True,
    ) -> None:
        self.project = project.resolve(strict=True)
        self.credential = credential
        self.required_datasets = {
            name.casefold() for name in (required_datasets or set())
        }
        self.materialize_archives = materialize_archives
        self._work: Path | None = None
        self._files: dict[str, list[Path]] = {}
        self._archive_datasets: dict[str, list[str]] = {}
        self.missing_archives: list[str] = []

    def __enter__(self) -> "DatasetCatalog":
        # 项目数据域保持只读。超时或进程终止的残留不能污染项目树。
        self._work = Path(tempfile.mkdtemp(prefix="emerald-listing-"))
        try:
            self._scan_project_files()
            archives = self._index_archives()
            if self.materialize_archives:
                self._materialize_archives(archives)
            return self
        except Exception:
            self.close()
            raise

    def __exit__(self, _type, _value, _traceback) -> None:
        self.close()

    def close(self) -> None:
        if self._work is not None:
            shutil.rmtree(self._work, ignore_errors=True)
        self._work = None

    def _project_files(self):
        """只遍历原始项目输入，忽略历史运行目录及其权限状态。"""
        stack = [self.project]
        while stack:
            directory = stack.pop()
            try:
                entries = list(directory.iterdir())
            except OSError:
                continue
            for entry in entries:
                try:
                    if entry.is_dir():
                        if entry.name.casefold() not in IGNORED_DIRECTORIES:
                            stack.append(entry)
                    elif entry.is_file():
                        yield entry
                except OSError:
                    continue

    def _record(self, path: Path) -> None:
        self._files.setdefault(path.stem.casefold(), []).append(path)

    def _scan_project_files(self) -> None:
        for path in self._project_files():
            if path.suffix.casefold() in SOURCE_SUFFIXES:
                self._record(path)

    def _index_archives(self) -> list[Path]:
        """读取 ZIP central directory；该步骤不解压任何数据成员。"""
        archives: list[Path] = []
        for archive in sorted(
            (path for path in self._project_files() if path.suffix.casefold() == ".zip"),
            key=lambda path: path.as_posix().casefold(),
        ):
            try:
                with zipfile.ZipFile(archive, "r") as bundle:
                    datasets = sorted({
                        Path(info.filename).stem.casefold()
                        for info in bundle.infolist()
                        if not info.is_dir()
                        and Path(info.filename).suffix.casefold() in SOURCE_SUFFIXES
                    })
            except (OSError, zipfile.BadZipFile):
                self.missing_archives.append(archive.relative_to(self.project).as_posix())
                continue
            archives.append(archive)
            relative = archive.relative_to(self.project).as_posix()
            for dataset in datasets:
                self._archive_datasets.setdefault(dataset, []).append(relative)
        return archives

    def _materialize_archives(self, archives: list[Path]) -> None:
        assert self._work is not None
        for index, archive in enumerate(archives):
            destination = self._work / f"archive-{index:04d}"
            try:
                extracted = extract_dataset_archive(
                    self.project,
                    archive,
                    destination,
                    self.credential,
                    include_datasets=self.required_datasets or None,
                )
            except PathPolicyError:
                relative = archive.relative_to(self.project).as_posix()
                if relative not in self.missing_archives:
                    self.missing_archives.append(relative)
                continue
            for path in extracted:
                if path.suffix.casefold() in SOURCE_SUFFIXES:
                    self._record(path)

    def files(self) -> dict[str, list[Path]]:
        return {key: list(value) for key, value in self._files.items()}

    def archive_datasets(self) -> dict[str, list[str]]:
        return {key: list(value) for key, value in self._archive_datasets.items()}