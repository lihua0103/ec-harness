import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const source = JSON.parse(readFileSync(join(here, '..', 'security', 'node_patterns.json'), 'utf8'));

export const dlpPatterns = source.map(({ source: pattern, flags = '', label }) => ({
  label,
  regex: new RegExp(pattern, flags),
}));

const safePatterns = [
  /^Day\s*\d+$/i,
  /^Week\s*\d+$/i,
  /^Cycle\s*\d+$/i,
  /^Visit\s*\d+$/i,
  /^Baseline$/i,
  /^Screening$/i,
];

export function scanDlp(text) {
  const value = String(text ?? '');
  for (const { regex, label } of dlpPatterns) {
    const match = regex.exec(value);
    // ST-P1-6: 安全词豁免必须整体等于命中串，不能因命中串"包含"安全词子串就放行
    // （否则 USUBJID=SCREENING-01-123456 因含 Screening 被整体豁免泄露）。
    if (match && !safePatterns.some((safe) => safe.test(match[0].trim()))) return label;
  }
  return null;
}

export function redactSensitiveText(text) {
  return String(text ?? '')
    .replace(/[\r\n]+/g, ' ')
    // FIX-3 (AR-2.9): 本地路径（Windows 盘符 / UNC / Unix 绝对路径）→ [PATH]
    .replace(/[A-Za-z]:\\[^\s"']*/g, '[PATH]')
    .replace(/\\\\[^\s"']+/g, '[PATH]')
    .replace(/(^|[\s"'(=])((?:\/[\w.-]+){2,})/g, '$1[PATH]')
    .replace(/\b[A-Za-z]{1,4}\d{6,8}\b/g, '[SUBJ]')
    .replace(/\b\d{3,4}-\d{3,6}\b/g, '[SUBJ]')
    .replace(/\b\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2})?)?\b/g, '[DATE]')
    .slice(0, 120);
}
