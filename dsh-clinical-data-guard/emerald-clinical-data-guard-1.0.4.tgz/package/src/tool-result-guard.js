import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { basename, extname, resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { scanDlp, redactSensitiveText } from './patterns.js';

const here = dirname(fileURLToPath(import.meta.url));
const extractor = join(here, '..', 'excel_header_extractor.py');

// FIX-8 (NFR-12): extractor 超时可配置，默认 10s，硬上限 30s；SIGTERM → 2s → SIGKILL。
const EXTRACTOR_TIMEOUT_DEFAULT_MS = 10_000;
const EXTRACTOR_TIMEOUT_MAX_MS = 30_000;
const EXTRACTOR_GRACE_MS = 2_000;

function dirname(path) {
  return path.slice(0, Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\')));
}

function join(...parts) {
  return parts.join('/').replace(/\\/g, '/');
}

export function extractPath(args = {}) {
  for (const key of ['path', 'file_path', 'filePath', 'filename', 'file']) {
    const value = args[key];
    if (typeof value === 'string' && value.trim()) return value;
  }
  return '';
}

/**
 * 本地凭据通道 (用户需求)：判断 filePath 是否位于配置的 credentialsDir 之内。
 * 用解析后的绝对路径前缀判断（防 ../ 穿越），不靠文件名/内容形态（后者是
 * ST-D-5 泄露通道）。credentialsDir 未配置时恒为 false（凭据通道默认关闭）。
 */
export function isCredentialPath(filePath, credentialsDir) {
  if (!credentialsDir || typeof filePath !== 'string' || !filePath.trim()) return false;
  const base = resolve(credentialsDir);
  const target = resolve(filePath);
  const rel = relative(base, target);
  // rel 不以 .. 开头且非绝对路径 → target 在 base 之内。
  return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel);
}

/**
 * 凭据占位：agent 上下文只得到"这是本地凭据、原值在此路径、只允许交本地工具"，
 * 凭据原值绝不进入 LLM 上下文。本地解压工具用路径自行在本地读取原值。
 */
function credentialPlaceholder(path) {
  return {
    clinicalGuard: 'CREDENTIAL_LOCAL_ONLY',
    credentialPath: path,
    message: '本地凭据文件：原值仅供本地工具（如解压）使用，已阻止其进入模型上下文。',
  };
}

function extractorTimeoutMs(config) {
  const raw = Number(config?.extractorTimeoutMs);
  if (!Number.isFinite(raw) || raw <= 0) return EXTRACTOR_TIMEOUT_DEFAULT_MS;
  return Math.min(raw, EXTRACTOR_TIMEOUT_MAX_MS);
}

function runExtractor(path, maxRows, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.env.PYTHON ?? (process.platform === 'win32' ? 'python' : 'python3'), [
      extractor,
      path,
      '--max-scan-rows',
      String(maxRows),
    ], { stdio: ['ignore', 'pipe', 'pipe'], env: (() => { const e = {}; for (const k of ['PATH','SystemRoot','USERPROFILE','HOME','TEMP','TMP','LOCALAPPDATA','APPDATA','HOMEDRIVE','HOMEPATH','LD_LIBRARY_PATH','DYLD_LIBRARY_PATH']) { if (process.env[k] !== undefined) e[k] = process.env[k]; } e.PYTHONIOENCODING = 'utf-8'; e.PYTHONUTF8 = '1'; if (process.env.EMERALD_AUDIT_ROOT) e.EMERALD_AUDIT_ROOT = process.env.EMERALD_AUDIT_ROOT; return e; })() });
    let out = '';
    let err = '';
    let killTimer;
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      killTimer = setTimeout(() => child.kill('SIGKILL'), EXTRACTOR_GRACE_MS);
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { out += chunk; });
    child.stderr.on('data', (chunk) => { err += chunk; });
    child.on('error', (error) => {
      clearTimeout(timer);
      clearTimeout(killTimer);
      reject(error);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      clearTimeout(killTimer);
      if (code !== 0) {
        // FIX-3 (AR-2.9): extractor stderr 已在 Python 侧脱敏，此处再做路径/受试者兜底脱敏。
        reject(new Error(redactSensitiveText(err.trim()) || `excel extractor exited with ${code}`));
        return;
      }
      try {
        resolve(JSON.parse(out));
      } catch (error) {
        reject(new Error(redactSensitiveText(`invalid excel extractor response: ${error.message}`)));
      }
    });
  });
}

function dataOnlyPlaceholder(path, kind) {
  return {
    clinicalGuard: 'DATA_BLOCKED',
    kind,
    file: redactSensitiveText(basename(path)),
    message: '临床数据行内容已屏蔽；仅允许本地处理，禁止发送给模型。',
  };
}

/**
 * FIX-1 (R-8 / FR-07-02 / BR-03.4 / BY-13 / TC-20):
 * 不再按工具名是否包含 `read` 放行。所有工具结果都必须进入安全处置：
 * 无路径 → scrub_text；危险扩展名 → 占位；Excel 类 → 表头提取；
 * 带路径但扩展名未识别 → 同样强制 scrub_text。
 */
export function shouldReplaceResult() {
  return true;
}

/**
 * FIX-4 (R-3 / 5.5 / FR-13 / TC-26): post-execute 命中 SENSITIVE 时不再把
 * 三选项作为工具结果交给 Agent 自决，而是返回 needsApproval 信号，
 * 由宿主审批通道 (ctx.approval.request) 请求用户决策；无审批通道时 fail-closed。
 */
export async function safeToolResult(exec, result, runtime, config) {
  const path = extractPath(exec.arguments ?? {});
  const ext = extname(path).toLowerCase();

  // 本地凭据通道（用户需求）：credentialsDir 下的文件原值绝不进 LLM 上下文，
  // 只把路径占位交回 agent，由本地工具（解压等）在本地读取真实凭据值。
  // 优先于其它分类——凭据文件不该被 token 化或表头提取。
  if (isCredentialPath(path, config.credentialsDir)) {
    return { value: credentialPlaceholder(path) };
  }

  if (ext === '.sas7bdat') return { value: dataOnlyPlaceholder(path, 'SAS_DATA') };
  if (ext === '.zip') return { value: dataOnlyPlaceholder(path, 'ZIP_MAYBE_DATA') };

  if (['.xlsx', '.xls', '.csv'].includes(ext)) {
    if (!existsSync(path)) {
      return {
        value: {
          clinicalGuard: 'CHECK_FAILED',
          reason: '目标文件不存在，无法验证内容。',
        },
      };
    }
    try {
      const headers = await runExtractor(path, config.maxScanRows, extractorTimeoutMs(config));
      return { value: { clinicalGuard: 'EXCEL_HEADERS_ONLY', ...headers } };
    } catch (error) {
      return {
        value: {
          clinicalGuard: 'CHECK_FAILED',
          reason: '表头安全提取失败，结果已 fail-closed。',
          detail: redactSensitiveText(error.message),
        },
      };
    }
  }

  // 无路径 / 带路径但扩展名未识别（BR-03.4）：一律 scrub_text。
  const payload = result?.value ?? result?.content ?? result;
  const serialized = typeof payload === 'string' ? payload : JSON.stringify(payload);
  const scrub = await runtime.request({ operation: 'scrub_text', text: serialized });
  if (!scrub.ok) {
    return {
      value: {
        clinicalGuard: 'BLOCKED',
        reason: '工具结果安全脱敏失败。',
      },
    };
  }
  if (scrub.needs_user) {
    // 敏感数据组合：决策权交还用户，不进入模型上下文。
    // scrubbedText 供"脱敏后继续"选项使用；原值仅在 L3_ALLOW_AUDITED 时放行。
    return {
      needsApproval: true,
      userPrompt: scrub.user_prompt,
      scrubbedText: `已自动脱敏 ${scrub.scrubbed_rows} 行疑似数据\n${scrub.text}`,
    };
  }
  return { value: `已自动脱敏 ${scrub.scrubbed_rows} 行疑似数据\n${scrub.text}` };
}
