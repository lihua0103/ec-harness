"""DLP 模式库单一来源 (P1-4)

Node.js 插件初筛与 Python 安全内核共用此文件中的定义。
修改模式时只改这一个文件，再运行 scripts/sync_patterns.py 生成 Node 端副本。

导出:
  SUBJECT_ID_PATTERNS  — 受试者编号正则 (compiled)
  DATE_PATTERNS        — 临床日期正则 (compiled)
  MEDICAL_CODE_PATTERNS — 医学编码正则 (compiled)
  CDISC_CORE_FIELDS    — CDISC 标准字段名集合
  CLINICAL_TERMS       — 临床术语集合
  SAS_CLINICAL_DOMAINS — SAS 域名集合
  SAFE_CONTEXT_RE      — 安全上下文正则（版本/文件名日期豁免）
"""
from __future__ import annotations
import hashlib
import re

# ---------------------------------------------------------------------------
# 受试者编号模式
# ---------------------------------------------------------------------------
SUBJECT_ID_PATTERNS: list[tuple[re.Pattern, str]] = [
    # 站点-受试者编号 (101-001, 001-0001)
    (re.compile(r'\b\d{3,4}-\d{3,6}\b'), "站点-受试者编号"),
    # 字母前缀+6-8位数字 (A1234567, S0001234) — IGNORECASE 认小写绕过 (ST-P1-1)
    (re.compile(r'\b[A-Z]{1,4}\d{6,8}\b', re.IGNORECASE), "字母前缀编号"),
    # 复合编号 (ABC-12-001234)
    (re.compile(r'\b[A-Z]{2,4}-\d{2,4}-\d{3,6}\b', re.IGNORECASE), "复合站点编号"),
    # USUBJID格式 (STUDY001-SITE01-SUBJ001)
    (re.compile(r'\b[A-Z0-9]+-[A-Z0-9]+-[A-Z0-9]+\b', re.IGNORECASE), "USUBJID格式"),
]

# 数值型受试者编号在 Excel 中会以 int/float 传入。此模式同时用于单元格字符串化
# 后的扫描，避免只依赖 Python isinstance(str) 判断。
# 前导零 5-8 位（如 01001）是 EDC 站点-受试者编号形态；普通 6-8 位数字沿用。
NUMERIC_SUBJECT_ID_RE = re.compile(r"^(?:0\d{4,7}|\d{6,8})$")

# ---------------------------------------------------------------------------
# 临床日期时间模式
# ---------------------------------------------------------------------------
DATE_PATTERNS: list[tuple[re.Pattern, str]] = [
    # ISO8601 带时间（CDISC 标准）
    (re.compile(r'\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\b'), "ISO8601时间戳"),
    # ISO 日期
    (re.compile(r'\b\d{4}-\d{2}-\d{2}\b'), "ISO日期"),
    # SAS 日期格式 (01JAN2024) — IGNORECASE 认 01jan2024 小写绕过 (ST-P1-1)
    (re.compile(r'\b\d{2}[A-Z]{3}\d{4}\b', re.IGNORECASE), "SAS日期(01JAN2024)"),
    # 临床报告日期时间 (08 Jun 2026 05:19:50) — Rave/EDC 导出常见格式
    (re.compile(r'\b\d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2}\b',
                re.IGNORECASE), "临床日期时间(08 Jun 2026 05:19:50)"),
    # 临床报告日期 (08 Jun 2026)
    (re.compile(r'\b\d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4}\b',
                re.IGNORECASE), "临床日期(08 Jun 2026)"),
    # 美式日期 MM/DD/YYYY
    (re.compile(r'\b\d{2}/\d{2}/\d{4}\b'), "MM/DD/YYYY"),
    # 中文日期
    (re.compile(r'\b\d{4}年\d{1,2}月\d{1,2}日\b'), "中文日期"),
]

# ---------------------------------------------------------------------------
# 医学编码模式
# ---------------------------------------------------------------------------
MEDICAL_CODE_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r'\bPT:\s*\d{8}\b', re.IGNORECASE), "MedDRA PT编码"),
    (re.compile(r'\bLLT:\s*\d{8}\b', re.IGNORECASE), "MedDRA LLT编码"),
    (re.compile(r'\bWHO:\s*\d{6}\b', re.IGNORECASE), "WHO药品编码"),
]

# ---------------------------------------------------------------------------
# CDISC 标准字段名
# ---------------------------------------------------------------------------
CDISC_CORE_FIELDS: set[str] = {
    "usubjid", "subjid", "subject", "siteid", "screenid", "randid",
    "rfstdtc", "rfendtc", "dthdtc", "aestdtc", "aeendtc",
    "cmstdtc", "cmendt", "exstdtc", "exendtc",
    "vsdtc", "lbdtc", "egdtc",
    "visit", "visitnum", "visitdy", "epoch",
    "domain", "studyid",
}

# ---------------------------------------------------------------------------
# 临床术语
# ---------------------------------------------------------------------------
CLINICAL_TERMS: set[str] = {
    "筛选中", "筛选失败", "已入组", "已随机", "基线访视",
    "治疗期", "随访期", "提前终止", "完成研究",
    "screening", "screen failure", "enrolled", "randomized",
    "baseline", "treatment", "follow-up", "early termination",
    "study completion", "discontinued",
    "不良事件", "严重不良事件",
    "adverse event", "serious adverse event",
    "mild", "moderate", "severe",
    "sae", "ae grade",
    "blood pressure", "heart rate", "temperature",
}

CLINICAL_TERMS_LOWER = {term.lower() for term in CLINICAL_TERMS}

# ---------------------------------------------------------------------------
# SAS 域名
# ---------------------------------------------------------------------------
SAS_CLINICAL_DOMAINS: set[str] = {
    "dm", "ae", "cm", "ex", "lb", "vs", "eg", "mh", "pe",
    "qs", "sc", "ds", "sv", "pr", "fa", "ie", "ho",
    "adsl", "adae", "adcm", "adlb", "advs", "adeg",
}

# ---------------------------------------------------------------------------
# 安全上下文：完整文件名形态版本日期（只豁免文件名上下文中的日期）
# 格式: /[\w\-_]+\.\w+$/ 内 \d{4}-\d{2}-\d{2}
# ---------------------------------------------------------------------------
SAFE_FILENAME_CONTEXT_RE = re.compile(
    r'[\w\-_]*\d{4}-\d{2}-\d{2}[\w\-_]*\.\w{1,6}\b'
)

# ---------------------------------------------------------------------------
# Node.js 插件初筛用弱正则子集；scripts/sync_patterns.py 生成 JSON 副本。
# ---------------------------------------------------------------------------
NODE_DLP_PATTERNS = [
    # 基础受试者编号
    {"re": r"\b\d{3,4}-\d{4,6}-\d{3,6}\b",      "label": "SUBJECT_ID"},
    {"re": r"\b\d{3,4}-\d{3,6}\b",               "label": "SITE_SUBJECT_ID"},
    {"re": r"\bUSUBJID\s*[=:]\s*\S+",  "flags": "i", "label": "USUBJID_ASSIGN"},
    {"re": r"\bSUBJID\s*[=:]\s*\S+",   "flags": "i", "label": "SUBJID_ASSIGN"},
    # 扩展：字母前缀编号（同 Python Layer 2）— IGNORECASE 认小写绕过 (ST-P1-1)
    {"re": r"\b[A-Z]{1,4}\d{6,8}\b",   "flags": "i", "label": "ALPHA_SUBJECT_ID"},
    # 前导零受试者编号（EDC 形态，如 01001）
    {"re": r"\b0\d{4,7}\b",                        "label": "LEADING_ZERO_SUBJECT_ID"},
    {"re": r"\b\d{4}-\d{2}-\d{2}\b",              "label": "ISO_DATE"},
    # ISO8601 时间戳
    {"re": r"\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}",   "label": "ISO8601_DATETIME"},
    # SAS 日期 (01JAN2024 / 01jan2024) — IGNORECASE (ST-P1-1)
    {"re": r"\b\d{2}[A-Z]{3}\d{4}\b", "flags": "i", "label": "SAS_DATE"},
    # 临床报告日期（Rave/EDC 导出格式）
    {"re": r"\b\d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4}\b",
     "flags": "i", "label": "DD_MMM_YYYY_DATE"},
    # MedDRA 编码
    {"re": r"\bPT:\s*\d{8}\b",         "flags": "i", "label": "MEDDRA_PT"},
]


def is_safe_filename_date(text: str, start: int, end: int) -> bool:
    """仅当敏感命中完整落在带扩展名的文件名内时豁免。"""
    for match in SAFE_FILENAME_CONTEXT_RE.finditer(text):
        if start >= match.start() and end <= match.end():
            return True
    return False


# ---------------------------------------------------------------------------
# 错误消息统一脱敏 (FIX-3 / R-6 / AR-2.9)
# ---------------------------------------------------------------------------
# 孤立代理字符（\ud800-\udfff）：JSON 传输可携带，UTF-8 编码必崩，必须清除。
_SURROGATE_RE = re.compile(r"[\ud800-\udfff]")

# 路径形态：Windows 盘符路径 / UNC 路径 / Unix 绝对路径（含反斜杠形式）。
_PATH_RES = [
    re.compile(r'[A-Za-z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*'),
    re.compile(r'\\\\[^\\/:*?"<>|\r\n]+(?:\\[^\\/:*?"<>|\r\n]+)+'),
    re.compile(r'(?<![\w.])/(?:[\w.-]+/)+[\w.-]*'),
]


def clean_surrogates(text: object, replacement: str = "\ufffd") -> str:
    """孤立代理字符（lone surrogate，如 \\udcae）统一替换为 U+FFFD。

    JSON 输入可合法携带 \\udXXX 孤立代理（Node JSON.stringify 会原样输出），
    但 Python stdout 以 UTF-8 编码时会抛 UnicodeEncodeError 杀死 worker/extractor。
    所有出域文本（worker 响应、extractor stdout）必须先过本函数。
    """
    return _SURROGATE_RE.sub(replacement, str(text))


def sanitize_error(text: object, limit: int = 200) -> str:
    """错误回执统一脱敏：先清孤立代理，再路径→[PATH]、受试者/日期→占位，截断。"""
    s = clean_surrogates(text)
    for pattern, label in SUBJECT_ID_PATTERNS:
        s = pattern.sub(f"[SUBJ]", s)
    for pattern, _label in DATE_PATTERNS:
        s = pattern.sub("[DATE]", s)
    for pattern in _PATH_RES:
        s = pattern.sub("[PATH]", s)
    s = re.sub(r"[\r\n\t]+", " ", s)
    return s[:limit]


def stable_hash(value: object, length: int = 24) -> str:
    """统一单向哈希上下文 (FIX-9.4)：审计与授权记录使用同一哈希算法，可相互关联。"""
    return hashlib.sha256(str(value if value not in (None, "") else "anonymous").encode("utf-8")).hexdigest()[:length]
